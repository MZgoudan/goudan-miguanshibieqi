# 🔧 Service Worker 修复指南

## 🚨 问题描述
Chrome扩展管理页面显示 "Service Worker (无效)"，导致插件无法正常工作。

## 🔍 问题原因分析

### 已修复的问题
1. **语法错误**: background.js第287行的try语句缺少对应的catch语句
2. **变量引用错误**: 在Service Worker环境中过早引用未定义的变量
3. **API兼容性**: 某些API在Service Worker环境中不可用

### 修复内容
- ✅ 添加了缺失的catch语句
- ✅ 修复了变量引用时机问题
- ✅ 添加了Service Worker初始化函数
- ✅ 改进了错误处理机制

## 🛠️ 修复步骤

### 步骤1: 重新加载插件
1. 打开 `chrome://extensions/`
2. 找到"狗蛋蜜罐识别器"
3. 点击"重新加载"按钮 (🔄)
4. 检查Service Worker状态是否变为"正在运行"

### 步骤2: 验证修复
1. 点击插件图标，确认popup正常显示
2. 打开 `test/service-worker-debug.html` 进行诊断
3. 检查控制台是否有错误信息

### 步骤3: 功能测试
1. 访问任意网站，测试检测功能
2. 打开 `test/quick-bug-check.html` 运行快速检查
3. 确认所有核心功能正常工作

## 🔧 手动修复方法

如果自动修复不成功，请按以下步骤手动修复：

### 方法1: 使用简化版Service Worker
1. 将 `manifest.json` 中的 `background.service_worker` 改为 `background-simple.js`
2. 重新加载插件
3. 测试基础功能是否正常

### 方法2: 检查语法错误
1. 打开Chrome开发者工具
2. 访问 `chrome://extensions/`
3. 点击插件的"错误"按钮查看详细错误信息
4. 根据错误信息修复代码

### 方法3: 权限检查
1. 确认manifest.json中的权限配置正确
2. 检查host_permissions是否包含所需域名
3. 验证content_scripts配置是否正确

## 🧪 测试工具

### 1. Service Worker诊断工具
文件: `test/service-worker-debug.html`
功能:
- 检查Service Worker状态
- 测试扩展API通信
- 查看错误日志
- 提供修复建议

### 2. 快速Bug检查
文件: `test/quick-bug-check.html`
功能:
- 12项关键检查
- 实时评分
- 问题诊断

### 3. Chrome兼容性测试
文件: `test/chrome-compatibility-test.html`
功能:
- 全面兼容性测试
- API可用性检查
- 性能测试

## 📊 常见错误代码

### 错误1: "Service Worker (无效)"
**原因**: JavaScript语法错误或API使用不当
**解决**: 检查控制台错误，修复语法问题

### 错误2: "Failed to load extension"
**原因**: manifest.json配置错误
**解决**: 验证JSON格式和字段配置

### 错误3: "Permission denied"
**原因**: 权限配置不足
**解决**: 添加必要的permissions和host_permissions

### 错误4: "Script load failed"
**原因**: 引用的脚本文件不存在或路径错误
**解决**: 检查importScripts路径和文件存在性

## 🎯 验证清单

完成修复后，请确认以下项目：

- [ ] Service Worker状态显示"正在运行"
- [ ] 插件图标正常显示
- [ ] Popup界面可以正常打开
- [ ] 控制台无错误信息
- [ ] 核心检测功能正常工作
- [ ] 通知功能正常
- [ ] 存储功能正常

## 🆘 紧急修复

如果以上方法都无效，请使用紧急修复版本：

1. 备份当前的 `background.js`
2. 使用 `background-simple.js` 替换
3. 修改 `manifest.json` 指向简化版
4. 重新加载插件

简化版功能：
- ✅ 基础检测功能
- ✅ 消息通信
- ✅ 存储功能
- ❌ 高级检测规则
- ❌ 复杂配置选项

## 📞 技术支持

如果问题仍然存在：

1. **查看详细错误**: 
   - 打开 `chrome://extensions/`
   - 点击"错误"查看详细信息
   - 截图保存错误信息

2. **收集诊断信息**:
   - 运行 `test/service-worker-debug.html`
   - 导出错误日志
   - 记录Chrome版本和操作系统

3. **尝试最小化复现**:
   - 使用 `manifest-debug.json`
   - 逐步添加功能模块
   - 确定问题所在

## 🔄 预防措施

为避免将来出现类似问题：

1. **代码质量**:
   - 使用ESLint检查语法
   - 添加try-catch错误处理
   - 避免在Service Worker中使用DOM API

2. **测试流程**:
   - 每次修改后重新加载测试
   - 使用诊断工具定期检查
   - 在不同Chrome版本中测试

3. **版本管理**:
   - 保留工作版本的备份
   - 记录每次修改的内容
   - 使用版本控制系统

---

**修复完成后，Service Worker应该显示为"正在运行"状态，插件功能恢复正常。**
