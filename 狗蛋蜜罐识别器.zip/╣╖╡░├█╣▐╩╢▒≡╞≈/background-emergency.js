/**
 * 狗蛋蜜罐识别器 - 紧急修复Service Worker
 * 最简化版本，确保能够正常运行
 */

'use strict';

// 🚨 立即修复chrome.privacy.network - 在任何代码执行前
console.log('🚨 立即执行chrome.privacy.network修复...');
if (typeof chrome !== 'undefined') {
  if (!chrome.privacy) {
    chrome.privacy = {};
    console.log('✅ 创建chrome.privacy');
  }
  if (!chrome.privacy.network) {
    chrome.privacy.network = {};
    console.log('✅ 创建chrome.privacy.network');
  }
  if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
    chrome.privacy.network.webRTCIPHandlingPolicy = {
      get: function(details, callback) {
        console.log('🔧 chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（紧急修复）');
        if (callback && typeof callback === 'function') {
          setTimeout(() => {
            try {
              callback({ value: 'default' });
            } catch (error) {
              console.warn('callback执行失败:', error);
            }
          }, 0);
        }
      },
      set: function(details, callback) {
        console.log('🔧 chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（紧急修复）');
        if (callback && typeof callback === 'function') {
          setTimeout(() => {
            try {
              callback();
            } catch (error) {
              console.warn('set callback执行失败:', error);
            }
          }, 0);
        }
      }
    };
    console.log('✅ 创建chrome.privacy.network.webRTCIPHandlingPolicy');
  }
  console.log('✅ chrome.privacy.network立即修复完成');
} else {
  console.warn('⚠️ chrome对象不存在，跳过修复');
}

// 立即导入Service Worker专用的Chrome Privacy修复脚本
try {
  importScripts('service-worker-privacy-fix.js');
  console.log('✅ Service Worker Chrome Privacy修复脚本已导入');
} catch (error) {
  console.warn('⚠️ Service Worker Chrome Privacy修复脚本导入失败:', error);

  // 内联紧急修复
  if (typeof chrome !== 'undefined') {
    if (!chrome.privacy) chrome.privacy = {};
    if (!chrome.privacy.network) chrome.privacy.network = {};
    if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
      chrome.privacy.network.webRTCIPHandlingPolicy = {
        get: function(details, callback) {
          if (callback) setTimeout(() => callback({ value: 'default' }), 0);
        },
        set: function(details, callback) {
          if (callback) setTimeout(callback, 0);
        }
      };
    }
    console.log('✅ 内联Chrome Privacy修复完成');
  }
}

console.log('🚨 紧急修复Service Worker开始加载...');

// 最简配置
const EmergencyConfig = {
  version: '2.2.0',
  enabled: true,
  blackListDomains: [
    "api.fpjs.io", "eu.api.fpjs.io", "comment.api.163.com", "now.qq.com"
  ]
};

// 兼容旧版Heimdallr配置 - 防止pluginStart错误
let HConfig = {
  currentTabs: -999,
  noPageCache: true,
  blockHoneypot: false,
  responseCheck: false,
  pluginStart: true,
  webRtcSettingModify: false,
  canvasInject: false
};

// 确保全局可访问，防止undefined错误
if (typeof window !== 'undefined') {
  window.HConfig = HConfig;
}
if (typeof globalThis !== 'undefined') {
  globalThis.HConfig = HConfig;
}

// 创建chrome.privacy.network安全代理，防止network访问错误
if (typeof chrome !== 'undefined' && !chrome.privacy) {
  console.log('🔧 创建chrome.privacy.network安全代理');

  chrome.privacy = {
    network: {
      webRTCIPHandlingPolicy: {
        get: function(details, callback) {
          console.log('chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（安全代理）');
          if (callback) {
            setTimeout(() => {
              callback({ value: 'default' });
            }, 0);
          }
        },
        set: function(details, callback) {
          console.log('chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（安全代理）');
          if (callback) {
            setTimeout(callback, 0);
          }
        }
      }
    }
  };
}

// 统计数据
let emergencyStats = {
  detectionCount: 0,
  blockCount: 0,
  startTime: Date.now()
};

// UI切换映射
const uiFileMap = {
  'quick': 'resource/popup/quick-config.html',
  'modern': 'resource/popup/modern-ui.html', 
  'classic': 'resource/popup/index.html',
  'simple': 'resource/popup/simple-popup.html'
};

// 简单的消息处理
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 收到消息:', request?.action);
  
  const response = {
    success: true,
    version: EmergencyConfig.version,
    timestamp: Date.now()
  };
  
  try {
    switch (request?.action) {
      case 'ping':
        response.message = 'Service Worker运行正常';
        break;
        
      case 'getConfig':
        response.config = {
          enabled: EmergencyConfig.enabled,
          version: EmergencyConfig.version,
          blackListCount: EmergencyConfig.blackListDomains.length
        };
        break;
        
      case 'getStats':
        response.stats = {
          ...emergencyStats,
          uptime: Date.now() - emergencyStats.startTime
        };
        break;
        
      case 'switchUI':
        const uiType = request.uiType;
        const uiFile = uiFileMap[uiType];

        if (uiFile) {
          chrome.action.setPopup({ popup: uiFile }).then(() => {
            chrome.storage.local.set({ preferredUI: uiType });
            response.message = `已切换到${getUIDisplayName(uiType)}`;
            console.log('✅ UI切换成功:', uiType, '->', uiFile);
          }).catch(error => {
            response.success = false;
            response.message = '切换失败: ' + error.message;
            console.error('❌ UI切换失败:', error);
          });
        } else {
          response.success = false;
          response.message = '未知的UI类型';
        }
        break;

      case 'testPrivacyAPI':
        // 安全地测试chrome.privacy.network
        try {
          if (chrome.privacy && chrome.privacy.network && chrome.privacy.network.webRTCIPHandlingPolicy) {
            chrome.privacy.network.webRTCIPHandlingPolicy.get({}, (details) => {
              if (chrome.runtime.lastError) {
                response.success = false;
                response.message = 'Privacy API错误: ' + chrome.runtime.lastError.message;
              } else {
                response.message = `WebRTC策略: ${details.value}`;
              }
            });
          } else {
            response.message = 'chrome.privacy.network不可用（使用安全代理）';
          }
        } catch (error) {
          response.success = false;
          response.message = 'Privacy API测试失败: ' + error.message;
        }
        break;

      // 🚨 蜜罐检测结果处理
      case 'honeypotDetected':
        console.log('🚨 检测到蜜罐:', request);

        // 存储检测结果到本地，供前端UI显示
        const detectionResult = {
          timestamp: Date.now(),
          url: sender.tab?.url || 'unknown',
          domain: sender.tab?.url ? new URL(sender.tab?.url).hostname : 'unknown',
          honeypotType: request.honeypotType || 'unknown',
          evidence: request.evidence || '',
          confidence: request.confidence || 'unknown',
          ruleName: request.ruleName || '',
          ruleDescription: request.ruleDescription || ''
        };

        // 获取现有检测历史
        chrome.storage.local.get(['honeypotDetections'], (result) => {
          const detections = result.honeypotDetections || [];
          detections.unshift(detectionResult); // 最新的在前面

          // 只保留最近100条记录
          if (detections.length > 100) {
            detections.splice(100);
          }

          // 保存到存储
          chrome.storage.local.set({ honeypotDetections: detections });
        });

        // 记录蜜罐检测日志
        console.warn('🚨🚨🚨 蜜罐检测警告 🚨🚨🚨');
        console.warn('网站:', sender.tab?.url || 'unknown');
        console.warn('类型:', request.honeypotType);
        console.warn('证据:', request.evidence);
        console.warn('置信度:', request.confidence);

        // 更新统计
        emergencyStats.detectionCount++;

        response.message = '蜜罐检测结果已记录到前端UI';
        break;

      default:
        response.message = '未知操作: ' + (request?.action || 'undefined');
    }
  } catch (error) {
    console.error('❌ 消息处理错误:', error);
    response.success = false;
    response.error = error.message;
  }
  
  sendResponse(response);
  return true; // 保持消息通道开放
});

// UI显示名称
function getUIDisplayName(uiType) {
  const names = {
    'quick': '快速配置界面',
    'modern': '现代界面', 
    'classic': '经典界面',
    'simple': '简单界面'
  };
  return names[uiType] || uiType;
}

// 简单的检测功能（非阻塞模式）
function simpleDetection(details) {
  if (!EmergencyConfig.enabled) return;

  try {
    const url = details.url;
    if (!url) return;

    const hostname = new URL(url).hostname.toLowerCase();

    // 检查黑名单
    const isBlocked = EmergencyConfig.blackListDomains.some(domain => {
      return hostname === domain.toLowerCase() || hostname.endsWith('.' + domain.toLowerCase());
    });

    if (isBlocked) {
      emergencyStats.detectionCount++;
      emergencyStats.blockCount++;
      console.log('🚫 检测到可疑域名:', hostname);

      // 发送通知
      if (chrome.notifications) {
        chrome.notifications.create('', {
          type: 'basic',
          iconUrl: 'resource/img/icon/icon-48.png',
          title: '狗蛋蜜罐识别器',
          message: `检测到可疑域名: ${hostname}`
        }).catch(error => {
          console.warn('通知发送失败:', error);
        });
      }

      // 更新badge
      if (chrome.action) {
        chrome.action.setBadgeText({ text: emergencyStats.detectionCount.toString() });
        chrome.action.setBadgeBackgroundColor({ color: '#FF4444' });
      }

      // 非阻塞模式：只记录，不阻止请求
      console.log('📊 已记录可疑请求，继续监控...');
    }
  } catch (error) {
    console.error('❌ 检测函数错误:', error);
  }
}

// 设置WebRequest监听器（非阻塞模式）
if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
  try {
    chrome.webRequest.onBeforeRequest.addListener(
      simpleDetection,
      { urls: ["<all_urls>"] }
      // 移除 ["blocking"] - 改为非阻塞模式
    );
    console.log('✅ WebRequest监听器已设置（非阻塞模式）');
  } catch (error) {
    console.warn('⚠️ WebRequest监听器设置失败:', error.message);
    // 继续运行，不影响其他功能
  }
}

// 初始化配置存储
chrome.storage.local.get(['HConfig']).then(result => {
  if (result.HConfig) {
    // 合并存储的配置
    HConfig = { ...HConfig, ...result.HConfig };
    console.log('✅ 已恢复配置:', HConfig);
  } else {
    // 保存默认配置
    chrome.storage.local.set({ HConfig: HConfig });
    console.log('✅ 已保存默认配置:', HConfig);
  }
}).catch(error => {
  console.warn('⚠️ 配置初始化失败:', error);
});

// 恢复UI偏好
chrome.storage.local.get(['preferredUI']).then(result => {
  const preferredUI = result.preferredUI;
  if (preferredUI && uiFileMap[preferredUI]) {
    chrome.action.setPopup({ popup: uiFileMap[preferredUI] });
    console.log('✅ 已恢复UI偏好:', preferredUI);
  }
}).catch(error => {
  console.warn('⚠️ 恢复UI偏好失败:', error);
});

// 安装事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('📦 扩展安装/更新:', details.reason);
  
  // 设置初始badge
  if (chrome.action) {
    chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    chrome.action.setBadgeText({ text: '' });
  }
  
  if (details.reason === 'install') {
    if (chrome.notifications) {
      chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'resource/img/icon/icon-48.png',
        title: '狗蛋蜜罐识别器',
        message: '安装成功！已开始保护您的浏览安全。'
      });
    }
  }
});

// 启动事件
chrome.runtime.onStartup.addListener(() => {
  console.log('🚀 浏览器启动，Service Worker重新激活');
});

// 全局错误处理
self.addEventListener('error', (event) => {
  console.error('❌ Service Worker全局错误:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('❌ Service Worker未处理的Promise拒绝:', event.reason);
});

// 保持活跃
setInterval(() => {
  console.log('💓 Service Worker保持活跃:', new Date().toISOString());
}, 30000);

console.log('✅ 紧急修复Service Worker加载完成');
