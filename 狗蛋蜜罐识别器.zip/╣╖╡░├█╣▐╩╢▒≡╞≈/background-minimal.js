/**
 * 狗蛋蜜罐识别器 - 极简Service Worker
 * 只包含最基本的功能，确保稳定运行
 */

'use strict';

console.log('狗蛋蜜罐识别器 Minimal Service Worker 开始加载...');

// 极简配置
const MinimalConfig = {
  version: '2.2.0',
  enabled: true,
  
  // 基础黑名单
  blackListDomains: [
    "api.fpjs.io", "eu.api.fpjs.io", "ap.api.fpjs.io", "cdn.fpjs.io",
    "comment.api.163.com", "now.qq.com", "node.video.qq.com"
  ]
};

// 统计数据
let stats = {
  detectionCount: 0,
  blockCount: 0,
  startTime: Date.now()
};

// UI切换辅助函数
function getUIFile(uiType) {
  const uiMap = {
    'quick': 'resource/popup/quick-config.html',
    'modern': 'resource/popup/modern-ui.html',
    'classic': 'resource/popup/index.html',
    'simple': 'resource/popup/simple-popup.html'
  };
  return uiMap[uiType] || null;
}

function getUIDisplayName(uiType) {
  const nameMap = {
    'quick': '快速配置界面',
    'modern': '现代界面',
    'classic': '经典界面',
    'simple': '简单界面'
  };
  return nameMap[uiType] || uiType;
}

// 极简消息处理
function handleMessage(request, sender, sendResponse) {
  console.log('收到消息:', request?.action || 'unknown');
  
  try {
    const response = {
      success: true,
      version: MinimalConfig.version,
      timestamp: Date.now()
    };
    
    switch (request?.action) {
      case 'ping':
        response.status = 'ok';
        response.message = 'Service Worker运行正常';
        break;
        
      case 'getConfig':
        response.config = {
          enabled: MinimalConfig.enabled,
          blackListCount: MinimalConfig.blackListDomains.length,
          version: MinimalConfig.version
        };
        break;
        
      case 'getStats':
        response.stats = {
          ...stats,
          uptime: Date.now() - stats.startTime
        };
        break;
        
      case 'updateConfig':
        if (request.key === 'enabled' && typeof request.value === 'boolean') {
          MinimalConfig.enabled = request.value;
          response.message = `检测功能已${request.value ? '启用' : '禁用'}`;
        } else {
          response.success = false;
          response.error = '无效的配置参数';
        }
        break;

      case 'switchUI':
        try {
          const uiType = request.uiType;
          const uiFile = getUIFile(uiType);

          if (uiFile) {
            // 动态更改popup指向
            await chrome.action.setPopup({ popup: uiFile });

            // 保存用户偏好
            await chrome.storage.local.set({ preferredUI: uiType });

            response.success = true;
            response.message = `已切换到${getUIDisplayName(uiType)}`;
            console.log('UI切换成功:', uiType, '->', uiFile);
          } else {
            response.success = false;
            response.message = '未知的UI类型';
          }
        } catch (error) {
          console.error('UI切换失败:', error);
          response.success = false;
          response.message = '切换失败: ' + error.message;
        }
        break;
        
      default:
        response.success = false;
        response.error = '未知的操作: ' + (request?.action || 'undefined');
    }
    
    sendResponse(response);
  } catch (error) {
    console.error('消息处理出错:', error);
    sendResponse({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
}

// 极简检测函数（仅记录，不阻塞）
function simpleDetection(details) {
  if (!MinimalConfig.enabled) return;
  
  try {
    const url = details.url;
    if (!url) return;
    
    let hostname;
    try {
      hostname = new URL(url).hostname.toLowerCase();
    } catch (e) {
      return;
    }
    
    // 检查黑名单
    const isBlocked = MinimalConfig.blackListDomains.some(domain => {
      return hostname === domain.toLowerCase() || hostname.endsWith('.' + domain.toLowerCase());
    });
    
    if (isBlocked) {
      stats.detectionCount++;
      console.log('检测到可疑域名:', hostname);
      
      // 发送简单通知
      if (chrome.notifications) {
        chrome.notifications.create('', {
          type: 'basic',
          iconUrl: 'resource/img/icon/icon-48.png',
          title: '狗蛋蜜罐识别器',
          message: `检测到可疑域名: ${hostname}`
        }, () => {
          if (chrome.runtime.lastError) {
            console.warn('通知发送失败:', chrome.runtime.lastError.message);
          }
        });
      }
      
      // 更新badge
      if (chrome.action) {
        chrome.action.setBadgeText({ text: stats.detectionCount.toString() });
        chrome.action.setBadgeBackgroundColor({ color: '#FF4444' });
      }
    }
  } catch (error) {
    console.error('检测函数出错:', error);
  }
}

// 设置事件监听器
async function setupListeners() {
  try {
    // 消息监听
    if (!chrome.runtime.onMessage.hasListener(handleMessage)) {
      chrome.runtime.onMessage.addListener(handleMessage);
      console.log('消息监听器已设置');
    }

    // WebRequest监听（非阻塞）
    if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
      if (!chrome.webRequest.onBeforeRequest.hasListener(simpleDetection)) {
        chrome.webRequest.onBeforeRequest.addListener(
          simpleDetection,
          { urls: ["<all_urls>"] }
        );
        console.log('WebRequest监听器已设置（非阻塞）');
      }
    }

    // 恢复用户UI偏好
    await restoreUIPreference();

    // 设置初始badge
    if (chrome.action) {
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
      chrome.action.setBadgeText({ text: '' });
    }

  } catch (error) {
    console.error('监听器设置失败:', error);
  }
}

// 恢复用户UI偏好
async function restoreUIPreference() {
  try {
    const result = await chrome.storage.local.get(['preferredUI']);
    const preferredUI = result.preferredUI;

    if (preferredUI) {
      const uiFile = getUIFile(preferredUI);
      if (uiFile) {
        await chrome.action.setPopup({ popup: uiFile });
        console.log('已恢复UI偏好:', preferredUI, '->', uiFile);
      }
    }
  } catch (error) {
    console.warn('恢复UI偏好失败:', error);
  }
}

// 生命周期事件
chrome.runtime.onStartup.addListener(() => {
  console.log('扩展启动');
  setupListeners();
});

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('扩展安装/更新:', details.reason);
  await setupListeners();

  if (details.reason === 'install') {
    if (chrome.notifications) {
      chrome.notifications.create('', {
        type: 'basic',
        iconUrl: 'resource/img/icon/icon-48.png',
        title: '狗蛋蜜罐识别器',
        message: '安装成功！已开始保护您的浏览安全。'
      });
    }
  }
});

// 全局错误处理
self.addEventListener('error', (event) => {
  console.error('Service Worker全局错误:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('Service Worker未处理的Promise拒绝:', event.reason);
});

// 立即设置监听器
(async () => {
  await setupListeners();
})();

// 保持活跃
let keepAliveInterval = setInterval(() => {
  console.log('Service Worker保持活跃:', new Date().toISOString());
}, 25000);

console.log('狗蛋蜜罐识别器 Minimal Service Worker 加载完成');
