/**
 * 狗蛋蜜罐识别器 - 安全版Service Worker
 * 专门为Service Worker环境设计，避免DOM API使用
 */

'use strict';

console.log('狗蛋蜜罐识别器 Safe Service Worker 开始加载...');

// 安全地导入脚本，添加错误处理
try {
  importScripts("resource/data/data.js");
  console.log('data.js 加载成功');
} catch (error) {
  console.error('data.js 加载失败:', error);
}

try {
  importScripts("resource/data/latest-rules-2024.js");
  console.log('latest-rules-2024.js 加载成功');
} catch (error) {
  console.error('latest-rules-2024.js 加载失败:', error);
}

try {
  importScripts("resource/config/enhanced-config.js");
  console.log('enhanced-config.js 加载成功');
} catch (error) {
  console.error('enhanced-config.js 加载失败:', error);
}

// Service Worker安全配置
const SafeConfig = {
  version: '2.2.0',
  enabled: true,
  
  // 基础黑名单（不依赖外部变量）
  baseBlackListDomains: [
    "comment.api.163.com", "now.qq.com", "node.video.qq.com", "access.video.qq.com",
    "passport.game.renren.com", "wap.sogou.com", "v2.sohu.com", "login.sina.com.cn",
    "api.fpjs.io", "eu.api.fpjs.io", "ap.api.fpjs.io", "cdn.fpjs.io"
  ],
  
  // 完整黑名单（运行时合并）
  blackListDomains: []
};

// 安全的初始化函数
function safeInitialize() {
  try {
    console.log('开始安全初始化...');
    
    // 合并黑名单域名
    SafeConfig.blackListDomains = [...SafeConfig.baseBlackListDomains];
    
    // 安全地添加最新规则
    if (typeof LatestJSONPRules2024 !== 'undefined' && Array.isArray(LatestJSONPRules2024)) {
      SafeConfig.blackListDomains = SafeConfig.blackListDomains.concat(LatestJSONPRules2024);
      console.log('已添加最新JSONP规则:', LatestJSONPRules2024.length, '个');
    }
    
    if (typeof LatestHoneypotDomains2024 !== 'undefined' && Array.isArray(LatestHoneypotDomains2024)) {
      SafeConfig.blackListDomains = SafeConfig.blackListDomains.concat(LatestHoneypotDomains2024);
      console.log('已添加最新蜜罐域名:', LatestHoneypotDomains2024.length, '个');
    }
    
    // 去重
    SafeConfig.blackListDomains = [...new Set(SafeConfig.blackListDomains)];
    
    console.log('黑名单域名总数:', SafeConfig.blackListDomains.length);
    console.log('安全初始化完成');
    
    return true;
  } catch (error) {
    console.error('安全初始化失败:', error);
    return false;
  }
}

// 安全的检测函数（非阻塞模式）
function safeDetection(details) {
  try {
    if (!SafeConfig.enabled) return;

    const url = details.url;
    if (!url) return;

    // 使用URL构造函数解析URL
    let hostname;
    try {
      const urlObj = new URL(url);
      hostname = urlObj.hostname.toLowerCase();
    } catch (e) {
      console.warn('URL解析失败:', url);
      return;
    }

    // 检查黑名单
    const isBlocked = SafeConfig.blackListDomains.some(domain => {
      return hostname === domain.toLowerCase() || hostname.endsWith('.' + domain.toLowerCase());
    });

    if (isBlocked) {
      console.log('检测到黑名单域名:', hostname);

      // 发送通知
      safeNotification(
        '狗蛋蜜罐识别器',
        `检测到可疑域名: ${hostname}`,
        'basic'
      );

      // 安全地记录统计
      try {
        chrome.storage.local.get(['blockCount', 'detectionCount'], (result) => {
          const blockCount = (result.blockCount || 0) + 1;
          const detectionCount = (result.detectionCount || 0) + 1;
          chrome.storage.local.set({
            blockCount: blockCount,
            detectionCount: detectionCount
          });
        });
      } catch (e) {
        console.warn('统计记录失败:', e);
      }
    }
  } catch (error) {
    console.error('检测函数出错:', error);
  }
}

// 安全的消息处理
function safeMessageHandler(request, sender, sendResponse) {
  try {
    console.log('收到消息:', request?.action || 'unknown');
    
    // 基础响应
    const response = {
      success: true,
      version: SafeConfig.version,
      timestamp: Date.now()
    };
    
    switch (request?.action) {
      case 'ping':
        response.status = 'ok';
        response.message = 'Service Worker运行正常';
        break;
        
      case 'getConfig':
        response.config = {
          enabled: SafeConfig.enabled,
          blackListCount: SafeConfig.blackListDomains.length,
          version: SafeConfig.version
        };
        break;
        
      case 'getStats':
        chrome.storage.local.get(['blockCount', 'detectionCount'], (result) => {
          response.stats = {
            blockCount: result.blockCount || 0,
            detectionCount: result.detectionCount || 0
          };
          sendResponse(response);
        });
        return true; // 异步响应
        
      case 'updateConfig':
        if (request.key === 'enabled' && typeof request.value === 'boolean') {
          SafeConfig.enabled = request.value;
          response.message = `检测功能已${request.value ? '启用' : '禁用'}`;
        } else {
          response.success = false;
          response.error = '无效的配置参数';
        }
        break;
        
      default:
        response.success = false;
        response.error = '未知的操作: ' + (request?.action || 'undefined');
    }
    
    sendResponse(response);
  } catch (error) {
    console.error('消息处理出错:', error);
    sendResponse({
      success: false,
      error: error.message,
      timestamp: Date.now()
    });
  }
}

// 安全的通知函数
function safeNotification(title, message, type = 'basic') {
  try {
    if (!chrome.notifications) {
      console.warn('通知API不可用');
      return;
    }
    
    const options = {
      type: type,
      iconUrl: 'resource/img/icon/icon-48.png',
      title: title,
      message: message
    };
    
    chrome.notifications.create('', options, (notificationId) => {
      if (chrome.runtime.lastError) {
        console.warn('通知创建失败:', chrome.runtime.lastError.message);
      } else {
        console.log('通知已发送:', notificationId);
      }
    });
  } catch (error) {
    console.error('通知发送失败:', error);
  }
}

// 设置事件监听器
function setupEventListeners() {
  try {
    // 消息监听
    if (!chrome.runtime.onMessage.hasListener(safeMessageHandler)) {
      chrome.runtime.onMessage.addListener(safeMessageHandler);
      console.log('消息监听器已设置');
    }
    
    // WebRequest监听（非阻塞模式）
    if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
      if (!chrome.webRequest.onBeforeRequest.hasListener(safeDetection)) {
        chrome.webRequest.onBeforeRequest.addListener(
          safeDetection,
          { urls: ["<all_urls>"] }
        );
        console.log('WebRequest监听器已设置（非阻塞模式）');
      }
    } else {
      console.warn('WebRequest API不可用');
    }
    
    // 设置图标状态
    if (chrome.action) {
      chrome.action.setBadgeBackgroundColor({ color: "#4CAF50" });
      chrome.action.setBadgeText({ text: "ON" });
      console.log('图标状态已设置');
    }
    
  } catch (error) {
    console.error('事件监听器设置失败:', error);
  }
}

// 生命周期事件处理
chrome.runtime.onStartup.addListener(() => {
  console.log('扩展启动');
  safeInitialize();
  setupEventListeners();
});

chrome.runtime.onInstalled.addListener((details) => {
  console.log('扩展安装/更新:', details.reason);
  safeInitialize();
  setupEventListeners();
  
  // 首次安装时发送欢迎通知
  if (details.reason === 'install') {
    safeNotification(
      '狗蛋蜜罐识别器',
      '安装成功！已开始保护您的浏览安全。',
      'basic'
    );
  }
});

// 全局错误处理
self.addEventListener('error', (event) => {
  console.error('Service Worker全局错误:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('Service Worker未处理的Promise拒绝:', event.reason);
});

// 立即执行初始化
console.log('开始立即初始化...');
const initResult = safeInitialize();
if (initResult) {
  setupEventListeners();
  console.log('狗蛋蜜罐识别器 Safe Service Worker 加载成功');
} else {
  console.error('狗蛋蜜罐识别器 Safe Service Worker 初始化失败');
}

// 保持Service Worker活跃
let keepAliveInterval;
function startKeepAlive() {
  if (keepAliveInterval) clearInterval(keepAliveInterval);
  
  keepAliveInterval = setInterval(() => {
    console.log('Service Worker保持活跃:', new Date().toISOString());
  }, 25000); // 25秒间隔，避免Service Worker休眠
}

startKeepAlive();

console.log('狗蛋蜜罐识别器 Safe Service Worker 脚本加载完成');
