/**
 * 狗蛋蜜罐识别器 - 简化版Service Worker
 * 用于测试和调试Service Worker问题
 */

'use strict';

console.log('狗蛋蜜罐识别器 Service Worker 开始加载...');

// 基础配置
const BasicConfig = {
  enabled: true,
  version: '2.2.0',
  blackListDomains: [
    "comment.api.163.com", "now.qq.com", "api.fpjs.io", "eu.api.fpjs.io"
  ]
};

// 简化的检测函数
function simpleDetection(details) {
  try {
    const url = details.url;
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;
    
    // 检查黑名单
    if (BasicConfig.blackListDomains.includes(hostname)) {
      console.log('检测到黑名单域名:', hostname);
      return { cancel: true };
    }
    
    return { cancel: false };
  } catch (error) {
    console.error('检测函数出错:', error);
    return { cancel: false };
  }
}

// 消息处理
function handleMessage(request, sender, sendResponse) {
  try {
    console.log('收到消息:', request);
    
    if (request.action === 'ping') {
      sendResponse({ status: 'ok', version: BasicConfig.version });
      return;
    }
    
    if (request.action === 'getConfig') {
      sendResponse(BasicConfig);
      return;
    }
    
    sendResponse({ error: '未知操作' });
  } catch (error) {
    console.error('消息处理出错:', error);
    sendResponse({ error: error.message });
  }
}

// 初始化函数
function initialize() {
  try {
    console.log('初始化 Service Worker...');
    
    // 设置消息监听器
    if (!chrome.runtime.onMessage.hasListener(handleMessage)) {
      chrome.runtime.onMessage.addListener(handleMessage);
      console.log('消息监听器已设置');
    }
    
    // 设置webRequest监听器（如果有权限）
    if (chrome.webRequest && chrome.webRequest.onBeforeRequest) {
      if (!chrome.webRequest.onBeforeRequest.hasListener(simpleDetection)) {
        chrome.webRequest.onBeforeRequest.addListener(
          simpleDetection,
          { urls: ["<all_urls>"] },
          ["blocking"]
        );
        console.log('webRequest监听器已设置');
      }
    } else {
      console.warn('webRequest API不可用');
    }
    
    // 设置图标
    if (chrome.action) {
      chrome.action.setBadgeBackgroundColor({ color: "#4CAF50" });
      chrome.action.setBadgeText({ text: "OK" });
      console.log('图标状态已设置');
    }
    
    console.log('Service Worker 初始化完成');
    return true;
    
  } catch (error) {
    console.error('初始化失败:', error);
    return false;
  }
}

// 错误处理
function handleError(error, context) {
  console.error(`Service Worker 错误 [${context}]:`, error);
  
  // 尝试发送错误报告
  try {
    chrome.storage.local.set({
      lastError: {
        message: error.message,
        stack: error.stack,
        context: context,
        timestamp: Date.now()
      }
    });
  } catch (storageError) {
    console.error('无法保存错误信息:', storageError);
  }
}

// 事件监听器
chrome.runtime.onStartup.addListener(() => {
  console.log('扩展启动事件');
  initialize();
});

chrome.runtime.onInstalled.addListener((details) => {
  console.log('扩展安装事件:', details.reason);
  initialize();
  
  // 首次安装时打开选项页面
  if (details.reason === 'install') {
    try {
      chrome.runtime.openOptionsPage();
    } catch (error) {
      console.warn('无法打开选项页面:', error);
    }
  }
});

// 全局错误处理
self.addEventListener('error', (event) => {
  handleError(event.error, 'global');
});

self.addEventListener('unhandledrejection', (event) => {
  handleError(event.reason, 'unhandledrejection');
});

// 立即初始化
try {
  const initResult = initialize();
  if (initResult) {
    console.log('狗蛋蜜罐识别器 Service Worker 加载成功');
  } else {
    console.error('狗蛋蜜罐识别器 Service Worker 加载失败');
  }
} catch (error) {
  handleError(error, 'immediate_init');
}

// 保持Service Worker活跃
function keepAlive() {
  console.log('Service Worker 保持活跃:', new Date().toISOString());
}

// 每5分钟执行一次保活
setInterval(keepAlive, 5 * 60 * 1000);

console.log('狗蛋蜜罐识别器 Service Worker 脚本加载完成');
