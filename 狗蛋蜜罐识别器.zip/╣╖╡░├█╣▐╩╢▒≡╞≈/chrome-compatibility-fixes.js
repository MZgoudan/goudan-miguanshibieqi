/**
 * 狗蛋蜜罐识别器 - Chrome兼容性修复脚本
 * 修复在不同Chrome版本中的兼容性问题
 */

'use strict';

// Chrome版本检测和兼容性修复
class ChromeCompatibilityFixer {
    constructor() {
        this.chromeVersion = this.getChromeVersion();
        this.isManifestV3 = chrome.runtime.getManifest().manifest_version === 3;
        this.init();
    }

    // 获取Chrome版本
    getChromeVersion() {
        const userAgent = navigator.userAgent;
        const match = userAgent.match(/Chrome\/(\d+)/);
        return match ? parseInt(match[1]) : 0;
    }

    // 初始化兼容性修复
    init() {
        console.log(`Chrome版本: ${this.chromeVersion}, Manifest版本: ${this.isManifestV3 ? 'v3' : 'v2'}`);
        
        this.fixStorageAPI();
        this.fixNotificationAPI();
        this.fixWebRequestAPI();
        this.fixTabsAPI();
        this.fixRuntimeAPI();
    }

    // 修复存储API兼容性
    fixStorageAPI() {
        if (!chrome.storage) {
            console.warn('Storage API不可用');
            return;
        }

        // 为旧版本Chrome添加Promise支持
        if (this.chromeVersion < 88) {
            const originalSet = chrome.storage.local.set;
            const originalGet = chrome.storage.local.get;

            chrome.storage.local.setAsync = function(items) {
                return new Promise((resolve, reject) => {
                    originalSet.call(this, items, () => {
                        if (chrome.runtime.lastError) {
                            reject(chrome.runtime.lastError);
                        } else {
                            resolve();
                        }
                    });
                });
            };

            chrome.storage.local.getAsync = function(keys) {
                return new Promise((resolve, reject) => {
                    originalGet.call(this, keys, (result) => {
                        if (chrome.runtime.lastError) {
                            reject(chrome.runtime.lastError);
                        } else {
                            resolve(result);
                        }
                    });
                });
            };
        }
    }

    // 修复通知API兼容性
    fixNotificationAPI() {
        if (!chrome.notifications) {
            console.warn('Notifications API不可用');
            return;
        }

        // 检查通知权限
        if (this.chromeVersion >= 88) {
            chrome.permissions.contains({
                permissions: ['notifications']
            }, (result) => {
                if (!result) {
                    console.warn('通知权限未授予');
                }
            });
        }

        // 修复通知选项兼容性
        const originalCreate = chrome.notifications.create;
        chrome.notifications.create = function(notificationId, options, callback) {
            // 确保图标路径正确
            if (options.iconUrl && !options.iconUrl.startsWith('chrome-extension://')) {
                options.iconUrl = chrome.runtime.getURL(options.iconUrl);
            }

            // 移除不支持的选项
            if (this.chromeVersion < 90 && options.buttons) {
                delete options.buttons;
            }

            return originalCreate.call(this, notificationId, options, callback);
        }.bind(this);
    }

    // 修复WebRequest API兼容性
    fixWebRequestAPI() {
        if (!chrome.webRequest) {
            console.warn('WebRequest API不可用');
            return;
        }

        // 检查webRequest权限
        chrome.permissions.contains({
            permissions: ['webRequest']
        }, (result) => {
            if (!result) {
                console.warn('webRequest权限未授予');
            }
        });

        // 修复extraHeaders选项兼容性
        const originalAddListener = chrome.webRequest.onBeforeRequest.addListener;
        chrome.webRequest.onBeforeRequest.addListener = function(callback, filter, opt_extraInfoSpec) {
            // 在较新版本的Chrome中，extraHeaders需要特殊处理
            if (opt_extraInfoSpec && opt_extraInfoSpec.includes('extraHeaders')) {
                if (this.chromeVersion >= 88) {
                    // 确保有正确的权限
                    chrome.permissions.contains({
                        origins: filter.urls
                    }, (result) => {
                        if (!result) {
                            console.warn('缺少host权限用于extraHeaders');
                        }
                    });
                }
            }

            return originalAddListener.call(this, callback, filter, opt_extraInfoSpec);
        }.bind(this);
    }

    // 修复Tabs API兼容性
    fixTabsAPI() {
        if (!chrome.tabs) {
            console.warn('Tabs API不可用');
            return;
        }

        // 修复tabs.create的URL处理
        const originalCreate = chrome.tabs.create;
        chrome.tabs.create = function(createProperties, callback) {
            // 确保URL是完整的
            if (createProperties.url && !createProperties.url.startsWith('http') && !createProperties.url.startsWith('chrome-extension://')) {
                createProperties.url = chrome.runtime.getURL(createProperties.url);
            }

            return originalCreate.call(this, createProperties, callback);
        };
    }

    // 修复Runtime API兼容性
    fixRuntimeAPI() {
        if (!chrome.runtime) {
            console.warn('Runtime API不可用');
            return;
        }

        // 修复消息传递的错误处理
        const originalSendMessage = chrome.runtime.sendMessage;
        chrome.runtime.sendMessage = function(message, options, responseCallback) {
            // 如果只有两个参数，第二个参数是回调
            if (arguments.length === 2 && typeof options === 'function') {
                responseCallback = options;
                options = undefined;
            }

            const wrappedCallback = responseCallback ? function(response) {
                if (chrome.runtime.lastError) {
                    console.warn('消息传递错误:', chrome.runtime.lastError.message);
                    return;
                }
                responseCallback(response);
            } : undefined;

            if (options) {
                return originalSendMessage.call(this, message, options, wrappedCallback);
            } else {
                return originalSendMessage.call(this, message, wrappedCallback);
            }
        };
    }

    // 检查API可用性
    checkAPIAvailability() {
        const apis = {
            'chrome.runtime': !!chrome.runtime,
            'chrome.tabs': !!chrome.tabs,
            'chrome.storage': !!chrome.storage,
            'chrome.notifications': !!chrome.notifications,
            'chrome.webRequest': !!chrome.webRequest,
            'chrome.permissions': !!chrome.permissions,
            'chrome.scripting': !!chrome.scripting
        };

        console.log('API可用性检查:', apis);
        return apis;
    }

    // 检查权限状态
    async checkPermissions() {
        if (!chrome.permissions) return {};

        const requiredPermissions = [
            'storage', 'tabs', 'webRequest', 'notifications', 'scripting'
        ];

        const permissionStatus = {};

        for (const permission of requiredPermissions) {
            try {
                const result = await new Promise((resolve) => {
                    chrome.permissions.contains({permissions: [permission]}, resolve);
                });
                permissionStatus[permission] = result;
            } catch (error) {
                permissionStatus[permission] = false;
                console.warn(`检查权限 ${permission} 失败:`, error);
            }
        }

        console.log('权限状态:', permissionStatus);
        return permissionStatus;
    }

    // 生成兼容性报告
    generateCompatibilityReport() {
        const report = {
            chromeVersion: this.chromeVersion,
            manifestVersion: this.isManifestV3 ? 3 : 2,
            isCompatible: this.chromeVersion >= 88,
            apis: this.checkAPIAvailability(),
            recommendations: []
        };

        if (this.chromeVersion < 88) {
            report.recommendations.push('建议升级Chrome到88+版本以获得完整支持');
        }

        if (!this.isManifestV3) {
            report.recommendations.push('当前使用Manifest v2，建议迁移到v3');
        }

        if (!chrome.webRequest) {
            report.recommendations.push('WebRequest API不可用，部分功能可能受限');
        }

        return report;
    }
}

// 全局错误处理
window.addEventListener('error', (event) => {
    console.error('全局错误:', event.error);
    
    // 发送错误报告到background script
    if (chrome.runtime) {
        chrome.runtime.sendMessage({
            type: 'error',
            error: {
                message: event.error.message,
                stack: event.error.stack,
                filename: event.filename,
                lineno: event.lineno
            }
        }).catch(() => {
            // 忽略发送失败的错误
        });
    }
});

// 未处理的Promise拒绝
window.addEventListener('unhandledrejection', (event) => {
    console.error('未处理的Promise拒绝:', event.reason);
    
    if (chrome.runtime) {
        chrome.runtime.sendMessage({
            type: 'unhandledRejection',
            reason: event.reason.toString()
        }).catch(() => {
            // 忽略发送失败的错误
        });
    }
});

// 导出兼容性修复器
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChromeCompatibilityFixer;
} else if (typeof window !== 'undefined') {
    window.ChromeCompatibilityFixer = ChromeCompatibilityFixer;
}

// 自动初始化（仅在扩展环境中）
if (typeof chrome !== 'undefined' && chrome.runtime) {
    const compatibilityFixer = new ChromeCompatibilityFixer();
    
    // 延迟执行权限检查
    setTimeout(() => {
        compatibilityFixer.checkPermissions();
    }, 1000);
    
    // 生成并输出兼容性报告
    setTimeout(() => {
        const report = compatibilityFixer.generateCompatibilityReport();
        console.log('兼容性报告:', report);
    }, 2000);
}
