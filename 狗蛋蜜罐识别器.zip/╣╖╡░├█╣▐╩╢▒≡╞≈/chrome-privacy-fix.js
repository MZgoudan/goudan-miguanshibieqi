/**
 * Chrome Privacy API 全局修复脚本
 * 必须在所有其他脚本之前加载
 * 专门修复 "Cannot read properties of undefined (reading 'network')" 错误
 */

console.log('🔧 Chrome Privacy API 全局修复脚本开始执行...');

// 🔧 立即创建fingerprintDefenseManager，防止ReferenceError
// 检查是否在浏览器环境中（有window对象）
if (typeof window !== 'undefined' && !window.fingerprintDefenseManager) {
    window.fingerprintDefenseManager = {
        isEnabled: true,
        config: {
            canvas: true,
            webgl: true,
            audio: true,
            font: true,
            storage: true,
            clipboard: true,
            webrtc: true,
            mediaDevices: true,
            sensor: true,
            network: true,
            hardware: true,
            timing: true
        },
        stats: {
            canvasBlocked: 0,
            webglBlocked: 0,
            audioBlocked: 0,
            fontBlocked: 0,
            storageBlocked: 0,
            clipboardBlocked: 0,
            webrtcBlocked: 0,
            mediaDevicesBlocked: 0,
            sensorBlocked: 0,
            networkBlocked: 0,
            hardwareBlocked: 0,
            timingBlocked: 0
        },
        enable: function() {
            this.isEnabled = true;
            console.log('指纹防护已启用');
        },
        disable: function() {
            this.isEnabled = false;
            console.log('指纹防护已禁用');
        },
        getStats: function() {
            return this.stats;
        },
        resetStats: function() {
            Object.keys(this.stats).forEach(key => {
                this.stats[key] = 0;
            });
            console.log('指纹防护统计已重置');
        }
    };
    console.log('✅ fingerprintDefenseManager已在全局修复脚本中创建');
}

// 立即创建chrome.privacy.network，防止任何访问错误
(function() {
    'use strict';

    // 立即阻止所有可能的错误
    try {
    
    // 确保chrome对象存在
    if (typeof chrome === 'undefined') {
        console.warn('Chrome对象不存在，跳过privacy修复');
        return;
    }
    
    // 如果chrome.privacy不存在，立即创建
    if (!chrome.privacy) {
        console.log('🔧 立即创建chrome.privacy对象');
        chrome.privacy = {};
    }
    
    // 如果chrome.privacy.network不存在，立即创建
    if (!chrome.privacy.network) {
        console.log('🔧 立即创建chrome.privacy.network对象');
        chrome.privacy.network = {};
    }
    
    // 如果webRTCIPHandlingPolicy不存在，立即创建
    if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
        console.log('🔧 立即创建chrome.privacy.network.webRTCIPHandlingPolicy对象');
        chrome.privacy.network.webRTCIPHandlingPolicy = {
            get: function(details, callback) {
                console.log('chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（全局修复代理）');
                if (callback && typeof callback === 'function') {
                    // 异步返回默认值
                    setTimeout(() => {
                        try {
                            callback({ value: 'default' });
                        } catch (error) {
                            console.warn('Privacy API callback执行失败:', error);
                        }
                    }, 0);
                }
            },
            set: function(details, callback) {
                console.log('chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（全局修复代理）');
                if (callback && typeof callback === 'function') {
                    // 异步确认设置
                    setTimeout(() => {
                        try {
                            callback();
                        } catch (error) {
                            console.warn('Privacy API set callback执行失败:', error);
                        }
                    }, 0);
                }
            }
        };
    }
    
        console.log('✅ Chrome Privacy API 全局修复完成');
    } catch (error) {
        console.error('❌ Chrome Privacy API 修复失败:', error);

        // 最后的紧急修复
        try {
            if (typeof window !== 'undefined') {
                window.chrome = window.chrome || {};
                window.chrome.privacy = window.chrome.privacy || {};
                window.chrome.privacy.network = window.chrome.privacy.network || {};
                window.chrome.privacy.network.webRTCIPHandlingPolicy = window.chrome.privacy.network.webRTCIPHandlingPolicy || {
                    get: function(details, callback) {
                        if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                    },
                    set: function(details, callback) {
                        if (callback) setTimeout(callback, 0);
                    }
                };
                console.log('✅ 紧急修复完成');
            }
        } catch (finalError) {
            console.error('❌ 最终修复也失败了:', finalError);
        }
    }

})();

// 全局错误拦截 - 最后的防线（仅在浏览器环境中）
if (typeof window !== 'undefined' && window.addEventListener) {
    window.addEventListener('error', function(event) {
    const message = event.message;
    if (message && message.includes("Cannot read properties of undefined (reading 'network')")) {
        console.error('🚨 仍然捕获到network访问错误:', {
            message: message,
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno
        });
        
        // 紧急修复
        try {
            if (typeof chrome !== 'undefined') {
                if (!chrome.privacy) chrome.privacy = {};
                if (!chrome.privacy.network) chrome.privacy.network = {};
                if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
                    chrome.privacy.network.webRTCIPHandlingPolicy = {
                        get: function(details, callback) {
                            if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                        },
                        set: function(details, callback) {
                            if (callback) setTimeout(callback, 0);
                        }
                    };
                }
                console.log('🔧 紧急修复chrome.privacy.network完成');
            }
        } catch (error) {
            console.error('紧急修复失败:', error);
        }
        
        // 阻止错误继续传播
        event.preventDefault();
        return true;
    }
    }, true); // 使用捕获阶段
}

// Promise错误拦截（仅在浏览器环境中）
if (typeof window !== 'undefined' && window.addEventListener) {
    window.addEventListener('unhandledrejection', function(event) {
    const reason = event.reason;
    if (reason && reason.message && reason.message.includes("Cannot read properties of undefined (reading 'network')")) {
        console.error('🚨 Promise中捕获到network访问错误:', reason);
        
        // 紧急修复
        try {
            if (typeof chrome !== 'undefined') {
                if (!chrome.privacy) chrome.privacy = {};
                if (!chrome.privacy.network) chrome.privacy.network = {};
                if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
                    chrome.privacy.network.webRTCIPHandlingPolicy = {
                        get: function(details, callback) {
                            if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                        },
                        set: function(details, callback) {
                            if (callback) setTimeout(callback, 0);
                        }
                    };
                }
                console.log('🔧 Promise错误紧急修复chrome.privacy.network完成');
            }
        } catch (error) {
            console.error('Promise错误紧急修复失败:', error);
        }
        
        // 阻止错误显示
        event.preventDefault();
    }
    });
}

console.log('✅ Chrome Privacy API 全局修复脚本加载完成');
