/**
 * 狗蛋蜜罐识别器 - 增强配置管理模块
 * 支持动态配置和性能优化
 */

'use strict';

// ========== 增强配置管理 ==========
const EnhancedConfig = {
  // 默认配置
  defaults: {
    // 基础功能开关
    pluginEnabled: true,
    
    // Anti-HoneyPot配置
    antiHoneyPot: {
      enabled: true,
      sensitivity: 'medium', // low, medium, high
      blockRedirect: true,
      notificationEnabled: true
    },
    
    // Niffler配置
    niffler: {
      enabled: true,
      threshold: 4,
      timeWindow: 8000,
      whitelistEnabled: true,
      domainKeywordsEnabled: true
    },
    
    // 指纹对抗配置
    antiFingerprint: {
      enabled: true,
      canvas: true,
      webgl: true,
      audio: true,
      font: true,
      storage: true,
      clipboard: true
    },
    
    // 蜜罐检测配置
    honeypotDetection: {
      enabled: true,
      confidence: 'medium', // low, medium, high
      autoBlock: false,
      realTimeDetection: true
    },
    
    // 性能优化配置
    performance: {
      maxDetectionResults: 100,
      cleanupInterval: 300000, // 5分钟
      batchNotifications: true,
      throttleDetection: true
    },
    
    // 用户界面配置
    ui: {
      showNotifications: true,
      showBadge: true,
      notificationDuration: 5000,
      detailedLogs: false
    }
  },
  
  // 当前配置
  current: {},
  
  // 配置变更监听器
  listeners: new Set(),
  
  // 初始化配置
  async init() {
    try {
      const stored = await chrome.storage.local.get(['enhancedConfig']);
      this.current = { ...this.defaults, ...stored.enhancedConfig };
      await this.save();
      console.log('狗蛋蜜罐识别器: 配置初始化完成', this.current);
    } catch (error) {
      console.warn('配置初始化失败:', error);
      this.current = { ...this.defaults };
    }
  },
  
  // 保存配置
  async save() {
    try {
      await chrome.storage.local.set({ enhancedConfig: this.current });
      this.notifyListeners();
    } catch (error) {
      console.warn('配置保存失败:', error);
    }
  },
  
  // 获取配置值
  get(path) {
    const keys = path.split('.');
    let value = this.current;
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return undefined;
      }
    }
    
    return value;
  },
  
  // 设置配置值
  async set(path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    let target = this.current;
    
    // 创建嵌套对象路径
    for (const key of keys) {
      if (!target[key] || typeof target[key] !== 'object') {
        target[key] = {};
      }
      target = target[key];
    }
    
    target[lastKey] = value;
    await this.save();
  },
  
  // 批量更新配置
  async update(updates) {
    for (const [path, value] of Object.entries(updates)) {
      await this.set(path, value);
    }
  },
  
  // 重置配置
  async reset() {
    this.current = { ...this.defaults };
    await this.save();
  },
  
  // 添加配置变更监听器
  addListener(callback) {
    this.listeners.add(callback);
  },
  
  // 移除配置变更监听器
  removeListener(callback) {
    this.listeners.delete(callback);
  },
  
  // 通知配置变更
  notifyListeners() {
    for (const listener of this.listeners) {
      try {
        listener(this.current);
      } catch (error) {
        console.warn('配置监听器执行失败:', error);
      }
    }
  },
  
  // 导出配置
  export() {
    return JSON.stringify(this.current, null, 2);
  },
  
  // 导入配置
  async import(configJson) {
    try {
      const imported = JSON.parse(configJson);
      this.current = { ...this.defaults, ...imported };
      await this.save();
      return true;
    } catch (error) {
      console.warn('配置导入失败:', error);
      return false;
    }
  }
};

// ========== 性能监控模块 ==========
const PerformanceMonitor = {
  metrics: {
    detectionCount: 0,
    notificationCount: 0,
    averageDetectionTime: 0,
    memoryUsage: 0,
    lastCleanup: Date.now()
  },
  
  // 记录检测性能
  recordDetection(startTime) {
    const duration = Date.now() - startTime;
    this.metrics.detectionCount++;
    
    // 计算平均检测时间
    this.metrics.averageDetectionTime = 
      (this.metrics.averageDetectionTime * (this.metrics.detectionCount - 1) + duration) / 
      this.metrics.detectionCount;
  },
  
  // 记录通知
  recordNotification() {
    this.metrics.notificationCount++;
  },
  
  // 获取性能报告
  getReport() {
    return {
      ...this.metrics,
      uptime: Date.now() - this.metrics.lastCleanup,
      detectionsPerMinute: this.metrics.detectionCount / ((Date.now() - this.metrics.lastCleanup) / 60000)
    };
  },
  
  // 重置指标
  reset() {
    this.metrics = {
      detectionCount: 0,
      notificationCount: 0,
      averageDetectionTime: 0,
      memoryUsage: 0,
      lastCleanup: Date.now()
    };
  }
};

// ========== 通知管理器 ==========
const NotificationManager = {
  queue: [],
  isProcessing: false,
  lastNotification: 0,
  
  // 添加通知到队列
  async add(notification) {
    if (!EnhancedConfig.get('ui.showNotifications')) {
      return;
    }
    
    this.queue.push({
      ...notification,
      timestamp: Date.now()
    });
    
    if (!this.isProcessing) {
      await this.process();
    }
  },
  
  // 处理通知队列
  async process() {
    this.isProcessing = true;
    
    while (this.queue.length > 0) {
      const notification = this.queue.shift();
      
      // 防止通知过于频繁
      const minInterval = 1000; // 1秒最小间隔
      const timeSinceLastNotification = Date.now() - this.lastNotification;
      
      if (timeSinceLastNotification < minInterval) {
        await new Promise(resolve => setTimeout(resolve, minInterval - timeSinceLastNotification));
      }
      
      try {
        await chrome.notifications.create({
          type: 'basic',
          iconUrl: 'resource/img/icon/icon-48.png',
          title: notification.title,
          message: notification.message,
          priority: notification.priority || 1
        });
        
        this.lastNotification = Date.now();
        PerformanceMonitor.recordNotification();
        
        // 自动清除通知
        const duration = EnhancedConfig.get('ui.notificationDuration');
        if (duration > 0) {
          setTimeout(() => {
            chrome.notifications.clear(notification.id);
          }, duration);
        }
        
      } catch (error) {
        console.warn('通知发送失败:', error);
      }
    }
    
    this.isProcessing = false;
  },
  
  // 清除所有通知
  clearAll() {
    this.queue = [];
    chrome.notifications.getAll((notifications) => {
      for (const id in notifications) {
        chrome.notifications.clear(id);
      }
    });
  }
};

// ========== 数据清理器 ==========
const DataCleaner = {
  // 清理过期数据
  cleanup() {
    const maxResults = EnhancedConfig.get('performance.maxDetectionResults');
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24小时
    
    // 清理HSniffList中的过期数据
    if (typeof HSniffList === 'object' && HSniffList) {
      for (const [key, value] of Object.entries(HSniffList)) {
        if (value.sresult && Array.isArray(value.sresult)) {
          // 按时间排序并限制数量
          value.sresult = value.sresult
            .filter(item => item.details && (now - item.details.timestamp) < maxAge)
            .sort((a, b) => b.details.timestamp - a.details.timestamp)
            .slice(0, maxResults);
          
          // 如果没有结果了，删除整个条目
          if (value.sresult.length === 0) {
            delete HSniffList[key];
          }
        }
      }
    }
    
    // 清理TabStates中的过期数据
    if (typeof TabStates === 'object' && TabStates) {
      for (const [tabId, state] of TabStates.entries()) {
        // 清理超过1小时的标签页状态
        if (state.lastActivity && (now - state.lastActivity) > 3600000) {
          if (state.timer) {
            clearTimeout(state.timer);
          }
          TabStates.delete(tabId);
        }
      }
    }
    
    console.log('狗蛋蜜罐识别器: 数据清理完成');
  },
  
  // 启动定期清理
  startPeriodicCleanup() {
    const interval = EnhancedConfig.get('performance.cleanupInterval');
    setInterval(() => {
      this.cleanup();
    }, interval);
  }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { EnhancedConfig, PerformanceMonitor, NotificationManager, DataCleaner };
} else if (typeof globalThis !== 'undefined') {
  // Service Worker环境或浏览器环境
  globalThis.EnhancedConfig = EnhancedConfig;
  globalThis.PerformanceMonitor = PerformanceMonitor;
  globalThis.NotificationManager = NotificationManager;
  globalThis.DataCleaner = DataCleaner;
} else if (typeof window !== 'undefined') {
  // 浏览器环境
  window.EnhancedConfig = EnhancedConfig;
  window.PerformanceMonitor = PerformanceMonitor;
  window.NotificationManager = NotificationManager;
  window.DataCleaner = DataCleaner;
}
