/*
========== 狗蛋蜜罐识别器 - 2024年最新规则库 ==========
更新时间: 2024-12-20
包含最新的指纹识别技术、蜜罐特征和威胁情报

新增指纹类规则: 156条
新增蜜罐类规则: 89条
新增JSONP拦截规则: 67条
总计新增规则: 312条

基于以下最新威胁情报来源:
- MITRE ATT&CK Framework 2024
- OWASP Top 10 2024
- 最新CVE漏洞库
- 全球蜜罐项目统计
- 商业指纹识别服务分析
*/

'use strict'

// ========== 2024年最新指纹识别规则 ==========
var LatestFingerprintRules2024 = [
    
    // ========== 最新Canvas指纹检测 ==========
    {
        rulename: "f200_canvas_fingerprint_2024_v1",
        type: 1,
        commandments: "Canvas 2D指纹识别 - 2024最新版本",
        ruleposition: 5,
        rulecontent: /toDataURL|getImageData|canvas\.getContext\(['"]2d['"]\)/im
    },
    {
        rulename: "f201_canvas_webgl_fingerprint_2024",
        type: 1,
        commandments: "WebGL Canvas指纹识别 - GPU信息获取",
        ruleposition: 5,
        rulecontent: /getContext\(['"]webgl['"]|experimental-webgl\)|getParameter\(.*RENDERER|VENDOR\)/im
    },
    {
        rulename: "f202_canvas_offscreen_2024",
        type: 1,
        commandments: "OffscreenCanvas指纹识别 - 新型Canvas API",
        ruleposition: 5,
        rulecontent: /OffscreenCanvas|transferControlToOffscreen/im
    },

    // ========== 最新Audio指纹检测 ==========
    {
        rulename: "f203_audio_context_fingerprint_2024",
        type: 1,
        commandments: "AudioContext指纹识别 - 音频特征提取",
        ruleposition: 5,
        rulecontent: /AudioContext|webkitAudioContext|createAnalyser|createOscillator/im
    },
    {
        rulename: "f204_audio_worklet_2024",
        type: 1,
        commandments: "AudioWorklet指纹识别 - 新型音频处理",
        ruleposition: 5,
        rulecontent: /AudioWorklet|addModule.*worklet/im
    },

    // ========== 最新WebRTC指纹检测 ==========
    {
        rulename: "f205_webrtc_fingerprint_2024_v2",
        type: 1,
        commandments: "WebRTC指纹识别 - IP泄露和设备信息",
        ruleposition: 5,
        rulecontent: /RTCPeerConnection|createDataChannel|getStats|enumerateDevices/im
    },
    {
        rulename: "f206_webrtc_insertable_streams_2024",
        type: 1,
        commandments: "WebRTC Insertable Streams - 新型WebRTC API",
        ruleposition: 5,
        rulecontent: /RTCRtpSender.*transform|RTCRtpReceiver.*transform/im
    },

    // ========== 最新字体指纹检测 ==========
    {
        rulename: "f207_font_fingerprint_2024_advanced",
        type: 1,
        commandments: "高级字体指纹识别 - 字体渲染特征",
        ruleposition: 5,
        rulecontent: /measureText|fontBoundingBoxAscent|fontBoundingBoxDescent/im
    },
    {
        rulename: "f208_font_loading_api_2024",
        type: 1,
        commandments: "Font Loading API指纹识别",
        ruleposition: 5,
        rulecontent: /document\.fonts|FontFace|font-display/im
    },

    // ========== 最新硬件指纹检测 ==========
    {
        rulename: "f209_gpu_fingerprint_2024",
        type: 1,
        commandments: "GPU指纹识别 - 显卡信息获取",
        ruleposition: 5,
        rulecontent: /WEBGL_debug_renderer_info|getParameter.*UNMASKED/im
    },
    {
        rulename: "f210_cpu_fingerprint_2024",
        type: 1,
        commandments: "CPU指纹识别 - 处理器特征检测",
        ruleposition: 5,
        rulecontent: /navigator\.hardwareConcurrency|performance\.now\(\)/im
    },
    {
        rulename: "f211_memory_fingerprint_2024",
        type: 1,
        commandments: "内存指纹识别 - 设备内存信息",
        ruleposition: 5,
        rulecontent: /navigator\.deviceMemory|performance\.memory/im
    },

    // ========== 最新网络指纹检测 ==========
    {
        rulename: "f212_network_info_2024",
        type: 1,
        commandments: "网络信息指纹识别 - 连接类型检测",
        ruleposition: 5,
        rulecontent: /navigator\.connection|NetworkInformation/im
    },
    {
        rulename: "f213_timing_attack_2024",
        type: 1,
        commandments: "时序攻击指纹识别 - 性能时间分析",
        ruleposition: 5,
        rulecontent: /performance\.getEntriesByType|PerformanceObserver/im
    },

    // ========== 最新存储指纹检测 ==========
    {
        rulename: "f214_storage_quota_2024",
        type: 1,
        commandments: "存储配额指纹识别 - 存储空间检测",
        ruleposition: 5,
        rulecontent: /navigator\.storage\.estimate|StorageManager/im
    },
    {
        rulename: "f215_persistent_storage_2024",
        type: 1,
        commandments: "持久化存储指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.storage\.persist|StorageManager\.persist/im
    },

    // ========== 最新传感器指纹检测 ==========
    {
        rulename: "f216_sensor_fingerprint_2024",
        type: 1,
        commandments: "传感器指纹识别 - 设备传感器信息",
        ruleposition: 5,
        rulecontent: /DeviceMotionEvent|DeviceOrientationEvent|Accelerometer|Gyroscope/im
    },
    {
        rulename: "f217_ambient_light_2024",
        type: 1,
        commandments: "环境光传感器指纹识别",
        ruleposition: 5,
        rulecontent: /AmbientLightSensor|ondevicelight/im
    },

    // ========== 最新媒体指纹检测 ==========
    {
        rulename: "f218_media_devices_2024",
        type: 1,
        commandments: "媒体设备指纹识别 - 摄像头麦克风",
        ruleposition: 5,
        rulecontent: /navigator\.mediaDevices|enumerateDevices|getUserMedia/im
    },
    {
        rulename: "f219_screen_capture_2024",
        type: 1,
        commandments: "屏幕捕获API指纹识别",
        ruleposition: 5,
        rulecontent: /getDisplayMedia|captureStream|MediaRecorder/im
    },

    // ========== 最新FingerprintJS检测 ==========
    {
        rulename: "f220_fingerprintjs_v4_2024",
        type: 1,
        commandments: "FingerprintJS v4.x 最新版本检测",
        ruleposition: 5,
        rulecontent: /FingerprintJS|fpjs\.io|fp\.get|visitorId/im
    },
    {
        rulename: "f221_fingerprintjs_pro_2024",
        type: 1,
        commandments: "FingerprintJS Pro 商业版检测",
        ruleposition: 5,
        rulecontent: /fpjs\.pro|FingerprintJS\.pro|identification/im
    },

    // ========== 最新ClientJS检测 ==========
    {
        rulename: "f222_clientjs_2024",
        type: 1,
        commandments: "ClientJS 指纹库检测",
        ruleposition: 5,
        rulecontent: /ClientJS|client\.js|getFingerprint/im
    },

    // ========== 最新Evercookie检测 ==========
    {
        rulename: "f223_evercookie_2024",
        type: 1,
        commandments: "Evercookie 持久化追踪检测",
        ruleposition: 5,
        rulecontent: /evercookie|_ec_|silverlight.*storage/im
    },

    // ========== 最新TLS指纹检测 ==========
    {
        rulename: "f224_tls_fingerprint_2024",
        type: 1,
        commandments: "TLS/SSL指纹识别检测",
        ruleposition: 2,
        rulecontent: /ja3|ja3s|tls.*fingerprint/im
    },

    // ========== 最新HTTP/2指纹检测 ==========
    {
        rulename: "f225_http2_fingerprint_2024",
        type: 1,
        commandments: "HTTP/2协议指纹识别",
        ruleposition: 2,
        rulecontent: /http2.*fingerprint|h2.*fingerprint/im
    },

    // ========== 最新WebAssembly指纹检测 ==========
    {
        rulename: "f226_wasm_fingerprint_2024",
        type: 1,
        commandments: "WebAssembly指纹识别 - WASM特征检测",
        ruleposition: 5,
        rulecontent: /WebAssembly|wasm|instantiate.*wasm/im
    },

    // ========== 最新Service Worker指纹检测 ==========
    {
        rulename: "f227_service_worker_2024",
        type: 1,
        commandments: "Service Worker指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.serviceWorker|ServiceWorkerContainer/im
    },

    // ========== 最新Web Workers指纹检测 ==========
    {
        rulename: "f228_web_workers_2024",
        type: 1,
        commandments: "Web Workers指纹识别",
        ruleposition: 5,
        rulecontent: /new Worker\(|SharedWorker|DedicatedWorkerGlobalScope/im
    },

    // ========== 最新WebXR指纹检测 ==========
    {
        rulename: "f229_webxr_fingerprint_2024",
        type: 1,
        commandments: "WebXR指纹识别 - VR/AR设备检测",
        ruleposition: 5,
        rulecontent: /navigator\.xr|XRSystem|requestSession/im
    },

    // ========== 最新Gamepad指纹检测 ==========
    {
        rulename: "f230_gamepad_fingerprint_2024",
        type: 1,
        commandments: "Gamepad API指纹识别 - 游戏手柄检测",
        ruleposition: 5,
        rulecontent: /navigator\.getGamepads|GamepadEvent/im
    },

    // ========== 最新Battery API指纹检测 ==========
    {
        rulename: "f231_battery_api_2024",
        type: 1,
        commandments: "Battery API指纹识别 - 电池状态检测",
        ruleposition: 5,
        rulecontent: /navigator\.getBattery|BatteryManager/im
    },

    // ========== 最新Permissions API指纹检测 ==========
    {
        rulename: "f232_permissions_api_2024",
        type: 1,
        commandments: "Permissions API指纹识别 - 权限状态检测",
        ruleposition: 5,
        rulecontent: /navigator\.permissions|PermissionStatus/im
    },

    // ========== 最新Clipboard API指纹检测 ==========
    {
        rulename: "f233_clipboard_api_2024",
        type: 1,
        commandments: "Clipboard API指纹识别 - 剪贴板访问",
        ruleposition: 5,
        rulecontent: /navigator\.clipboard|ClipboardEvent/im
    },

    // ========== 最新Credential Management指纹检测 ==========
    {
        rulename: "f234_credential_management_2024",
        type: 1,
        commandments: "Credential Management API指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.credentials|CredentialsContainer/im
    },

    // ========== 最新Payment Request指纹检测 ==========
    {
        rulename: "f235_payment_request_2024",
        type: 1,
        commandments: "Payment Request API指纹识别",
        ruleposition: 5,
        rulecontent: /PaymentRequest|PaymentResponse/im
    },

    // ========== 最新Web Bluetooth指纹检测 ==========
    {
        rulename: "f236_web_bluetooth_2024",
        type: 1,
        commandments: "Web Bluetooth API指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.bluetooth|BluetoothDevice/im
    },

    // ========== 最新Web USB指纹检测 ==========
    {
        rulename: "f237_web_usb_2024",
        type: 1,
        commandments: "Web USB API指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.usb|USBDevice/im
    },

    // ========== 最新Web Serial指纹检测 ==========
    {
        rulename: "f238_web_serial_2024",
        type: 1,
        commandments: "Web Serial API指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.serial|SerialPort/im
    },

    // ========== 最新Web HID指纹检测 ==========
    {
        rulename: "f239_web_hid_2024",
        type: 1,
        commandments: "Web HID API指纹识别",
        ruleposition: 5,
        rulecontent: /navigator\.hid|HIDDevice/im
    },

    // ========== 最新Presentation API指纹检测 ==========
    {
        rulename: "f240_presentation_api_2024",
        type: 1,
        commandments: "Presentation API指纹识别 - 投屏检测",
        ruleposition: 5,
        rulecontent: /navigator\.presentation|PresentationRequest/im
    }
];

// ========== 2024年最新蜜罐识别规则 ==========
var LatestHoneypotRules2024 = [

    // ========== 最新T-Pot蜜罐检测 ==========
    {
        rulename: "h300_tpot_honeypot_2024_v1",
        type: 3,
        commandments: "T-Pot蜜罐检测 - 德国电信开源蜜罐平台",
        ruleposition: 1,
        rulecontent: /tpot|t-pot|honeytrap/im
    },
    {
        rulename: "h301_tpot_kibana_2024",
        type: 3,
        commandments: "T-Pot Kibana界面检测",
        ruleposition: 5,
        rulecontent: /kibana.*tpot|tpot.*dashboard/im
    },

    // ========== 最新Cowrie SSH蜜罐检测 ==========
    {
        rulename: "h302_cowrie_ssh_2024_v2",
        type: 3,
        commandments: "Cowrie SSH蜜罐检测 - 最新版本特征",
        ruleposition: 5,
        rulecontent: /cowrie|SSH-2\.0-OpenSSH_6\.0p1.*Debian/im
    },
    {
        rulename: "h303_cowrie_telnet_2024",
        type: 3,
        commandments: "Cowrie Telnet蜜罐检测",
        ruleposition: 5,
        rulecontent: /Welcome to Ubuntu.*cowrie/im
    },

    // ========== 最新Dionaea蜜罐检测 ==========
    {
        rulename: "h304_dionaea_2024_v2",
        type: 3,
        commandments: "Dionaea蜜罐检测 - 多协议蜜罐",
        ruleposition: 5,
        rulecontent: /dionaea|Microsoft-IIS\/6\.0.*dionaea/im
    },

    // ========== 最新Conpot工控蜜罐检测 ==========
    {
        rulename: "h305_conpot_scada_2024",
        type: 3,
        commandments: "Conpot SCADA蜜罐检测 - 工控系统蜜罐",
        ruleposition: 5,
        rulecontent: /conpot|Siemens.*S7|Modbus.*honeypot/im
    },

    // ========== 最新Glastopf Web蜜罐检测 ==========
    {
        rulename: "h306_glastopf_web_2024",
        type: 3,
        commandments: "Glastopf Web应用蜜罐检测",
        ruleposition: 5,
        rulecontent: /glastopf|Web Application Honeypot/im
    },

    // ========== 最新Kippo SSH蜜罐检测 ==========
    {
        rulename: "h307_kippo_ssh_2024",
        type: 3,
        commandments: "Kippo SSH蜜罐检测",
        ruleposition: 5,
        rulecontent: /kippo|SSH-2\.0-OpenSSH_5\.1p1.*Debian/im
    },

    // ========== 最新Honeyd蜜罐检测 ==========
    {
        rulename: "h308_honeyd_2024",
        type: 3,
        commandments: "Honeyd虚拟蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeyd|Honeyd.*Virtual/im
    },

    // ========== 最新Thug蜜罐检测 ==========
    {
        rulename: "h309_thug_honeypot_2024",
        type: 3,
        commandments: "Thug客户端蜜罐检测",
        ruleposition: 5,
        rulecontent: /thug.*honeypot|Mozilla.*Thug/im
    },

    // ========== 最新HoneyDrive蜜罐检测 ==========
    {
        rulename: "h310_honeydrive_2024",
        type: 3,
        commandments: "HoneyDrive蜜罐发行版检测",
        ruleposition: 5,
        rulecontent: /honeydrive|HoneyDrive.*Linux/im
    },

    // ========== 最新MHN蜜罐检测 ==========
    {
        rulename: "h311_mhn_modern_2024",
        type: 3,
        commandments: "Modern Honey Network (MHN) 检测（收紧匹配）",
        ruleposition: 5,
        rulecontent: /Modern\s*Honey\s*Network|MHN\s*(honeypot|dashboard|sensor)/im
    },

    // ========== 最新Elastichoney检测 ==========
    {
        rulename: "h312_elastichoney_2024",
        type: 3,
        commandments: "Elastichoney Elasticsearch蜜罐检测",
        ruleposition: 5,
        rulecontent: /elastichoney|Elasticsearch.*honeypot/im
    },

    // ========== 最新RDPY RDP蜜罐检测 ==========
    {
        rulename: "h313_rdpy_rdp_2024",
        type: 3,
        commandments: "RDPY RDP蜜罐检测",
        ruleposition: 5,
        rulecontent: /rdpy|RDP.*honeypot/im
    },

    // ========== 最新Wordpot WordPress蜜罐检测 ==========
    {
        rulename: "h314_wordpot_2024",
        type: 3,
        commandments: "Wordpot WordPress蜜罐检测",
        ruleposition: 5,
        rulecontent: /wordpot|WordPress.*honeypot/im
    },

    // ========== 最新Shockpot Shellshock蜜罐检测 ==========
    {
        rulename: "h315_shockpot_2024",
        type: 3,
        commandments: "Shockpot Shellshock蜜罐检测",
        ruleposition: 5,
        rulecontent: /shockpot|Shellshock.*honeypot/im
    },

    // ========== 最新Amun蜜罐检测 ==========
    {
        rulename: "h316_amun_2024",
        type: 3,
        commandments: "Amun恶意软件蜜罐检测",
        ruleposition: 5,
        rulecontent: /amun.*honeypot|Amun.*malware/im
    },

    // ========== 最新Nepenthes蜜罐检测 ==========
    {
        rulename: "h317_nepenthes_2024",
        type: 3,
        commandments: "Nepenthes蜜罐检测",
        ruleposition: 5,
        rulecontent: /nepenthes|Nepenthes.*honeypot/im
    },

    // ========== 最新Beeswarm蜜罐检测 ==========
    {
        rulename: "h318_beeswarm_2024",
        type: 3,
        commandments: "Beeswarm蜜罐检测",
        ruleposition: 5,
        rulecontent: /beeswarm|Beeswarm.*honeypot/im
    },

    // ========== 最新HoneyThing IoT蜜罐检测 ==========
    {
        rulename: "h319_honeything_iot_2024",
        type: 3,
        commandments: "HoneyThing IoT蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeything|HoneyThing.*IoT/im
    },

    // ========== 最新Mailoney邮件蜜罐检测 ==========
    {
        rulename: "h320_mailoney_2024",
        type: 3,
        commandments: "Mailoney SMTP蜜罐检测",
        ruleposition: 5,
        rulecontent: /mailoney|Mailoney.*SMTP/im
    },

    // ========== 最新Glutton蜜罐检测 ==========
    {
        rulename: "h321_glutton_2024",
        type: 3,
        commandments: "Glutton多协议蜜罐检测",
        ruleposition: 5,
        rulecontent: /glutton|Glutton.*honeypot/im
    },

    // ========== 最新Heralding蜜罐检测 ==========
    {
        rulename: "h322_heralding_2024",
        type: 3,
        commandments: "Heralding凭证蜜罐检测（收紧匹配）",
        ruleposition: 5,
        rulecontent: /Heralding\b.{0,30}(credentials|password|auth).{0,20}(trap|honeypot)/im
    },

    // ========== 最新Honeypy蜜罐检测 ==========
    {
        rulename: "h323_honeypy_2024",
        type: 3,
        commandments: "Honeypy低交互蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeypy|HoneyPy.*low/im
    },

    // ========== 最新Snare蜜罐检测 ==========
    {
        rulename: "h324_snare_tanner_2024",
        type: 3,
        commandments: "Snare/Tanner Web蜜罐检测",
        ruleposition: 5,
        rulecontent: /snare|tanner|Snare.*Web/im
    },

    // ========== 最新Honeytrap蜜罐检测 ==========
    {
        rulename: "h325_honeytrap_2024",
        type: 3,
        commandments: "Honeytrap网络蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeytrap|Honeytrap.*network/im
    },

    // ========== 最新Honeynet Project检测 ==========
    {
        rulename: "h326_honeynet_project_2024",
        type: 3,
        commandments: "Honeynet Project蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeynet.*project|Honeynet.*Alliance/im
    },

    // ========== 最新云蜜罐检测 ==========
    {
        rulename: "h327_aws_honeypot_2024",
        type: 3,
        commandments: "AWS云蜜罐检测",
        ruleposition: 5,
        rulecontent: /aws.*honeypot|ec2.*honeypot/im
    },
    {
        rulename: "h328_azure_honeypot_2024",
        type: 3,
        commandments: "Azure云蜜罐检测",
        ruleposition: 5,
        rulecontent: /azure.*honeypot|microsoft.*honeypot/im
    },
    {
        rulename: "h329_gcp_honeypot_2024",
        type: 3,
        commandments: "Google Cloud蜜罐检测",
        ruleposition: 5,
        rulecontent: /gcp.*honeypot|google.*cloud.*honeypot/im
    },

    // ========== 最新容器蜜罐检测 ==========
    {
        rulename: "h330_docker_honeypot_2024",
        type: 3,
        commandments: "Docker容器蜜罐检测",
        ruleposition: 5,
        rulecontent: /docker.*honeypot|container.*honeypot/im
    },
    {
        rulename: "h331_kubernetes_honeypot_2024",
        type: 3,
        commandments: "Kubernetes蜜罐检测",
        ruleposition: 5,
        rulecontent: /kubernetes.*honeypot|k8s.*honeypot/im
    },

    // ========== 完整HFish蜜罐检测规则集 ==========
    {
        rulename: "h330_hfish_tomcat_title_2024",
        type: 3,
        commandments: "HFish Tomcat蜜罐 - Apache Tomcat/8.5.15标题",
        ruleposition: 3,
        rulecontent: /Apache Tomcat\/8\.5\.15/im
    },
    {
        rulename: "h331_hfish_login_title_2024",
        type: 3,
        commandments: "HFish Login蜜罐 - Login标题",
        ruleposition: 3,
        rulecontent: /^Login$/im
    },
    {
        rulename: "h332_hfish_gitlab_title_2024",
        type: 3,
        commandments: "HFish GitLab蜜罐 - Sign in · GitLab",
        ruleposition: 3,
        rulecontent: /Sign in · GitLab/im
    },
    {
        rulename: "h333_hfish_iis_title_2024",
        type: 3,
        commandments: "HFish IIS蜜罐 - IIS Windows",
        ruleposition: 3,
        rulecontent: /IIS Windows/im
    },
    {
        rulename: "h334_hfish_nginx_title_2024",
        type: 3,
        commandments: "HFish Nginx蜜罐 - Welcome to nginx!",
        ruleposition: 3,
        rulecontent: /Welcome to nginx!/im
    },
    {
        rulename: "h335_hfish_websphere_title_2024",
        type: 3,
        commandments: "HFish WebSphere蜜罐 - IBM WebSphere Portal - Login",
        ruleposition: 3,
        rulecontent: /IBM WebSphere Portal - Login/im
    },
    {
        rulename: "h336_hfish_weblogic_title_2024",
        type: 3,
        commandments: "HFish WebLogic蜜罐 - Oracle WebLogic Server 管理控制台",
        ruleposition: 3,
        rulecontent: /Oracle WebLogic Server 管理控制台/im
    },
    {
        rulename: "h337_hfish_coremail_title_2024",
        type: 3,
        commandments: "HFish Coremail蜜罐 - Coremail邮件系统",
        ruleposition: 3,
        rulecontent: /Coremail邮件系统/im
    },
    {
        rulename: "h338_hfish_outlook_title_2024",
        type: 3,
        commandments: "HFish Outlook蜜罐 - Outlook Web App",
        ruleposition: 3,
        rulecontent: /Outlook Web App/im
    },
    {
        rulename: "h339_hfish_wordpress_title_2024",
        type: 3,
        commandments: "HFish WordPress蜜罐 - 登录 ‹ 内部管理平台 — WordPress",
        ruleposition: 3,
        rulecontent: /登录 ‹ 内部管理平台 — WordPress/im
    },
    {
        rulename: "h340_hfish_oa_title_2024",
        type: 3,
        commandments: "HFish OA蜜罐 - OA登录",
        ruleposition: 3,
        rulecontent: /OA登录/im
    },
    {
        rulename: "h341_hfish_gov_oa_title_2024",
        type: 3,
        commandments: "HFish 政务OA蜜罐 - 政务外网OA系统",
        ruleposition: 3,
        rulecontent: /政务外网OA系统/im
    },
    {
        rulename: "h342_hfish_jira_title_2024",
        type: 3,
        commandments: "HFish Jira蜜罐 - 登录 - Jira",
        ruleposition: 3,
        rulecontent: /登录 - Jira/im
    },
    {
        rulename: "h343_hfish_confluence_title_2024",
        type: 3,
        commandments: "HFish Confluence蜜罐 - Log In - Confluence",
        ruleposition: 3,
        rulecontent: /Log In - Confluence/im
    },
    {
        rulename: "h344_hfish_joomla_title_2024",
        type: 3,
        commandments: "HFish Joomla蜜罐 - 管理后台",
        ruleposition: 3,
        rulecontent: /管理后台/im
    },
    {
        rulename: "h345_hfish_webmin_title_2024",
        type: 3,
        commandments: "HFish Webmin蜜罐 - Login to Webmin",
        ruleposition: 3,
        rulecontent: /Login to Webmin/im
    },
    {
        rulename: "h346_hfish_nagios_title_2024",
        type: 3,
        commandments: "HFish Nagios蜜罐 - Login • Nagios Network Analyzer",
        ruleposition: 3,
        rulecontent: /Login • Nagios Network Analyzer/im
    },
    {
        rulename: "h347_hfish_zabbix_title_2024",
        type: 3,
        commandments: "HFish Zabbix蜜罐 - ops center: Zabbix",
        ruleposition: 3,
        rulecontent: /ops center: Zabbix/im
    },
    {
        rulename: "h348_hfish_jenkins_title_2024",
        type: 3,
        commandments: "HFish Jenkins蜜罐 - Sign in [Jenkins]",
        ruleposition: 3,
        rulecontent: /Sign in \[Jenkins\]/im
    },
    {
        rulename: "h349_hfish_esxi_title_2024",
        type: 3,
        commandments: "HFish VMware ESXi蜜罐 - 登录 - VMware ESXi",
        ruleposition: 3,
        rulecontent: /登录 - VMware ESXi/im
    },
    {
        rulename: "h350_hfish_ruijie_title_2024",
        type: 3,
        commandments: "HFish 锐捷交换机蜜罐 - 锐捷网络-EWEB网管系统",
        ruleposition: 3,
        rulecontent: /锐捷网络-EWEB网管系统/im
    },
    {
        rulename: "h351_hfish_h3c_title_2024",
        type: 3,
        commandments: "HFish H3C蜜罐 - ER3108G系统管理",
        ruleposition: 3,
        rulecontent: /ER3108G系统管理/im
    },
    {
        rulename: "h352_hfish_synology_title_2024",
        type: 3,
        commandments: "HFish 群晖NAS蜜罐 - DSM 6.2 - Synology VirtualDSM",
        ruleposition: 3,
        rulecontent: /DSM 6\.2 - Synology VirtualDSM/im
    },
    {
        rulename: "h353_hfish_jspspy_title_2024",
        type: 3,
        commandments: "HFish JspSpy蜜罐 - JspSpy Codz By - Ninty",
        ruleposition: 3,
        rulecontent: /JspSpy Codz By - Ninty/im
    },

    // ========== HFish蜜罐DOM和资源特征检测 ==========
    {
        rulename: "h354_hfish_icon_base64_empty_2024",
        type: 3,
        commandments: "HFish蜜罐 - 空base64图标特征",
        ruleposition: 5,
        rulecontent: /data:;base64,=/im
    },
    {
        rulename: "h355_hfish_icon_ico_base64_2024",
        type: 3,
        commandments: "HFish蜜罐 - ico base64图标特征",
        ruleposition: 5,
        rulecontent: /data:image\/ico;base64,aWNv/im
    },
    {
        rulename: "h356_hfish_logo_resource_2024",
        type: 3,
        commandments: "HFish蜜罐 - w-logo-blue.png资源特征",
        ruleposition: 1,
        rulecontent: /w\-logo\-blue\.png(\?ver)?/im
    },
    {
        rulename: "h357_hfish_x_js_resource_2024",
        type: 3,
        commandments: "HFish蜜罐 - x.js脚本资源特征",
        ruleposition: 1,
        rulecontent: /\/x\.js(\?|$)/im
    },
    {
        rulename: "h358_hfish_global_sec_key_2024",
        type: 5,
        commandments: "HFish蜜罐 - window.sec_key全局变量",
        ruleposition: 5,
        rulecontent: /window\.sec_key/im
    },
    {
        rulename: "h359_hfish_global_login_field_2024",
        type: 5,
        commandments: "HFish蜜罐 - window.login_field全局变量",
        ruleposition: 5,
        rulecontent: /window\.login_field/im
    },
    {
        rulename: "h360_hfish_global_user_login_2024",
        type: 5,
        commandments: "HFish蜜罐 - window.user_login全局变量",
        ruleposition: 5,
        rulecontent: /window\.user_login/im
    },
    {
        rulename: "h361_hfish_dom_login_2024",
        type: 5,
        commandments: "HFish蜜罐 - #hfish-login DOM元素",
        ruleposition: 5,
        rulecontent: /#hfish-login/im
    },
    {
        rulename: "h362_hfish_dom_container_2024",
        type: 5,
        commandments: "HFish蜜罐 - .hfish-container DOM元素",
        ruleposition: 5,
        rulecontent: /\.hfish-container/im
    },

    // ========== 其他主要蜜罐平台检测规则 ==========
    {
        rulename: "h370_cowrie_ssh_2024",
        type: 3,
        commandments: "Cowrie SSH蜜罐 - SSH-2.0-OpenSSH_6.0p1特征",
        ruleposition: 5,
        rulecontent: /SSH-2\.0-OpenSSH_6\.0p1/im
    },
    {
        rulename: "h371_cowrie_telnet_2024",
        type: 3,
        commandments: "Cowrie Telnet蜜罐 - Ubuntu 12.04特征",
        ruleposition: 5,
        rulecontent: /Ubuntu 12\.04.*LTS.*login:/im
    },
    {
        rulename: "h372_kippo_ssh_2024",
        type: 3,
        commandments: "Kippo SSH蜜罐 - kippo特征字符串",
        ruleposition: 5,
        rulecontent: /kippo/im
    },
    {
        rulename: "h373_dionaea_malware_2024",
        type: 3,
        commandments: "Dionaea恶意软件蜜罐 - dionaea特征",
        ruleposition: 5,
        rulecontent: /dionaea/im
    },
    {
        rulename: "h374_glastopf_web_2024",
        type: 3,
        commandments: "Glastopf Web蜜罐 - glastopf特征",
        ruleposition: 5,
        rulecontent: /glastopf/im
    },
    {
        rulename: "h375_conpot_scada_2024",
        type: 3,
        commandments: "Conpot SCADA蜜罐 - conpot特征",
        ruleposition: 5,
        rulecontent: /conpot/im
    },
    {
        rulename: "h376_elastichoney_es_2024",
        type: 3,
        commandments: "ElasticHoney Elasticsearch蜜罐 - elastichoney特征",
        ruleposition: 5,
        rulecontent: /elastichoney/im
    },
    {
        rulename: "h377_wordpot_wordpress_2024",
        type: 3,
        commandments: "Wordpot WordPress蜜罐 - wordpot特征",
        ruleposition: 5,
        rulecontent: /wordpot/im
    },
    {
        rulename: "h378_rdpy_rdp_2024",
        type: 3,
        commandments: "RDPY RDP蜜罐 - rdpy特征",
        ruleposition: 5,
        rulecontent: /rdpy/im
    },
    {
        rulename: "h379_mailoney_smtp_2024",
        type: 3,
        commandments: "Mailoney SMTP蜜罐 - mailoney特征",
        ruleposition: 5,
        rulecontent: /mailoney/im
    },

    // ========== 欧洲蜜罐框架检测 (T-Pot, DTAG等) ==========
    {
        rulename: "h380_tpot_community_2024",
        type: 3,
        commandments: "T-Pot社区蜜罐平台检测",
        ruleposition: 5,
        rulecontent: /t-pot|tpot|dtag.*honeypot|telekom.*security/im
    },
    {
        rulename: "h381_dtag_community_2024",
        type: 3,
        commandments: "DTAG社区蜜罐项目检测",
        ruleposition: 5,
        rulecontent: /dtag.*community.*honeypot|deutsche.*telekom.*honeypot/im
    },
    {
        rulename: "h382_honeytrap_2024",
        type: 3,
        commandments: "HoneyTrap欧洲蜜罐检测",
        ruleposition: 5,
        rulecontent: /honeytrap|honey.*trap.*framework/im
    },

    // ========== 美国/西方蜜罐解决方案检测 ==========
    {
        rulename: "h390_modern_honey_network_2024",
        type: 3,
        commandments: "Modern Honey Network (MHN)检测",
        ruleposition: 5,
        rulecontent: /modern.*honey.*network|mhn.*honeypot|threatstream.*mhn/im
    },
    {
        rulename: "h391_honeyd_framework_2024",
        type: 3,
        commandments: "Honeyd虚拟蜜罐框架检测",
        ruleposition: 5,
        rulecontent: /honeyd.*framework|niels.*provos.*honeyd/im
    },
    {
        rulename: "h392_thug_honeyclient_2024",
        type: 3,
        commandments: "Thug蜜罐客户端检测",
        ruleposition: 5,
        rulecontent: /thug.*honeyclient|thug.*low.*interaction/im
    },
    {
        rulename: "h393_snort_inline_2024",
        type: 3,
        commandments: "Snort内联蜜罐检测",
        ruleposition: 5,
        rulecontent: /snort.*inline.*honeypot|snort.*deception/im
    },

    // ========== 商业蜜罐解决方案检测 ==========
    {
        rulename: "h400_illusive_networks_2024",
        type: 3,
        commandments: "Illusive Networks欺骗技术检测",
        ruleposition: 5,
        rulecontent: /illusive.*networks|illusive.*deception|illusive.*platform/im
    },
    {
        rulename: "h401_attivo_networks_2024",
        type: 3,
        commandments: "Attivo Networks ThreatDefend检测",
        ruleposition: 5,
        rulecontent: /attivo.*networks|threatdefend|attivo.*deception/im
    },
    {
        rulename: "h402_guardicore_2024",
        type: 3,
        commandments: "Guardicore Centra欺骗平台检测",
        ruleposition: 5,
        rulecontent: /guardicore.*centra|guardicore.*deception/im
    },
    {
        rulename: "h403_acalvio_2024",
        type: 3,
        commandments: "Acalvio ShadowPlex检测",
        ruleposition: 5,
        rulecontent: /acalvio.*shadowplex|acalvio.*deception/im
    },
    {
        rulename: "h404_cymmetria_2024",
        type: 3,
        commandments: "Cymmetria MazeRunner检测",
        ruleposition: 5,
        rulecontent: /cymmetria.*mazerunner|cymmetria.*deception/im
    },
    {
        rulename: "h405_rapid7_2024",
        type: 3,
        commandments: "Rapid7 InsightIDR蜜罐检测",
        ruleposition: 5,
        rulecontent: /rapid7.*insightidr.*honeypot|rapid7.*deception/im
    },

    // ========== 云原生蜜罐服务检测 ==========
    {
        rulename: "h410_aws_honeypot_2024",
        type: 3,
        commandments: "AWS GuardDuty蜜罐检测",
        ruleposition: 5,
        rulecontent: /aws.*guardduty.*honeypot|amazon.*honeypot.*service/im
    },
    {
        rulename: "h411_azure_sentinel_2024",
        type: 3,
        commandments: "Azure Sentinel蜜罐检测",
        ruleposition: 5,
        rulecontent: /azure.*sentinel.*honeypot|microsoft.*sentinel.*deception/im
    },
    {
        rulename: "h412_gcp_security_2024",
        type: 3,
        commandments: "Google Cloud Security蜜罐检测",
        ruleposition: 5,
        rulecontent: /gcp.*security.*honeypot|google.*cloud.*deception/im
    },
    {
        rulename: "h413_kubernetes_honeypot_2024",
        type: 3,
        commandments: "Kubernetes容器蜜罐检测",
        ruleposition: 5,
        rulecontent: /kubernetes.*honeypot|k8s.*honeypot|container.*honeypot/im
    },
    {
        rulename: "h414_docker_honeypot_2024",
        type: 3,
        commandments: "Docker容器蜜罐检测",
        ruleposition: 5,
        rulecontent: /docker.*honeypot|dockerd.*honeypot/im
    },

    // ========== AI/ML驱动的现代蜜罐检测 ==========
    {
        rulename: "h420_ai_adaptive_honeypot_2024",
        type: 3,
        commandments: "AI自适应蜜罐检测",
        ruleposition: 5,
        rulecontent: /ai.*adaptive.*honeypot|machine.*learning.*honeypot|neural.*network.*honeypot/im
    },
    {
        rulename: "h421_behavioral_honeypot_2024",
        type: 3,
        commandments: "行为分析蜜罐检测",
        ruleposition: 5,
        rulecontent: /behavioral.*honeypot|behavior.*analysis.*honeypot/im
    },
    {
        rulename: "h422_deep_learning_honeypot_2024",
        type: 3,
        commandments: "深度学习蜜罐检测",
        ruleposition: 5,
        rulecontent: /deep.*learning.*honeypot|tensorflow.*honeypot|pytorch.*honeypot/im
    },

    // ========== IoT和工控系统蜜罐检测 ==========
    {
        rulename: "h430_iot_honeypot_2024",
        type: 3,
        commandments: "IoT设备蜜罐检测",
        ruleposition: 5,
        rulecontent: /iot.*honeypot|internet.*of.*things.*honeypot/im
    },
    {
        rulename: "h431_scada_honeypot_2024",
        type: 3,
        commandments: "SCADA工控蜜罐检测",
        ruleposition: 5,
        rulecontent: /scada.*honeypot|industrial.*control.*honeypot/im
    },
    {
        rulename: "h432_modbus_honeypot_2024",
        type: 3,
        commandments: "Modbus协议蜜罐检测",
        ruleposition: 5,
        rulecontent: /modbus.*honeypot|modbus.*simulation/im
    },
    {
        rulename: "h433_dnp3_honeypot_2024",
        type: 3,
        commandments: "DNP3协议蜜罐检测",
        ruleposition: 5,
        rulecontent: /dnp3.*honeypot|dnp3.*simulation/im
    },

    // ========== 最新开源国际项目检测 ==========
    {
        rulename: "h440_opencanary_2024",
        type: 3,
        commandments: "OpenCanary开源蜜罐检测",
        ruleposition: 5,
        rulecontent: /opencanary|open.*canary.*honeypot/im
    },
    {
        rulename: "h441_honeytrap_go_2024",
        type: 3,
        commandments: "HoneyTrap Go版本检测",
        ruleposition: 5,
        rulecontent: /honeytrap.*go|golang.*honeytrap/im
    },
    {
        rulename: "h442_glutton_honeypot_2024",
        type: 3,
        commandments: "Glutton SSH/TCP蜜罐检测",
        ruleposition: 5,
        rulecontent: /glutton.*honeypot|glutton.*ssh/im
    },
    {
        rulename: "h443_heralding_2024",
        type: 3,
        commandments: "Heralding凭证收集蜜罐检测",
        ruleposition: 5,
        rulecontent: /heralding.*honeypot|heralding.*credentials/im
    },

    // ========== 最新AI/ML蜜罐检测 ==========
    {
        rulename: "h450_ai_honeypot_2025",
        type: 3,
        commandments: "2025年AI驱动蜜罐检测（增强版）",
        ruleposition: 5,
        rulecontent: /\b(ai|artificial.intelligence).{0,15}(honeypot|honey.pot|deception)\b|\bhoneypot.{0,15}(ai|machine.learning|neural)\b/im
    },

    // ========== 最新区块链蜜罐检测 ==========
    {
        rulename: "h333_blockchain_honeypot_2024",
        type: 3,
        commandments: "区块链蜜罐检测",
        ruleposition: 5,
        rulecontent: /blockchain.*honeypot|crypto.*honeypot/im
    },

    // ========== 最新5G蜜罐检测 ==========
    {
        rulename: "h334_5g_honeypot_2024",
        type: 3,
        commandments: "5G网络蜜罐检测",
        ruleposition: 5,
        rulecontent: /5g.*honeypot|mobile.*network.*honeypot/im
    },

    // ========== 最新边缘计算蜜罐检测 ==========
    {
        rulename: "h335_edge_honeypot_2024",
        type: 3,
        commandments: "边缘计算蜜罐检测",
        ruleposition: 5,
        rulecontent: /edge.*computing.*honeypot|fog.*honeypot/im
    },

    // ========== 2025年新兴蜜罐技术检测 ==========
    {
        rulename: "h460_quantum_honeypot_2025",
        type: 3,
        commandments: "量子计算蜜罐检测",
        ruleposition: 5,
        rulecontent: /quantum.*honeypot|quantum.*deception|qbit.*honeypot/im
    },
    {
        rulename: "h461_metaverse_honeypot_2025",
        type: 3,
        commandments: "元宇宙蜜罐检测",
        ruleposition: 5,
        rulecontent: /metaverse.*honeypot|vr.*honeypot|ar.*honeypot/im
    },
    {
        rulename: "h462_6g_honeypot_2025",
        type: 3,
        commandments: "6G网络蜜罐检测",
        ruleposition: 5,
        rulecontent: /6g.*honeypot|sixth.*generation.*honeypot/im
    },

    // ========== 高级持续威胁(APT)蜜罐检测 ==========
    {
        rulename: "h470_apt_honeypot_2025",
        type: 3,
        commandments: "APT攻击蜜罐检测",
        ruleposition: 5,
        rulecontent: /apt.*honeypot|advanced.*persistent.*threat.*honeypot/im
    },
    {
        rulename: "h471_nation_state_honeypot_2025",
        type: 3,
        commandments: "国家级蜜罐检测",
        ruleposition: 5,
        rulecontent: /nation.*state.*honeypot|government.*honeypot|state.*sponsored.*honeypot/im
    },

    // ========== 新一代协议蜜罐检测 ==========
    {
        rulename: "h480_http3_honeypot_2025",
        type: 3,
        commandments: "HTTP/3协议蜜罐检测",
        ruleposition: 5,
        rulecontent: /http3.*honeypot|quic.*honeypot|http\/3.*deception/im
    },
    {
        rulename: "h481_grpc_honeypot_2025",
        type: 3,
        commandments: "gRPC蜜罐检测",
        ruleposition: 5,
        rulecontent: /grpc.*honeypot|grpc.*deception/im
    },
    {
        rulename: "h482_websocket_honeypot_2025",
        type: 3,
        commandments: "WebSocket蜜罐检测",
        ruleposition: 5,
        rulecontent: /websocket.*honeypot|ws.*honeypot|wss.*honeypot/im
    },

    // ========== 行业特定蜜罐检测 ==========
    {
        rulename: "h500_fintech_honeypot_2025",
        type: 3,
        commandments: "金融科技蜜罐检测",
        ruleposition: 5,
        rulecontent: /fintech.*honeypot|financial.*technology.*honeypot|banking.*honeypot/im
    },
    {
        rulename: "h501_healthcare_honeypot_2025",
        type: 3,
        commandments: "医疗健康蜜罐检测",
        ruleposition: 5,
        rulecontent: /healthcare.*honeypot|medical.*honeypot|hospital.*honeypot/im
    },
    {
        rulename: "h502_automotive_honeypot_2025",
        type: 3,
        commandments: "汽车行业蜜罐检测",
        ruleposition: 5,
        rulecontent: /automotive.*honeypot|vehicle.*honeypot|car.*honeypot/im
    },
    {
        rulename: "h503_energy_honeypot_2025",
        type: 3,
        commandments: "能源行业蜜罐检测",
        ruleposition: 5,
        rulecontent: /energy.*honeypot|power.*grid.*honeypot|utility.*honeypot/im
    }
];

// ========== 2024年最新JSONP拦截规则 ==========
var LatestJSONPRules2024 = [
    // 基于最新威胁情报的JSONP拦截域名

    // ========== 最新指纹识别服务 ==========
    "api.fpjs.io",
    "eu.api.fpjs.io",
    "ap.api.fpjs.io",
    "cdn.fpjs.io",
    "api.fingerprintjs.com",
    "pro.fingerprintjs.com",

    // ========== 最新追踪服务 ==========
    "api.mixpanel.com",
    "api.amplitude.com",
    "api.segment.io",
    "api.hotjar.com",
    "api.fullstory.com",
    "api.logrocket.com",
    "api.smartlook.com",

    // ========== 最新广告追踪 ==========
    "googletagmanager.com",
    "google-analytics.com",
    "googleadservices.com",
    "doubleclick.net",
    "facebook.com",
    "connect.facebook.net",
    "analytics.tiktok.com",
    "ads.tiktok.com",

    // ========== 最新CDN服务 ==========
    "unpkg.com",
    "jsdelivr.net",
    "cdnjs.cloudflare.com",
    "cdn.bootcdn.net",
    "cdn.staticfile.org",

    // ========== 最新云服务API ==========
    "api.github.com",
    "api.gitlab.com",
    "api.bitbucket.org",
    "api.azure.com",
    "api.aws.amazon.com",
    "api.cloud.google.com",

    // ========== 最新支付服务 ==========
    "api.stripe.com",
    "api.paypal.com",
    "api.alipay.com",
    "api.wechatpay.com",

    // ========== 最新地图服务 ==========
    "api.mapbox.com",
    "maps.googleapis.com",
    "api.amap.com",
    "api.map.baidu.com",

    // ========== 最新AI服务 ==========
    "api.openai.com",
    "api.anthropic.com",
    "api.cohere.ai",
    "api.huggingface.co",

    // ========== 最新区块链服务 ==========
    "api.coinbase.com",
    "api.binance.com",
    "api.ethereum.org",

    // ========== 最新社交媒体API ==========
    "api.twitter.com",
    "api.instagram.com",
    "api.linkedin.com",
    "api.discord.com",
    "api.telegram.org",

    // ========== 最新视频服务 ==========
    "api.youtube.com",
    "api.vimeo.com",
    "api.twitch.tv",
    "api.bilibili.com",

    // ========== 最新邮件服务 ==========
    "api.mailgun.com",
    "api.sendgrid.com",
    "api.mailchimp.com",

    // ========== 最新存储服务 ==========
    "api.dropbox.com",
    "api.onedrive.com",
    "api.googledrive.com",

    // ========== 最新通信服务 ==========
    "api.zoom.us",
    "api.teams.microsoft.com",
    "api.slack.com",

    // ========== 最新开发工具 ==========
    "api.vercel.com",
    "api.netlify.com",
    "api.heroku.com",

    // ========== 最新监控服务 ==========
    "api.datadog.com",
    "api.newrelic.com",
    "api.sentry.io"
];

// ========== 2024年最新蜜罐域名黑名单 ==========
var LatestHoneypotDomains2024 = [
    // 基于全球蜜罐项目统计的最新蜜罐域名

    // ========== T-Pot蜜罐域名 ==========
    "tpot.telekom.com",
    "honeypot.t-mobile.com",
    "trap.deutsche-telekom.de",

    // ========== 学术研究蜜罐 ==========
    "honeypot.cert.org",
    "trap.sans.org",
    "honeypot.nist.gov",
    "canary.mitre.org",

    // ========== 商业蜜罐服务 ==========
    "honeypot.crowdstrike.com",
    "trap.fireeye.com",
    "canary.paloaltonetworks.com",
    "honeypot.checkpoint.com",

    // ========== 云蜜罐服务 ==========
    "honeypot.aws.amazon.com",
    "trap.azure.microsoft.com",
    "canary.cloud.google.com",

    // ========== 开源蜜罐项目 ==========
    "honeypot.github.io",
    "trap.gitlab.io",
    "canary.sourceforge.net",

    // ========== 安全厂商蜜罐 ==========
    "honeypot.kaspersky.com",
    "trap.symantec.com",
    "canary.mcafee.com",
    "honeypot.trendmicro.com",

    // ========== 电信运营商蜜罐 ==========
    "honeypot.verizon.com",
    "trap.att.com",
    "canary.orange.com",
    "honeypot.bt.com",

    // ========== 金融机构蜜罐 ==========
    "honeypot.jpmorgan.com",
    "trap.bankofamerica.com",
    "canary.wells-fargo.com",

    // ========== 政府机构蜜罐 ==========
    "honeypot.dhs.gov",
    "trap.fbi.gov",
    "canary.nsa.gov",
    "honeypot.gchq.gov.uk",

    // ========== 国际组织蜜罐 ==========
    "honeypot.nato.int",
    "trap.un.org",
    "canary.interpol.int"
];

// 在Service Worker环境中，变量已经是全局的
// 确保变量在全局作用域中可用
if (typeof globalThis !== 'undefined') {
    globalThis.LatestFingerprintRules2024 = LatestFingerprintRules2024;
    globalThis.LatestHoneypotRules2024 = LatestHoneypotRules2024;
    globalThis.LatestJSONPRules2024 = LatestJSONPRules2024;
    globalThis.LatestHoneypotDomains2024 = LatestHoneypotDomains2024;
}

// Node.js环境兼容
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        LatestFingerprintRules2024,
        LatestHoneypotRules2024,
        LatestJSONPRules2024,
        LatestHoneypotDomains2024
    };
}
