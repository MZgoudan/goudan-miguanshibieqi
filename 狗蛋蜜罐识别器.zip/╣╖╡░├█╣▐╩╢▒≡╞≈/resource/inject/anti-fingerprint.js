/**
 * 狗蛋蜜罐识别器 - 反指纹识别模块
 * 整合AntiHoneypot的指纹对抗技术
 */

'use strict';

// 🔧 创建fingerprintDefenseManager对象，防止ReferenceError
window.fingerprintDefenseManager = window.fingerprintDefenseManager || {
  isEnabled: true,
  config: {
    canvas: true,
    webgl: true,
    audio: true,
    font: true,
    storage: true,
    clipboard: true,
    webrtc: true,
    mediaDevices: true,
    sensor: true,
    network: true,
    hardware: true,
    timing: true
  },
  stats: {
    canvasBlocked: 0,
    webglBlocked: 0,
    audioBlocked: 0,
    fontBlocked: 0,
    storageBlocked: 0,
    clipboardBlocked: 0,
    webrtcBlocked: 0,
    mediaDevicesBlocked: 0,
    sensorBlocked: 0,
    networkBlocked: 0,
    hardwareBlocked: 0,
    timingBlocked: 0
  },
  enable: function() {
    this.isEnabled = true;
    console.log('指纹防护已启用');
  },
  disable: function() {
    this.isEnabled = false;
    console.log('指纹防护已禁用');
  },
  getStats: function() {
    return this.stats;
  },
  resetStats: function() {
    Object.keys(this.stats).forEach(key => {
      this.stats[key] = 0;
    });
    console.log('指纹防护统计已重置');
  }
};

console.log('✅ fingerprintDefenseManager已创建');

// ========== Canvas指纹对抗 ==========
function initCanvasFingerprinting() {
  const originalToBlob = HTMLCanvasElement.prototype.toBlob;
  const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
  const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;

  // 随机噪声生成函数
  function addCanvasNoise(canvas, context) {
    if (!context) return;
    
    const shift = {
      'r': Math.floor(Math.random() * 10) - 5,
      'g': Math.floor(Math.random() * 10) - 5,
      'b': Math.floor(Math.random() * 10) - 5,
      'a': Math.floor(Math.random() * 10) - 5
    };

    const width = canvas.width;
    const height = canvas.height;
    const imageData = originalGetImageData.apply(context, [0, 0, width, height]);
    
    for (let i = 0; i < height; i++) {
      for (let j = 0; j < width; j++) {
        const n = ((i * (width * 4)) + (j * 4));
        imageData.data[n + 0] = Math.max(0, Math.min(255, imageData.data[n + 0] + shift.r));
        imageData.data[n + 1] = Math.max(0, Math.min(255, imageData.data[n + 1] + shift.g));
        imageData.data[n + 2] = Math.max(0, Math.min(255, imageData.data[n + 2] + shift.b));
        imageData.data[n + 3] = Math.max(0, Math.min(255, imageData.data[n + 3] + shift.a));
      }
    }

    context.putImageData(imageData, 0, 0);
    
    // 通知检测到Canvas指纹识别
    if (window.fingerprintDefenseManager) {
      window.fingerprintDefenseManager.stats.canvasBlocked++;
    }

    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "canvas",
        timestamp: Date.now()
      }
    }, '*');
  }

  // 重写toBlob方法
  Object.defineProperty(HTMLCanvasElement.prototype, "toBlob", {
    "value": function() {
      addCanvasNoise(this, this.getContext("2d"));
      return originalToBlob.apply(this, arguments);
    }
  });

  // 重写toDataURL方法
  Object.defineProperty(HTMLCanvasElement.prototype, "toDataURL", {
    "value": function() {
      addCanvasNoise(this, this.getContext("2d"));
      return originalToDataURL.apply(this, arguments);
    }
  });

  // 重写getImageData方法
  Object.defineProperty(CanvasRenderingContext2D.prototype, "getImageData", {
    "value": function() {
      addCanvasNoise(this.canvas, this);
      return originalGetImageData.apply(this, arguments);
    }
  });
}

// ========== WebGL指纹对抗 (2024增强版) ==========
function initWebGLFingerprinting() {
  const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
  const originalGetExtension = WebGLRenderingContext.prototype.getExtension;
  const originalGetShaderPrecisionFormat = WebGLRenderingContext.prototype.getShaderPrecisionFormat;

  // 重写getParameter方法 - 增强版
  WebGLRenderingContext.prototype.getParameter = function(parameter) {
    // 对敏感参数添加随机噪声
    if (parameter === this.RENDERER || parameter === this.VENDOR) {
      const original = originalGetParameter.apply(this, arguments);
      // 添加随机后缀来混淆指纹
      return original + ' (Enhanced)';
    }

    // 2024新增：对更多参数进行混淆
    if (parameter === this.UNMASKED_VENDOR_WEBGL || parameter === this.UNMASKED_RENDERER_WEBGL) {
      return 'Google Inc. (Enhanced)';
    }

    // 对版本信息进行混淆
    if (parameter === this.VERSION || parameter === this.SHADING_LANGUAGE_VERSION) {
      const original = originalGetParameter.apply(this, arguments);
      return original.replace(/\d+\.\d+/, '4.6');
    }

    return originalGetParameter.apply(this, arguments);
  };

  // 重写getShaderPrecisionFormat方法 - 2024新增
  WebGLRenderingContext.prototype.getShaderPrecisionFormat = function(shadertype, precisiontype) {
    const original = originalGetShaderPrecisionFormat.apply(this, arguments);
    // 标准化精度格式以防止指纹识别
    return {
      rangeMin: 127,
      rangeMax: 127,
      precision: 23
    };
  };

  // 通知检测到WebGL指纹识别
  WebGLRenderingContext.prototype.getExtension = function(name) {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "webgl",
        extension: name,
        timestamp: Date.now()
      }
    }, '*');
    return originalGetExtension.apply(this, arguments);
  };
}

// ========== AudioContext指纹对抗 ==========
function initAudioFingerprinting() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;

  const originalCreateAnalyser = AudioContext.prototype.createAnalyser;
  const originalCreateOscillator = AudioContext.prototype.createOscillator;

  // 重写createAnalyser方法
  AudioContext.prototype.createAnalyser = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "audio",
        method: "createAnalyser",
        timestamp: Date.now()
      }
    }, '*');
    return originalCreateAnalyser.apply(this, arguments);
  };

  // 重写createOscillator方法
  AudioContext.prototype.createOscillator = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "audio",
        method: "createOscillator",
        timestamp: Date.now()
      }
    }, '*');
    return originalCreateOscillator.apply(this, arguments);
  };
}

// ========== 字体指纹对抗 ==========
function initFontFingerprinting() {
  // 监控字体测量相关API
  const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
  
  CanvasRenderingContext2D.prototype.measureText = function(text) {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "font",
        text: text,
        timestamp: Date.now()
      }
    }, '*');
    return originalMeasureText.apply(this, arguments);
  };
}

// ========== 存储监控 ==========
function initStorageMonitoring() {
  // 监控localStorage
  const originalSetItem = Storage.prototype.setItem;
  Storage.prototype.setItem = function(key, value) {
    window.top.postMessage({
      msgType: "storage",
      msgData: {
        type: "localStorage",
        key: key,
        timestamp: Date.now()
      }
    }, '*');
    return originalSetItem.apply(this, arguments);
  };

  // 监控IndexedDB
  const originalOpen = indexedDB.open;
  indexedDB.open = function() {
    window.top.postMessage({
      msgType: "storage",
      msgData: {
        type: "indexedDB",
        timestamp: Date.now()
      }
    }, '*');
    return originalOpen.apply(this, arguments);
  };

  // 监控WebSQL
  if (window.openDatabase) {
    const originalOpenDatabase = window.openDatabase;
    window.openDatabase = function() {
      window.top.postMessage({
        msgType: "storage",
        msgData: {
          type: "webSQL",
          timestamp: Date.now()
        }
      }, '*');
      return originalOpenDatabase.apply(this, arguments);
    };
  }
}

// ========== 剪贴板监控 ==========
function initClipboardMonitoring() {
  document.addEventListener('paste', function(e) {
    window.top.postMessage({
      msgType: "clipboard",
      msgData: {
        type: "paste",
        timestamp: Date.now()
      }
    }, '*');
  });

  // 2024新增：Clipboard API监控
  if (navigator.clipboard) {
    const originalReadText = navigator.clipboard.readText;
    const originalWriteText = navigator.clipboard.writeText;

    navigator.clipboard.readText = function() {
      window.top.postMessage({
        msgType: "clipboard",
        msgData: {
          type: "api_read",
          timestamp: Date.now()
        }
      }, '*');
      return originalReadText.apply(this, arguments);
    };

    navigator.clipboard.writeText = function() {
      window.top.postMessage({
        msgType: "clipboard",
        msgData: {
          type: "api_write",
          timestamp: Date.now()
        }
      }, '*');
      return originalWriteText.apply(this, arguments);
    };
  }
}

// ========== 2024年新增指纹对抗技术 ==========

// WebRTC指纹对抗
function initWebRTCFingerprinting() {
  if (!window.RTCPeerConnection) return;

  const originalCreateDataChannel = RTCPeerConnection.prototype.createDataChannel;
  const originalGetStats = RTCPeerConnection.prototype.getStats;

  RTCPeerConnection.prototype.createDataChannel = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "webrtc",
        method: "createDataChannel",
        timestamp: Date.now()
      }
    }, '*');
    return originalCreateDataChannel.apply(this, arguments);
  };

  RTCPeerConnection.prototype.getStats = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "webrtc",
        method: "getStats",
        timestamp: Date.now()
      }
    }, '*');
    return originalGetStats.apply(this, arguments);
  };
}

// 媒体设备指纹对抗
function initMediaDevicesFingerprinting() {
  if (!navigator.mediaDevices) return;

  const originalEnumerateDevices = navigator.mediaDevices.enumerateDevices;
  const originalGetUserMedia = navigator.mediaDevices.getUserMedia;

  navigator.mediaDevices.enumerateDevices = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "mediaDevices",
        method: "enumerateDevices",
        timestamp: Date.now()
      }
    }, '*');

    // 返回标准化的设备列表
    return Promise.resolve([
      { deviceId: 'default', kind: 'audioinput', label: 'Default - Microphone' },
      { deviceId: 'default', kind: 'audiooutput', label: 'Default - Speaker' },
      { deviceId: 'default', kind: 'videoinput', label: 'Default - Camera' }
    ]);
  };

  navigator.mediaDevices.getUserMedia = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "mediaDevices",
        method: "getUserMedia",
        timestamp: Date.now()
      }
    }, '*');
    return originalGetUserMedia.apply(this, arguments);
  };
}

// 传感器指纹对抗 - 修复权限策略错误
function initSensorFingerprinting() {
  // 注意：不直接监听设备传感器事件，避免权限策略错误
  // 改为重写相关API来检测指纹尝试

  // 重写DeviceMotionEvent相关API
  if (window.DeviceMotionEvent && window.DeviceMotionEvent.requestPermission) {
    const originalRequestPermission = window.DeviceMotionEvent.requestPermission;
    window.DeviceMotionEvent.requestPermission = function() {
      window.top.postMessage({
        msgType: "fingerprint",
        msgData: {
          type: "sensor",
          method: "devicemotion_permission_request",
          timestamp: Date.now()
        }
      }, '*');
      return Promise.resolve('denied'); // 拒绝权限请求
    };
  }

  // 重写DeviceOrientationEvent相关API
  if (window.DeviceOrientationEvent && window.DeviceOrientationEvent.requestPermission) {
    const originalRequestPermission = window.DeviceOrientationEvent.requestPermission;
    window.DeviceOrientationEvent.requestPermission = function() {
      window.top.postMessage({
        msgType: "fingerprint",
        msgData: {
          type: "sensor",
          method: "deviceorientation_permission_request",
          timestamp: Date.now()
        }
      }, '*');
      return Promise.resolve('denied'); // 拒绝权限请求
    };
  }

  // 重写navigator.permissions.query来拦截传感器权限查询
  if (navigator.permissions && navigator.permissions.query) {
    const originalQuery = navigator.permissions.query;
    navigator.permissions.query = function(permissionDescriptor) {
      if (permissionDescriptor &&
          (permissionDescriptor.name === 'accelerometer' ||
           permissionDescriptor.name === 'gyroscope' ||
           permissionDescriptor.name === 'magnetometer')) {

        window.top.postMessage({
          msgType: "fingerprint",
          msgData: {
            type: "sensor",
            method: "permission_query",
            permission: permissionDescriptor.name,
            timestamp: Date.now()
          }
        }, '*');

        // 返回拒绝状态
        return Promise.resolve({ state: 'denied' });
      }

      return originalQuery.apply(this, arguments);
    };
  }
}

// 网络信息指纹对抗 - 完全修复undefined错误
function initNetworkFingerprinting() {
  try {
    // 多重安全检查
    if (typeof navigator === 'undefined') {
      console.log('navigator对象不存在，跳过网络指纹对抗');
      return;
    }

    if (!navigator.connection && !navigator.mozConnection && !navigator.webkitConnection) {
      console.log('所有网络连接API都不可用，跳过网络指纹对抗');
      return;
    }

    // 获取可用的连接对象
    const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (!connection) {
      console.log('无法获取网络连接对象，跳过网络指纹对抗');
      return;
    }

    // 安全地重写网络连接属性
    if ('effectiveType' in connection) {
      try {
        Object.defineProperty(connection, 'effectiveType', {
          get: function() {
            window.top.postMessage({
              msgType: "fingerprint",
              msgData: {
                type: "network",
                property: "effectiveType",
                timestamp: Date.now()
              }
            }, '*');
            return '4g'; // 标准化返回值
          },
          configurable: true
        });
      } catch (e) {
        console.warn('无法重写effectiveType属性:', e);
      }
    }

    if ('downlink' in connection) {
      try {
        Object.defineProperty(connection, 'downlink', {
          get: function() {
            window.top.postMessage({
              msgType: "fingerprint",
              msgData: {
                type: "network",
                property: "downlink",
                timestamp: Date.now()
              }
            }, '*');
            return 10; // 标准化返回值
          },
          configurable: true
        });
      } catch (e) {
        console.warn('无法重写downlink属性:', e);
      }
    }
  } catch (error) {
    console.warn('网络指纹对抗初始化失败:', error);
  }
}

// 硬件信息指纹对抗
function initHardwareFingerprinting() {
  // CPU核心数
  Object.defineProperty(navigator, 'hardwareConcurrency', {
    get: function() {
      window.top.postMessage({
        msgType: "fingerprint",
        msgData: {
          type: "hardware",
          property: "hardwareConcurrency",
          timestamp: Date.now()
        }
      }, '*');
      return 4; // 标准化返回值
    }
  });

  // 设备内存
  if (navigator.deviceMemory !== undefined) {
    Object.defineProperty(navigator, 'deviceMemory', {
      get: function() {
        window.top.postMessage({
          msgType: "fingerprint",
          msgData: {
            type: "hardware",
            property: "deviceMemory",
            timestamp: Date.now()
          }
        }, '*');
        return 8; // 标准化返回值
      }
    });
  }
}

// 时序攻击对抗
function initTimingAttackProtection() {
  const originalNow = performance.now;

  performance.now = function() {
    window.top.postMessage({
      msgType: "fingerprint",
      msgData: {
        type: "timing",
        method: "performance.now",
        timestamp: Date.now()
      }
    }, '*');

    // 添加随机噪声来防止时序攻击
    const original = originalNow.apply(this, arguments);
    return original + (Math.random() - 0.5) * 0.1;
  };
}

// ========== 初始化所有反指纹模块 (2024增强版) ==========
function initAntiFingerprinting() {
  try {
    // 原有模块
    initCanvasFingerprinting();
    initWebGLFingerprinting();
    initAudioFingerprinting();
    initFontFingerprinting();
    initStorageMonitoring();
    initClipboardMonitoring();

    // 2024新增模块
    initWebRTCFingerprinting();
    initMediaDevicesFingerprinting();
    initSensorFingerprinting();
    initNetworkFingerprinting();
    initHardwareFingerprinting();
    initTimingAttackProtection();

    console.log('狗蛋蜜罐识别器: 反指纹模块已启动 (2024增强版)');
    console.log('已启用12个反指纹对抗模块');
  } catch (error) {
    console.warn('狗蛋蜜罐识别器: 反指纹模块启动失败', error);
  }
}

// 立即执行初始化
initAntiFingerprinting();
