/**
 * 狗蛋蜜罐识别器 - 蜜罐特征检测模块
 * 作者: 蜜汁狗蛋
 * 版本: 2025.1.0
 *
 * 多层次检测体系，支持全球35+种蜜罐平台
 * 包含165+条检测规则，35个专项检测器
 */

'use strict';

// 🚨 立即加载完整的蜜罐检测规则数据库
console.log('🔍 开始加载完整蜜罐检测规则数据库...');

// 动态加载Heimdallr规则数据库
let HeimdallrRules = [];
let LatestRules2024 = [];

// 尝试加载规则文件
try {
  // 加载主规则数据库
  if (typeof printerData !== 'undefined') {
    HeimdallrRules = printerData.filter(rule => rule.type === 3); // type 3 = 蜜罐检测规则
    console.log(`✅ 已加载Heimdallr蜜罐规则: ${HeimdallrRules.length}条`);
  }

  // 加载2024最新规则
  if (typeof LatestHoneypotRules2024 !== 'undefined') {
    LatestRules2024 = LatestHoneypotRules2024;
    console.log(`✅ 已加载2024最新蜜罐规则: ${LatestRules2024.length}条`);
  }
} catch (error) {
  console.warn('⚠️ 规则数据库加载失败，使用内置规则:', error);
}

// 合并所有规则
const AllHoneypotRules = [...HeimdallrRules, ...LatestRules2024];
console.log(`🎯 总计蜜罐检测规则: ${AllHoneypotRules.length}条`);
// 风险告警策略（可运行时调整）
const DetectionPolicy = {
  minAlertConfidence: 'high',            // 仅对高置信度进行告警
  minHighDetectionsToAlert: 2,           // 至少命中2条高置信度规则才弹出警告页
  debounceMs: 8000,                      // 8秒内避免重复弹窗
  ignoredDomains: [
    'www.bing.com', 'cn.bing.com', 'bing.com',
    'fofa.info', 'www.fofa.info',        // FOFA网络空间搜索引擎
    'shodan.io', 'www.shodan.io',        // Shodan搜索引擎
    'censys.io', 'www.censys.io',        // Censys搜索引擎
    'zoomeye.org', 'www.zoomeye.org',    // ZoomEye搜索引擎
    'hunter.qianxin.com',                // 奇安信鹰图
    'quake.360.cn'                       // 360网络空间测绘
  ]
};
let _lastAlertAt = 0;
let _lastAlertUrl = '';

function isIgnoredDomain(host) {
  try {
    return DetectionPolicy.ignoredDomains.some(d => host.endsWith(d));
  } catch { return false; }
}

function shouldAlert(highCount) {
  if (isIgnoredDomain(location.hostname)) return false;
  if (highCount < DetectionPolicy.minHighDetectionsToAlert) return false;
  const now = Date.now();
  if (_lastAlertUrl === location.href && (now - _lastAlertAt) < DetectionPolicy.debounceMs) return false;
  _lastAlertAt = now; _lastAlertUrl = location.href;
  return true;
}

// 允许外部动态调整策略（测试/调参与误报压制）
window.godanHoneypot = window.godanHoneypot || {};
window.godanHoneypot.updatePolicy = (patch = {}) => Object.assign(DetectionPolicy, patch);


// ========== 蜜罐特征检测配置 ==========
const HoneypotDetectionConfig = {
  // 已知蜜罐特征
  honeypotSignatures: {
    // HFish蜜罐特征
    hfish: {
      globalVars: ['sec_key', 'login_field', 'user_login'],
      urlPatterns: ['/x.js'],
      domElements: ['#hfish-login', '.hfish-container']
    },

    // 默安蜜罐特征
    moan: {
      globalVars: ['token', 'path'],
      conditions: {
        token: (val) => typeof val === 'string' && val.includes('-'),
        path: (val) => typeof val === 'string' && val.includes('js_')
      }
    },

    // OpenCanary蜜罐特征
    opencanary: {
      titlePatterns: ['Synology RackStation'],
      metaPatterns: [
        { name: 'application-name', content: 'DemoSite' }
      ],
      h1Patterns: ['Network Storage v5.13']
    },

    // BEEF框架特征
    beef: {
      scriptPatterns: ['/hook.js', 'beef.js'],
      globalVars: ['beef']
    }
  },

  // 混淆脚本特征
  obfuscatorPatterns: [
    /var\s+_0x[a-f0-9]+\s*=\s*\[/i,
    /function\s+_0x[a-f0-9]+\s*\(/i,
    /_0x[a-f0-9]+\[_0x[a-f0-9]+\]/i
  ],

  // FingerprintJS检测
  fingerprintPatterns: [
    'FingerprintJS',
    'Fingerprint2',
    'fp.get',
    'new Fingerprint'
  ],

  // ========== 2024年最新蜜罐系统特征 ==========

  // T-Pot蜜罐平台
  tpot: {
    titlePatterns: ['T-Pot', 'Honeypot Dashboard'],
    urlPatterns: ['/kibana', '/tpot'],
    headerPatterns: ['X-T-Pot']
  },

  // Cowrie SSH蜜罐 (更新版本)
  cowrie: {
    bannerPatterns: ['SSH-2.0-OpenSSH_6.0p1', 'SSH-2.0-OpenSSH_7.4'],
    promptPatterns: ['root@', 'ubuntu@'],
    responsePatterns: ['cowrie', 'Welcome to Ubuntu']
  },

  // Dionaea蜜罐 (更新版本)
  dionaea: {
    servicePatterns: ['Microsoft-IIS/6.0', 'Apache/2.2.22'],
    headerPatterns: ['Server: dionaea'],
    portPatterns: [80, 443, 21, 23, 135, 445]
  },

  // Elastichoney
  elasticHoney: {
    titlePatterns: ['Elasticsearch'],
    responseHeaders: ['X-Elastic-Product'],
    versionPatterns: ['7.10.0', '8.0.0']
  },

  // Conpot工控蜜罐
  conpot: {
    titlePatterns: ['Siemens', 'Schneider Electric'],
    protocolPatterns: ['Modbus', 'S7'],
    devicePatterns: ['PLC', 'HMI']
  },

  // Glastopf Web蜜罐
  glastopf: {
    titlePatterns: ['glastopf'],
    headerPatterns: ['X-Powered-By: glastopf'],
    errorPatterns: ['glastopf error']
  },

  // Kippo SSH蜜罐
  kippo: {
    bannerPatterns: ['SSH-2.0-OpenSSH_5.1p1'],
    promptPatterns: ['root@srv'],
    logPatterns: ['kippo']
  },

  // Honeyd虚拟蜜罐
  honeyd: {
    headerPatterns: ['Server: Honeyd'],
    osPatterns: ['Honeyd Virtual'],
    servicePatterns: ['honeyd']
  },

  // MHN现代蜜罐网络
  mhn: {
    titlePatterns: ['Modern Honey Network'],
    urlPatterns: ['/mhn', '/api/feed'],
    headerPatterns: ['X-MHN']
  },

  // Wordpot WordPress蜜罐
  wordpot: {
    titlePatterns: ['WordPress'],
    urlPatterns: ['/wp-admin', '/wp-login.php'],
    headerPatterns: ['X-Powered-By: wordpot']
  },

  // Shockpot Shellshock蜜罐
  shockpot: {
    headerPatterns: ['() { :; }; echo vulnerable'],
    responsePatterns: ['shockpot'],
    cgiPatterns: ['/cgi-bin/']
  },

  // Amun恶意软件蜜罐
  amun: {
    servicePatterns: ['amun'],
    portPatterns: [135, 445, 1433, 5900],
    responsePatterns: ['amun honeypot']
  },

  // Beeswarm蜜罐
  beeswarm: {
    titlePatterns: ['Beeswarm'],
    servicePatterns: ['beeswarm'],
    protocolPatterns: ['HTTP', 'SSH', 'Telnet']
  },

  // HoneyThing IoT蜜罐
  honeything: {
    titlePatterns: ['IoT Device', 'Smart Device'],
    headerPatterns: ['X-IoT-Honeypot'],
    devicePatterns: ['Camera', 'Router', 'Thermostat']
  },

  // Mailoney SMTP蜜罐
  mailoney: {
    bannerPatterns: ['220 mailoney SMTP'],
    servicePatterns: ['mailoney'],
    protocolPatterns: ['SMTP', 'POP3', 'IMAP']
  },

  // Glutton多协议蜜罐
  glutton: {
    servicePatterns: ['glutton'],
    protocolPatterns: ['TCP', 'UDP'],
    responsePatterns: ['glutton honeypot']
  },

  // Heralding凭证蜜罐
  heralding: {
    bannerPatterns: ['heralding'],
    servicePatterns: ['SSH', 'Telnet', 'FTP'],
    authPatterns: ['authentication']
  },

  // Snare/Tanner Web蜜罐
  snare: {
    titlePatterns: ['Snare'],
    headerPatterns: ['X-Snare', 'X-Tanner'],
    responsePatterns: ['snare', 'tanner']
  },

  // 云蜜罐特征
  cloudHoneypot: {
    awsPatterns: ['ec2-', 'amazonaws.com'],
    azurePatterns: ['azure', 'microsoft'],
    gcpPatterns: ['googlecloud', 'compute.googleapis.com']
  },

  // 容器蜜罐特征
  containerHoneypot: {
    dockerPatterns: ['docker', 'container'],
    k8sPatterns: ['kubernetes', 'k8s'],
    headerPatterns: ['X-Container-Honeypot']
  }
};

// ========== 规则引擎检测函数 ==========

// 基于规则引擎的蜜罐检测
function detectHoneypotByRules() {
  console.log('🔍 开始基于规则引擎的蜜罐检测...');

  const detectionResults = [];
  const currentUrl = window.location.href;
  const pageTitle = document.title;
  const pageContent = document.documentElement.outerHTML;

  console.log('🔍 检测目标信息:', {
    URL: currentUrl,
    标题: pageTitle,
    内容长度: pageContent.length,
    规则数量: AllHoneypotRules.length
  });

  // 遍历所有蜜罐检测规则
  AllHoneypotRules.forEach(rule => {
    try {
      let isMatch = false;
      let evidence = '';

      // 调试信息：检查HFish相关规则
      if (rule.rulename.includes('hfish') || rule.rulename.includes('tomcat')) {
        console.log(`🔍 检查规则: ${rule.rulename}`, {
          规则位置: rule.ruleposition,
          规则内容: rule.rulecontent.toString(),
          页面标题: pageTitle
        });
      }

      switch (rule.ruleposition) {
        case 1: // 请求URL检测
          if (rule.rulecontent.test && rule.rulecontent.test(currentUrl)) {
            isMatch = true;
            evidence = `URL匹配: ${currentUrl}`;
          }
          break;

        case 5: // 响应体检测（页面内容）
          if (rule.rulecontent.test && rule.rulecontent.test(pageContent)) {
            isMatch = true;
            evidence = `页面内容匹配: ${rule.commandments}`;
          }
          break;

        case 3: // 请求体检测（页面标题等）
          if (rule.rulecontent.test && rule.rulecontent.test(pageTitle)) {
            isMatch = true;
            evidence = `页面标题匹配: ${pageTitle}`;
          }
          break;
      }

      if (isMatch) {
        console.warn(`🚨 规则引擎检测到蜜罐: ${rule.rulename}`);
        console.warn(`📋 规则描述: ${rule.commandments}`);
        console.warn(`🔍 匹配证据: ${evidence}`);

        // 动态置信度策略：页面内容关键词（ruleposition=5）仅记为中等，避免误报触发拦截
        const confidence = rule.ruleposition === 5 ? 'medium' : 'high';

        detectionResults.push({
          type: `规则引擎检测-${rule.rulename}`,
          evidence: evidence,
          confidence: confidence,
          ruleName: rule.rulename,
          ruleDescription: rule.commandments,
          ruleType: rule.type,
          rulePosition: rule.ruleposition
        });
      }
    } catch (error) {
      console.warn(`⚠️ 规则${rule.rulename}执行失败:`, error);
    }
  });

  return detectionResults;
}

// 高级蜜罐特征检测
function detectAdvancedHoneypotFeatures() {
  console.log('🔍 开始高级蜜罐特征检测...');

  const results = [];

  // 检测常见蜜罐全局变量
  const honeypotGlobalVars = [
    'sec_key', 'login_field', 'user_login', // HFish
    'token', 'path', // 默安
    'beef', 'hook', // BEEF
    'cowrie', 'kippo', 'dionaea', // SSH蜜罐
    'honeyd', 'honeytrap', 'glastopf', // 其他蜜罐
    'tpot', 'mhn', 'beeswarm', // 蜜罐平台
    'snare', 'tanner', 'wordpot', // Web蜜罐
    'mailoney', 'glutton', 'heralding' // 服务蜜罐
  ];

  honeypotGlobalVars.forEach(varName => {
    if (window[varName] !== undefined) {
      console.warn(`🚨 检测到蜜罐全局变量: ${varName} = ${window[varName]}`);
      results.push({
        type: `全局变量检测-${varName}`,
        evidence: `window.${varName} = ${window[varName]}`,
        confidence: 'high'
      });
    }
  });

  // 检测蜜罐特征DOM元素
  const honeypotSelectors = [
    '#hfish-login', '.hfish-container', // HFish
    '.honeypot', '.trap', '.decoy', // 通用蜜罐
    '#cowrie', '#kippo', '#dionaea', // SSH蜜罐
    '.tpot', '.mhn-dashboard', // 蜜罐平台
    '.snare-web', '.wordpot-login', // Web蜜罐
    '[data-honeypot]', '[class*="honeypot"]' // 属性检测
  ];

  honeypotSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.warn(`🚨 检测到蜜罐DOM元素: ${selector} (${elements.length}个)`);
      results.push({
        type: `DOM元素检测-${selector}`,
        evidence: `找到${elements.length}个匹配元素`,
        confidence: 'medium'
      });
    }
  });

  // 检测蜜罐特征脚本
  const scripts = document.querySelectorAll('script[src]');
  const honeypotScripts = [
    '/x.js', '/hook.js', 'beef.js', // 已知蜜罐脚本
    'cowrie.js', 'kippo.js', 'dionaea.js', // SSH蜜罐脚本
    'honeyd.js', 'honeytrap.js', 'glastopf.js', // 其他蜜罐脚本
    'tpot.js', 'mhn.js', 'beeswarm.js', // 蜜罐平台脚本
    'snare.js', 'tanner.js', 'wordpot.js' // Web蜜罐脚本
  ];

  scripts.forEach(script => {
    const src = script.src;
    honeypotScripts.forEach(honeypotScript => {
      if (src.includes(honeypotScript)) {
        console.warn(`🚨 检测到蜜罐脚本: ${src}`);
        results.push({
          type: `脚本检测-${honeypotScript}`,
          evidence: `脚本路径: ${src}`,
          confidence: 'high'
        });
      }
    });
  });

  return results;
}

// ========== 原有检测函数（保留兼容性） ==========

// 检测默安蜜罐 - 增强版
function detectMoanHoneypot() {
  const results = [];
  console.log('🔍 开始默安蜜罐检测...');

  // 检查默安特征全局变量
  const moanGlobalVars = ['token', 'path', 'moan_token', 'js_moan_path'];
  moanGlobalVars.forEach(varName => {
    if (window[varName] !== undefined) {
      console.log(`🔍 检测到默安全局变量: ${varName} = ${window[varName]}`);
      results.push({
        type: '默安蜜罐',
        evidence: `全局变量: window.${varName} = ${window[varName]}`,
        confidence: 'high'
      });
    }
  });

  // 传统默安检测逻辑（保持兼容性）
  if (window.token !== undefined && window.path !== undefined) {
    const { moan } = HoneypotDetectionConfig.honeypotSignatures;
    const tokenValid = moan.conditions.token(window.token);
    const pathValid = moan.conditions.path(window.path);

    if (tokenValid && pathValid) {
      console.log('🔍 检测到默安蜜罐经典特征组合');
      results.push({
        type: '默安蜜罐',
        evidence: `经典特征: token=${window.token}, path=${window.path}`,
        confidence: 'high'
      });
    }
  }

  // 检查默安特征DOM元素
  const moanSelectors = ['.moan-container', '#moan-login', '[data-moan]'];
  moanSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`🔍 检测到默安DOM元素: ${selector}`);
      results.push({
        type: '默安蜜罐',
        evidence: `DOM元素: ${selector}`,
        confidence: 'high'
      });
    }
  });

  // 检查默安特征资源
  const scripts = document.querySelectorAll('script[src]');
  scripts.forEach(script => {
    const src = script.getAttribute('src');
    if (src && (src.includes('moan.js') || src.includes('/moan/'))) {
      console.log(`🔍 检测到默安特征脚本: ${src}`);
      results.push({
        type: '默安蜜罐',
        evidence: `特征脚本: ${src}`,
        confidence: 'high'
      });
    }
  });

  console.log(`🔍 默安检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测HFish蜜罐 - 完整版（基于旧版本逻辑）
function detectHFishHoneypot() {
  const results = [];
  console.log('🍯 开始HFish蜜罐专项检测...');

  // === 1. HFish Tomcat蜜罐检测 ===
  if (document.title.includes("Apache Tomcat/8.5.15")) {
    const linkCount = document.getElementsByTagName("link").length;
    console.log(`🔍 检测到Tomcat标题，Link数量: ${linkCount}`);

    if (linkCount === 2) {
      results.push({
        type: 'HFish Tomcat蜜罐',
        evidence: `标题: ${document.title}, Link标签数量: ${linkCount}`,
        confidence: 'high'
      });
    }
  }

  // === 2. HFish Login页面检测 ===
  if (document.title === "Login") {
    const iconLink = document.querySelector('link[rel="icon"]');
    if (iconLink) {
      const href = iconLink.getAttribute('href');
      console.log(`🔍 Login页面图标: ${href}`);

      if (href && (href.includes('data:;base64,=') || href.includes('data:image/ico;base64,aWNv'))) {
        results.push({
          type: 'HFish Login蜜罐',
          evidence: `Login页面 + 特征图标: ${href}`,
          confidence: 'high'
        });
      }
    }
  }

  // === 3. HFish全局变量检测 ===
  const hfishGlobalVars = ['sec_key', 'login_field', 'user_login'];
  hfishGlobalVars.forEach(varName => {
    if (window[varName] !== undefined) {
      console.log(`🔍 检测到HFish全局变量: ${varName} = ${window[varName]}`);
      results.push({
        type: 'HFish蜜罐',
        evidence: `全局变量: window.${varName} = ${window[varName]}`,
        confidence: 'high'
      });
    }
  });

  // === 4. HFish DOM元素检测 ===
  const hfishSelectors = ['#hfish-login', '.hfish-container', '[data-hfish]'];
  hfishSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log(`🔍 检测到HFish DOM元素: ${selector}`);
      results.push({
        type: 'HFish蜜罐',
        evidence: `DOM元素: ${selector} (${elements.length}个)`,
        confidence: 'high'
      });
    }
  });

  // === 5. HFish特征资源检测 ===
  const scripts = document.querySelectorAll('script[src]');
  scripts.forEach(script => {
    const src = script.getAttribute('src');
    if (src && src.includes('/x.js')) {
      console.log(`🔍 检测到HFish特征脚本: ${src}`);
      results.push({
        type: 'HFish蜜罐',
        evidence: `特征脚本: ${src}`,
        confidence: 'high'
      });
    }
  });

  const images = document.querySelectorAll('img[src]');
  images.forEach(img => {
    const src = img.getAttribute('src');
    if (src && src.includes('w-logo-blue.png')) {
      console.log(`🔍 检测到HFish特征图片: ${src}`);
      results.push({
        type: 'HFish蜜罐',
        evidence: `特征图片: ${src}`,
        confidence: 'high'
      });
    }
  });

  // === 6. HFish多种服务类型检测 ===
  const hfishTitlePatterns = [
    { pattern: /Sign in · GitLab/i, type: 'HFish GitLab蜜罐' },
    { pattern: /IIS Windows/i, type: 'HFish IIS蜜罐' },
    { pattern: /Welcome to nginx!/i, type: 'HFish Nginx蜜罐' },
    { pattern: /IBM WebSphere Portal - Login/i, type: 'HFish WebSphere蜜罐' },
    { pattern: /Oracle WebLogic Server 管理控制台/i, type: 'HFish WebLogic蜜罐' },
    { pattern: /Coremail邮件系统/i, type: 'HFish Coremail蜜罐' },
    { pattern: /Outlook Web App/i, type: 'HFish Outlook蜜罐' },
    { pattern: /登录 ‹ 内部管理平台 — WordPress/i, type: 'HFish WordPress蜜罐' },
    { pattern: /OA登录/i, type: 'HFish OA蜜罐' },
    { pattern: /政务外网OA系统/i, type: 'HFish 政务OA蜜罐' },
    { pattern: /登录 - Jira/i, type: 'HFish Jira蜜罐' },
    { pattern: /Log In - Confluence/i, type: 'HFish Confluence蜜罐' },
    { pattern: /管理后台/i, type: 'HFish 管理后台蜜罐' },
    { pattern: /Login to Webmin/i, type: 'HFish Webmin蜜罐' },
    { pattern: /Login • Nagios Network Analyzer/i, type: 'HFish Nagios蜜罐' },
    { pattern: /ops center: Zabbix/i, type: 'HFish Zabbix蜜罐' },
    { pattern: /Sign in \[Jenkins\]/i, type: 'HFish Jenkins蜜罐' },
    { pattern: /登录 - VMware ESXi/i, type: 'HFish ESXi蜜罐' },
    { pattern: /锐捷网络-EWEB网管系统/i, type: 'HFish 锐捷蜜罐' },
    { pattern: /ER3108G系统管理/i, type: 'HFish H3C蜜罐' },
    { pattern: /DSM 6\.2 - Synology VirtualDSM/i, type: 'HFish 群晖NAS蜜罐' },
    { pattern: /JspSpy Codz By - Ninty/i, type: 'HFish JspSpy蜜罐' }
  ];

  hfishTitlePatterns.forEach(({ pattern, type }) => {
    if (pattern.test(document.title)) {
      console.log(`🔍 检测到HFish服务类型: ${type}`);
      results.push({
        type: type,
        evidence: `页面标题匹配: ${document.title}`,
        confidence: 'high'
      });
    }
  });

  // === 7. HFish页面内容特征检测 ===
  const pageHTML = document.documentElement.outerHTML;
  if (pageHTML.includes('HFish') || pageHTML.includes('hfish')) {
    console.log('🔍 页面内容包含HFish关键词');
    results.push({
      type: 'HFish蜜罐',
      evidence: '页面内容包含HFish关键词',
      confidence: 'medium'
    });
  }

  console.log(`🍯 HFish检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测OpenCanary蜜罐
function detectOpenCanaryHoneypot() {
  const { opencanary } = HoneypotDetectionConfig.honeypotSignatures;

  // 检查页面标题
  for (const pattern of opencanary.titlePatterns) {
    if (document.title.includes(pattern)) {
      // 进一步检查meta标签
      const metas = document.getElementsByTagName('meta');
      for (const meta of metas) {
        for (const metaPattern of opencanary.metaPatterns) {
          if (meta.name === metaPattern.name && meta.content.includes(metaPattern.content)) {
            return {
              type: 'opencanary',
              evidence: `Title: ${pattern}, Meta: ${metaPattern.name}=${metaPattern.content}`,
              confidence: 'high'
            };
          }
        }
      }
    }
  }

  // 检查H1标签
  const h1Elements = document.getElementsByTagName('h1');
  for (const h1 of h1Elements) {
    for (const pattern of opencanary.h1Patterns) {
      if (h1.innerText === pattern) {
        return {
          type: 'opencanary',
          evidence: `H1 text: ${pattern}`,
          confidence: 'high'
        };
      }
    }
  }

  return null;
}

// 检测BEEF框架
function detectBeefFramework() {
  const { beef } = HoneypotDetectionConfig.honeypotSignatures;

  // 检查脚本标签
  const scripts = document.getElementsByTagName('script');
  for (const script of scripts) {
    if (script.src) {
      for (const pattern of beef.scriptPatterns) {
        if (script.src.includes(pattern)) {
          return {
            type: 'beef',
            evidence: `Script source: ${script.src}`,
            confidence: 'high'
          };
        }
      }
    }
  }

  // 检查全局变量
  for (const varName of beef.globalVars) {
    if (window[varName] !== undefined) {
      return {
        type: 'beef',
        evidence: `Global variable: ${varName}`,
        confidence: 'medium'
      };
    }
  }

  return null;
}

// 检测混淆脚本
function detectObfuscatedScripts() {
  const scripts = document.getElementsByTagName('script');

  for (const script of scripts) {
    if (script.innerHTML) {
      for (const pattern of HoneypotDetectionConfig.obfuscatorPatterns) {
        if (pattern.test(script.innerHTML)) {
          return {
            type: 'obfuscator',
            evidence: 'Obfuscated JavaScript detected',
            confidence: 'medium'
          };
        }
      }
    }
  }

  return null;
}

// 检测FingerprintJS
function detectFingerprintJS() {
  const scripts = document.getElementsByTagName('script');

  for (const script of scripts) {
    const content = script.innerHTML || script.src || '';

    for (const pattern of HoneypotDetectionConfig.fingerprintPatterns) {
      if (content.includes(pattern)) {
        return {
          type: 'fingerprint2',
          evidence: `FingerprintJS pattern: ${pattern}`,
          confidence: 'high'
        };
      }
    }
  }

  return null;
}

// ========== 黑白名单检查函数 ==========
async function checkWhitelist(url) {
  try {
    // 等待whitelistManager加载
    await waitForWhitelistManager();

    if (window.whitelistManager) {
      const result = window.whitelistManager.isWhitelisted(url);
      console.log('🔍 白名单检查结果:', url, result);
      return result;
    }
    console.warn('⚠️ whitelistManager未找到');
    return { isWhitelisted: false };
  } catch (error) {
    console.warn('⚠️ 白名单检查失败:', error);
    return { isWhitelisted: false };
  }
}

async function checkBlacklist(url) {
  try {
    // 等待whitelistManager加载
    await waitForWhitelistManager();

    if (window.whitelistManager) {
      const result = window.whitelistManager.isBlacklisted(url);
      console.log('🔍 黑名单检查结果:', url, result);
      return result;
    }
    console.warn('⚠️ whitelistManager未找到');
    return { isBlacklisted: false };
  } catch (error) {
    console.warn('⚠️ 黑名单检查失败:', error);
    return { isBlacklisted: false };
  }
}

// 等待whitelistManager加载
async function waitForWhitelistManager() {
  console.log('⏳ 等待whitelistManager初始化...');

  // 方法1: 检查ready标志
  let attempts = 0;
  while (!window.whitelistManagerReady && attempts < 50) {
    await new Promise(resolve => setTimeout(resolve, 200));
    attempts++;
  }

  // 方法2: 检查管理器对象
  attempts = 0;
  while (!window.whitelistManager && attempts < 30) {
    await new Promise(resolve => setTimeout(resolve, 100));
    attempts++;
  }

  if (window.whitelistManager && window.whitelistManagerReady) {
    console.log('✅ whitelistManager已就绪');
    return true;
  } else {
    console.warn('⚠️ whitelistManager加载超时或失败');
    console.log('whitelistManager:', !!window.whitelistManager);
    console.log('whitelistManagerReady:', !!window.whitelistManagerReady);
    return false;
  }
}

// 显示白名单状态
function displayWhitelistStatus(reason) {
  try {
    // 创建白名单状态提示
    const statusDiv = document.createElement('div');
    statusDiv.id = 'whitelistStatus';
    statusDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(135deg, #28a745, #20c997);
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
      z-index: 10000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-size: 14px;
      font-weight: 500;
      max-width: 300px;
      animation: slideInRight 0.3s ease-out;
    `;

    statusDiv.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 16px;">✅</span>
        <div>
          <div style="font-weight: 600;">白名单网站</div>
          <div style="font-size: 12px; opacity: 0.9;">${reason}</div>
        </div>
      </div>
    `;

    // 添加动画样式
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideInRight {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `;
    document.head.appendChild(style);

    // 移除已存在的状态提示
    const existing = document.getElementById('whitelistStatus');
    if (existing) {
      existing.remove();
    }

    // 添加到页面
    document.body.appendChild(statusDiv);

    // 5秒后自动消失
    setTimeout(() => {
      if (statusDiv && statusDiv.parentNode) {
        statusDiv.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => {
          statusDiv.remove();
        }, 300);
      }
    }, 5000);

    console.log('✅ 白名单状态已显示:', reason);

  } catch (error) {
    console.warn('⚠️ 显示白名单状态失败:', error);
  }
}

// ========== 主检测函数 - 集成黑白名单和规则引擎 ==========
async function performHoneypotDetection() {
  console.log('🔍 开始全面蜜罐检测...');

  const allResults = [];
  const currentUrl = window.location.href;

  try {
    // 快速检查是否为明显的白名单域名（不依赖白名单管理器）
    const hostname = new URL(currentUrl).hostname.toLowerCase();
    const quickWhitelistDomains = [
      'google.com', 'baidu.com', 'github.com', 'stackoverflow.com',
      'microsoft.com', 'apple.com', 'amazon.com', 'taobao.com',
      'tmall.com', 'jd.com', 'qq.com', 'weibo.com', 'zhihu.com'
    ];

    const isQuickWhitelisted = quickWhitelistDomains.some(domain =>
      hostname === domain || hostname.endsWith('.' + domain)
    );

    if (isQuickWhitelisted) {
      console.log('✅ 网站在快速白名单中，跳过检测:', hostname);
      return [{
        type: '白名单网站',
        evidence: `快速白名单域名: ${hostname}`,
        confidence: 'safe',
        source: 'quick-whitelist'
      }];
    }

    // 尝试使用白名单管理器（如果可用）
    try {
      const isReady = await waitForWhitelistManager();
      if (isReady && window.whitelistManager) {
        const whitelistCheck = await checkWhitelist(currentUrl);
        if (whitelistCheck.isWhitelisted) {
          console.log('✅ 网站在白名单中，跳过检测:', whitelistCheck.reason);
          displayWhitelistStatus(whitelistCheck.reason);
          return [{
            type: '白名单网站',
            evidence: whitelistCheck.reason,
            confidence: 'safe',
            source: 'whitelist'
          }];
        }

        const blacklistCheck = await checkBlacklist(currentUrl);
        if (blacklistCheck.isBlacklisted) {
          console.log('🚫 网站在黑名单中，直接标记为蜜罐:', blacklistCheck.reason);
          return [{
            type: '黑名单蜜罐',
            evidence: blacklistCheck.reason,
            confidence: 'high',
            source: 'blacklist'
          }];
        }
      } else {
        console.warn('⚠️ 白名单管理器不可用，继续使用其他检测方法');
      }
    } catch (error) {
      console.warn('⚠️ 白名单检查失败，继续使用其他检测方法:', error);
    }

    console.log(`🎯 使用${AllHoneypotRules.length}条规则进行检测`);

    // 1. 基于规则引擎的检测（主要检测方法）
    try {
      const ruleResults = detectHoneypotByRules();
      allResults.push(...ruleResults);
      console.log(`📊 规则引擎检测结果: ${ruleResults.length}条`);
    } catch (error) {
      console.warn('⚠️ 规则引擎检测失败:', error);
    }
  } catch (error) {
    console.error('❌ 蜜罐检测失败:', error);
  }

  // 2. 高级特征检测
  try {
    const advancedResults = detectAdvancedHoneypotFeatures();
    allResults.push(...advancedResults);
    console.log(`📊 高级特征检测结果: ${advancedResults.length}条`);
  } catch (error) {
    console.warn('⚠️ 高级特征检测失败:', error);
  }

  // 3. 世界级蜜罐检测方法集合 (2025年最新)
  const detectors = [
    // === 基础蜜罐检测 ===
    detectMoanHoneypot,
    detectHFishHoneypot,
    detectOpenCanaryHoneypot,
    detectBeefFramework,
    detectObfuscatedScripts,
    detectFingerprintJS,

    // === 传统开源蜜罐 ===
    detectCowrieHoneypot,
    detectKippoHoneypot,
    detectDionaeaHoneypot,
    detectGlastopfHoneypot,
    detectConpotHoneypot,
    detectElasticHoneyHoneypot,
    detectWordpotHoneypot,
    detectRdpyHoneypot,
    detectMailoneyHoneypot,

    // === 2025年国际蜜罐平台 ===
    detectTPotHoneypot,           // T-Pot社区蜜罐
    detectMHNHoneypot,            // Modern Honey Network
    detectHoneydHoneypot,         // Honeyd虚拟蜜罐
    detectThugHoneypot,           // Thug蜜罐客户端
    detectCommercialHoneypots,    // 商业蜜罐解决方案
    detectCloudHoneypots,         // 云原生蜜罐服务
    detectAIHoneypots,            // AI/ML驱动蜜罐
    detectIoTIndustrialHoneypots, // IoT和工控蜜罐
    detectEmergingTechHoneypots,  // 新兴技术蜜罐
    detectIndustrySpecificHoneypots // 行业特定蜜罐
  ];

  console.log(`🌍 执行 ${detectors.length} 个全球蜜罐检测器 (2025年最新)...`);

  for (const detector of detectors) {
    try {
      const result = detector();
      if (result) {
        // 处理返回数组的情况（如增强版HFish检测）
        if (Array.isArray(result)) {
          allResults.push(...result);
        } else {
          allResults.push(result);
        }
      }
    } catch (error) {
      console.warn('传统检测方法出错:', error);
    }
  }

  // 汇总检测结果
  const totalDetections = allResults.length;
  console.log(`🎯 总检测结果: ${totalDetections}条`);

  if (totalDetections > 0) {
    console.warn('🚨🚨🚨 检测到蜜罐特征 🚨🚨🚨');
    console.warn(`📊 检测统计: 共发现${totalDetections}个蜜罐特征`);

    // 按置信度分类
    const highConfidence = allResults.filter(r => r.confidence === 'high').length;
    const mediumConfidence = allResults.filter(r => r.confidence === 'medium').length;
    const lowConfidence = allResults.filter(r => r.confidence === 'low').length;

    console.warn(`📈 置信度分布: 高(${highConfidence}) 中(${mediumConfidence}) 低(${lowConfidence})`);

    // 发送检测结果
    allResults.forEach((result, index) => {
      if (result) {
        console.warn(`🚨 蜜罐特征 #${index + 1}:`, result);

        // 发送检测结果到background script
        try {
          // 使用chrome.runtime.sendMessage发送到background
          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({
              action: 'honeypotDetected',
              honeypotType: result.type,
              evidence: result.evidence,
              confidence: result.confidence,
              timestamp: Date.now(),
              url: window.location.href,
              detectionIndex: index + 1,
              totalDetections: totalDetections,
              ruleName: result.ruleName || '',
              ruleDescription: result.ruleDescription || ''
            }).catch(error => {
              console.warn('发送蜜罐检测结果失败:', error);
            });
          }

          // 备用方案：使用postMessage
          window.top.postMessage({
            msgType: result.type,
            msgData: result.evidence,
            confidence: result.confidence,
            timestamp: Date.now(),
            detectionIndex: index + 1,
            totalDetections: totalDetections
          }, '*');
        } catch (error) {
          console.warn('蜜罐检测结果发送失败:', error);
        }
      }
    });

    // 不再显示警告页，所有检测结果都通过UI展示
    console.log('🎯 蜜罐检测完成，结果已发送到前端UI显示');
  } else {
    console.log('✅ 未检测到蜜罐特征');
  }

  return allResults;
}

// ========== 动态脚本监控 ==========
function monitorDynamicScripts() {
  // 监控动态添加的脚本
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      mutation.addedNodes.forEach(function(node) {
        if (node.tagName === 'SCRIPT') {
          // 检查新添加的脚本，延迟执行并等待whitelistManager
          setTimeout(async () => {
            console.log('🔍 检测到新脚本，执行检测...');
            await waitForWhitelistManager();
            await performHoneypotDetection();
          }, 1000);
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

// ========== 初始化检测 ==========
function initHoneypotDetection() {
  try {
    console.log('🔍 狗蛋蜜罐识别器: 蜜罐检测模块已启动');

    // 立即执行一次检测（不等待白名单管理器）
    setTimeout(async () => {
      console.log('🔍 开始立即检测...');
      await performHoneypotDetection();
    }, 1000);

    // DOM就绪后执行检测
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', async () => {
        console.log('🔍 DOM就绪，执行检测...');
        await performHoneypotDetection();
      });
    } else {
      // DOM已经就绪
      setTimeout(async () => {
        console.log('🔍 DOM已就绪，执行检测...');
        await performHoneypotDetection();
      }, 500);
    }

    // 页面完全加载后再次检测
    window.addEventListener('load', () => {
      setTimeout(async () => {
        console.log('🔍 页面加载完成，最终检测...');
        await performHoneypotDetection();

        // 启动动态脚本监控
        if (document.body) {
          monitorDynamicScripts();
        }
      }, 1000);
    });

  } catch (error) {
    console.warn('🔍 狗蛋蜜罐识别器: 蜜罐检测模块启动失败', error);
  }
}

// 显示蜜罐警告页面
function showHoneypotWarningPage(highConfidenceResults) {
  console.warn('🚨 显示蜜罐警告页面');

  const warningHtml = `
    <html>
      <head>
        <title>🚨 蜜罐检测警告</title>
        <style>
          body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            margin: 0;
          }
          .container {
            background: rgba(255,255,255,0.95);
            color: #333;
            border-radius: 15px;
            padding: 40px;
            max-width: 600px;
            margin: 0 auto;
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
          }
          h1 { color: #e74c3c; margin-bottom: 20px; }
          h2 { color: #c0392b; margin-bottom: 15px; }
          .warning-icon { font-size: 64px; margin-bottom: 20px; }
          .detection-list {
            text-align: left;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
          }
          .detection-item {
            margin: 10px 0;
            padding: 10px;
            background: #fff;
            border-left: 4px solid #e74c3c;
            border-radius: 4px;
          }
          .evidence {
            font-family: monospace;
            font-size: 12px;
            color: #666;
            margin-top: 5px;
          }
          .stats {
            background: #e8f5e8;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
          }
          .button {
            background: #3498db;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin: 10px;
            text-decoration: none;
            display: inline-block;
          }
          .button:hover { background: #2980b9; }
          .button.danger { background: #e74c3c; }
          .button.danger:hover { background: #c0392b; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="warning-icon">🚨</div>
          <h1>狗蛋蜜罐识别器</h1>
          <h2>检测到蜜罐网站！</h2>

          <div class="stats">
            <strong>🎯 检测统计</strong><br>
            高置信度检测: ${highConfidenceResults.length}个<br>
            当前URL: ${window.location.href}<br>
            检测时间: ${new Date().toLocaleString()}
          </div>

          <div class="detection-list">
            <strong>🔍 检测到的蜜罐特征:</strong>
            ${highConfidenceResults.map((result, index) => `
              <div class="detection-item">
                <strong>#${index + 1} ${result.type}</strong>
                <div class="evidence">证据: ${result.evidence}</div>
              </div>
            `).join('')}
          </div>

          <p style="color: #e74c3c; font-weight: bold; font-size: 18px;">
            ⚠️ 此页面已被识别为蜜罐陷阱，建议立即离开！
          </p>

          <div>
            <button class="button danger" onclick="window.close()">关闭页面</button>
            <button class="button" onclick="history.back()">返回上页</button>
          </div>

          <p style="font-size: 12px; color: #666; margin-top: 30px;">
            狗蛋蜜罐识别器 v2.2.0 | 使用${AllHoneypotRules.length}条规则检测
          </p>
        </div>
      </body>
    </html>
  `;

  // 替换页面内容
  document.documentElement.innerHTML = warningHtml;
}

// ========== 其他主要蜜罐平台检测函数 ==========

// 检测Cowrie SSH蜜罐
function detectCowrieHoneypot() {
  const results = [];
  console.log('🔍 开始Cowrie蜜罐检测...');

  // 检查SSH版本特征
  const pageContent = document.documentElement.outerHTML;
  if (pageContent.includes('SSH-2.0-OpenSSH_6.0p1') ||
      pageContent.includes('cowrie') ||
      pageContent.includes('Ubuntu 12.04')) {
    console.log('🔍 检测到Cowrie SSH蜜罐特征');
    results.push({
      type: 'Cowrie SSH蜜罐',
      evidence: 'SSH版本或系统特征匹配',
      confidence: 'high'
    });
  }

  console.log(`🔍 Cowrie检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Kippo SSH蜜罐
function detectKippoHoneypot() {
  const results = [];
  console.log('🔍 开始Kippo蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('kippo')) {
    console.log('🔍 检测到Kippo SSH蜜罐特征');
    results.push({
      type: 'Kippo SSH蜜罐',
      evidence: '页面内容包含kippo关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Kippo检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Dionaea恶意软件蜜罐
function detectDionaeaHoneypot() {
  const results = [];
  console.log('🔍 开始Dionaea蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('dionaea')) {
    console.log('🔍 检测到Dionaea恶意软件蜜罐特征');
    results.push({
      type: 'Dionaea恶意软件蜜罐',
      evidence: '页面内容包含dionaea关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Dionaea检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Glastopf Web蜜罐
function detectGlastopfHoneypot() {
  const results = [];
  console.log('🔍 开始Glastopf蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('glastopf')) {
    console.log('🔍 检测到Glastopf Web蜜罐特征');
    results.push({
      type: 'Glastopf Web蜜罐',
      evidence: '页面内容包含glastopf关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Glastopf检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Conpot SCADA蜜罐
function detectConpotHoneypot() {
  const results = [];
  console.log('🔍 开始Conpot蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('conpot')) {
    console.log('🔍 检测到Conpot SCADA蜜罐特征');
    results.push({
      type: 'Conpot SCADA蜜罐',
      evidence: '页面内容包含conpot关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Conpot检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测ElasticHoney Elasticsearch蜜罐
function detectElasticHoneyHoneypot() {
  const results = [];
  console.log('🔍 开始ElasticHoney蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('elastichoney') || pageContent.includes('elastic honey')) {
    console.log('🔍 检测到ElasticHoney蜜罐特征');
    results.push({
      type: 'ElasticHoney Elasticsearch蜜罐',
      evidence: '页面内容包含elastichoney关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 ElasticHoney检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Wordpot WordPress蜜罐
function detectWordpotHoneypot() {
  const results = [];
  console.log('🔍 开始Wordpot蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('wordpot')) {
    console.log('🔍 检测到Wordpot WordPress蜜罐特征');
    results.push({
      type: 'Wordpot WordPress蜜罐',
      evidence: '页面内容包含wordpot关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Wordpot检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测RDPY RDP蜜罐
function detectRdpyHoneypot() {
  const results = [];
  console.log('🔍 开始RDPY蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('rdpy')) {
    console.log('🔍 检测到RDPY RDP蜜罐特征');
    results.push({
      type: 'RDPY RDP蜜罐',
      evidence: '页面内容包含rdpy关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 RDPY检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Mailoney SMTP蜜罐
function detectMailoneyHoneypot() {
  const results = [];
  console.log('🔍 开始Mailoney蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  if (pageContent.includes('mailoney')) {
    console.log('🔍 检测到Mailoney SMTP蜜罐特征');
    results.push({
      type: 'Mailoney SMTP蜜罐',
      evidence: '页面内容包含mailoney关键词',
      confidence: 'high'
    });
  }

  console.log(`🔍 Mailoney检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// ========== 2025年国际蜜罐平台检测函数 ==========

// 检测T-Pot社区蜜罐平台
function detectTPotHoneypot() {
  const results = [];
  console.log('🔍 开始T-Pot蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  if (pageContent.includes('t-pot') || pageContent.includes('tpot') ||
      pageContent.includes('dtag') || pageContent.includes('telekom security') ||
      titleContent.includes('t-pot') || titleContent.includes('tpot')) {
    console.log('🔍 检测到T-Pot社区蜜罐特征');
    results.push({
      type: 'T-Pot社区蜜罐',
      evidence: '页面内容包含T-Pot或DTAG特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 T-Pot检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Modern Honey Network (MHN)
function detectMHNHoneypot() {
  const results = [];
  console.log('🔍 开始MHN蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  if (pageContent.includes('modern honey network') || pageContent.includes('mhn') ||
      pageContent.includes('threatstream') || titleContent.includes('mhn')) {
    console.log('🔍 检测到Modern Honey Network特征');
    results.push({
      type: 'Modern Honey Network蜜罐',
      evidence: '页面内容包含MHN特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 MHN检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Honeyd虚拟蜜罐框架
function detectHoneydHoneypot() {
  const results = [];
  console.log('🔍 开始Honeyd蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();

  if (pageContent.includes('honeyd') || pageContent.includes('niels provos')) {
    console.log('🔍 检测到Honeyd虚拟蜜罐特征');
    results.push({
      type: 'Honeyd虚拟蜜罐',
      evidence: '页面内容包含Honeyd特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 Honeyd检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测Thug蜜罐客户端
function detectThugHoneypot() {
  const results = [];
  console.log('🔍 开始Thug蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();

  if (pageContent.includes('thug honeyclient') || pageContent.includes('thug low interaction')) {
    console.log('🔍 检测到Thug蜜罐客户端特征');
    results.push({
      type: 'Thug蜜罐客户端',
      evidence: '页面内容包含Thug特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 Thug检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测商业蜜罐解决方案
function detectCommercialHoneypots() {
  const results = [];
  console.log('🔍 开始商业蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  // Illusive Networks
  if (pageContent.includes('illusive networks') || pageContent.includes('illusive deception') ||
      titleContent.includes('illusive')) {
    results.push({
      type: 'Illusive Networks欺骗平台',
      evidence: '检测到Illusive Networks特征',
      confidence: 'high'
    });
  }

  // Attivo Networks
  if (pageContent.includes('attivo networks') || pageContent.includes('threatdefend') ||
      titleContent.includes('attivo')) {
    results.push({
      type: 'Attivo Networks ThreatDefend',
      evidence: '检测到Attivo Networks特征',
      confidence: 'high'
    });
  }

  // Guardicore
  if (pageContent.includes('guardicore') || pageContent.includes('centra')) {
    results.push({
      type: 'Guardicore Centra欺骗平台',
      evidence: '检测到Guardicore特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 商业蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测云原生蜜罐服务
function detectCloudHoneypots() {
  const results = [];
  console.log('🔍 开始云原生蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  // AWS GuardDuty
  if (pageContent.includes('aws guardduty') || pageContent.includes('amazon honeypot')) {
    results.push({
      type: 'AWS GuardDuty蜜罐',
      evidence: '检测到AWS GuardDuty蜜罐特征',
      confidence: 'high'
    });
  }

  // Azure Sentinel
  if (pageContent.includes('azure sentinel') || pageContent.includes('microsoft sentinel')) {
    results.push({
      type: 'Azure Sentinel蜜罐',
      evidence: '检测到Azure Sentinel蜜罐特征',
      confidence: 'high'
    });
  }

  // Google Cloud Security
  if (pageContent.includes('gcp security') || pageContent.includes('google cloud deception')) {
    results.push({
      type: 'Google Cloud Security蜜罐',
      evidence: '检测到GCP安全蜜罐特征',
      confidence: 'high'
    });
  }

  // Kubernetes/Docker蜜罐
  if (pageContent.includes('kubernetes honeypot') || pageContent.includes('docker honeypot') ||
      pageContent.includes('container honeypot')) {
    results.push({
      type: '容器化蜜罐',
      evidence: '检测到容器化蜜罐特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 云原生蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测AI/ML驱动的现代蜜罐
function detectAIHoneypots() {
  const results = [];
  console.log('🔍 开始AI/ML蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  // AI自适应蜜罐
  if (pageContent.includes('ai adaptive honeypot') || pageContent.includes('machine learning honeypot') ||
      pageContent.includes('neural network honeypot') || titleContent.includes('ai honeypot')) {
    results.push({
      type: 'AI自适应蜜罐',
      evidence: '检测到AI/ML驱动蜜罐特征',
      confidence: 'high'
    });
  }

  // 行为分析蜜罐
  if (pageContent.includes('behavioral honeypot') || pageContent.includes('behavior analysis honeypot')) {
    results.push({
      type: '行为分析蜜罐',
      evidence: '检测到行为分析蜜罐特征',
      confidence: 'high'
    });
  }

  // 深度学习蜜罐
  if (pageContent.includes('deep learning honeypot') || pageContent.includes('tensorflow honeypot') ||
      pageContent.includes('pytorch honeypot')) {
    results.push({
      type: '深度学习蜜罐',
      evidence: '检测到深度学习蜜罐特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 AI/ML蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测IoT和工控系统蜜罐
function detectIoTIndustrialHoneypots() {
  const results = [];
  console.log('🔍 开始IoT/工控蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();

  // IoT蜜罐
  if (pageContent.includes('iot honeypot') || pageContent.includes('internet of things honeypot')) {
    results.push({
      type: 'IoT设备蜜罐',
      evidence: '检测到IoT蜜罐特征',
      confidence: 'high'
    });
  }

  // SCADA蜜罐
  if (pageContent.includes('scada honeypot') || pageContent.includes('industrial control honeypot')) {
    results.push({
      type: 'SCADA工控蜜罐',
      evidence: '检测到SCADA蜜罐特征',
      confidence: 'high'
    });
  }

  // Modbus蜜罐
  if (pageContent.includes('modbus honeypot') || pageContent.includes('modbus simulation')) {
    results.push({
      type: 'Modbus协议蜜罐',
      evidence: '检测到Modbus蜜罐特征',
      confidence: 'high'
    });
  }

  // DNP3蜜罐
  if (pageContent.includes('dnp3 honeypot') || pageContent.includes('dnp3 simulation')) {
    results.push({
      type: 'DNP3协议蜜罐',
      evidence: '检测到DNP3蜜罐特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 IoT/工控蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测2025年新兴技术蜜罐
function detectEmergingTechHoneypots() {
  const results = [];
  console.log('🔍 开始新兴技术蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();
  const titleContent = document.title.toLowerCase();

  // 量子计算蜜罐
  if (pageContent.includes('quantum honeypot') || pageContent.includes('quantum deception') ||
      pageContent.includes('qbit honeypot')) {
    results.push({
      type: '量子计算蜜罐',
      evidence: '检测到量子计算蜜罐特征',
      confidence: 'high'
    });
  }

  // 区块链蜜罐
  if (pageContent.includes('blockchain honeypot') || pageContent.includes('crypto honeypot') ||
      pageContent.includes('defi honeypot')) {
    results.push({
      type: '区块链蜜罐',
      evidence: '检测到区块链蜜罐特征',
      confidence: 'high'
    });
  }

  // 元宇宙蜜罐
  if (pageContent.includes('metaverse honeypot') || pageContent.includes('vr honeypot') ||
      pageContent.includes('ar honeypot') || titleContent.includes('metaverse')) {
    results.push({
      type: '元宇宙蜜罐',
      evidence: '检测到元宇宙蜜罐特征',
      confidence: 'high'
    });
  }

  // 6G网络蜜罐
  if (pageContent.includes('6g honeypot') || pageContent.includes('sixth generation honeypot')) {
    results.push({
      type: '6G网络蜜罐',
      evidence: '检测到6G网络蜜罐特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 新兴技术蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 检测行业特定蜜罐
function detectIndustrySpecificHoneypots() {
  const results = [];
  console.log('🔍 开始行业特定蜜罐检测...');

  const pageContent = document.documentElement.outerHTML.toLowerCase();

  // 金融科技蜜罐
  if (pageContent.includes('fintech honeypot') || pageContent.includes('financial technology honeypot') ||
      pageContent.includes('banking honeypot')) {
    results.push({
      type: '金融科技蜜罐',
      evidence: '检测到金融科技蜜罐特征',
      confidence: 'high'
    });
  }

  // 医疗健康蜜罐
  if (pageContent.includes('healthcare honeypot') || pageContent.includes('medical honeypot') ||
      pageContent.includes('hospital honeypot')) {
    results.push({
      type: '医疗健康蜜罐',
      evidence: '检测到医疗健康蜜罐特征',
      confidence: 'high'
    });
  }

  // 汽车行业蜜罐
  if (pageContent.includes('automotive honeypot') || pageContent.includes('vehicle honeypot') ||
      pageContent.includes('car honeypot')) {
    results.push({
      type: '汽车行业蜜罐',
      evidence: '检测到汽车行业蜜罐特征',
      confidence: 'high'
    });
  }

  // 能源行业蜜罐
  if (pageContent.includes('energy honeypot') || pageContent.includes('power grid honeypot') ||
      pageContent.includes('utility honeypot')) {
    results.push({
      type: '能源行业蜜罐',
      evidence: '检测到能源行业蜜罐特征',
      confidence: 'high'
    });
  }

  // 航空航天蜜罐
  if (pageContent.includes('aerospace honeypot') || pageContent.includes('aviation honeypot') ||
      pageContent.includes('satellite honeypot')) {
    results.push({
      type: '航空航天蜜罐',
      evidence: '检测到航空航天蜜罐特征',
      confidence: 'high'
    });
  }

  console.log(`🔍 行业特定蜜罐检测完成，发现 ${results.length} 个特征`);
  return results.length > 0 ? results : null;
}

// 立即执行初始化
console.log('🚀 正在启动蜜罐检测模块...');
initHoneypotDetection();

// 添加全局调试函数
window.godanDebug = {
  // 手动触发检测
  runDetection: async function() {
    console.log('🔍 手动触发蜜罐检测...');
    return await performHoneypotDetection();
  },

  // 检查规则状态
  checkRules: function() {
    console.log('📋 检查规则状态...');
    console.log('printerData:', typeof printerData, Array.isArray(printerData) ? printerData.length : 'not array');
    console.log('LatestHoneypotRules2024:', typeof LatestHoneypotRules2024, Array.isArray(LatestHoneypotRules2024) ? LatestHoneypotRules2024.length : 'not array');
    console.log('AllHoneypotRules:', AllHoneypotRules.length);
    return {
      printerData: Array.isArray(printerData) ? printerData.length : 0,
      latestRules: Array.isArray(LatestHoneypotRules2024) ? LatestHoneypotRules2024.length : 0,
      totalRules: AllHoneypotRules.length
    };
  },

  // 检查白名单管理器
  checkWhitelist: function() {
    console.log('🛡️ 检查白名单管理器状态...');
    console.log('whitelistManager:', !!window.whitelistManager);
    console.log('whitelistManagerReady:', !!window.whitelistManagerReady);
    return {
      manager: !!window.whitelistManager,
      ready: !!window.whitelistManagerReady
    };
  },

  // 测试HFish检测
  testHFish: function() {
    console.log('🍯 测试HFish检测...');
    // 添加测试特征
    window.sec_key = "test_key_12345";
    window.login_field = "username";

    const result = detectHFishHoneypot();

    // 清理测试特征
    delete window.sec_key;
    delete window.login_field;

    return result;
  },

  // 强制检测（跳过白名单）
  forceDetection: async function() {
    console.log('🔥 强制执行蜜罐检测（跳过白名单）...');
    const allResults = [];

    try {
      // 1. 规则引擎检测
      const ruleResults = detectHoneypotByRules();
      allResults.push(...ruleResults);

      // 2. 高级特征检测
      const advancedResults = detectAdvancedHoneypotFeatures();
      allResults.push(...advancedResults);

      // 3. HFish检测
      const hfishResults = detectHFishHoneypot();
      if (hfishResults) {
        allResults.push(...(Array.isArray(hfishResults) ? hfishResults : [hfishResults]));
      }

      // 4. 默安检测
      const moanResults = detectMoanHoneypot();
      if (moanResults) {
        allResults.push(...(Array.isArray(moanResults) ? moanResults : [moanResults]));
      }

      console.log(`🎯 强制检测结果: ${allResults.length}条`);
      return allResults;

    } catch (error) {
      console.error('❌ 强制检测失败:', error);
      return [];
    }
  }
};

console.log('✅ 蜜罐检测模块加载完成');
console.log('🔧 调试工具可用: window.godanDebug');
console.log('📖 使用方法:');
console.log('  - window.godanDebug.runDetection() // 手动触发检测');
console.log('  - window.godanDebug.checkRules() // 检查规则状态');
console.log('  - window.godanDebug.testHFish() // 测试HFish检测');
console.log('  - window.godanDebug.forceDetection() // 强制检测（跳过白名单）');
