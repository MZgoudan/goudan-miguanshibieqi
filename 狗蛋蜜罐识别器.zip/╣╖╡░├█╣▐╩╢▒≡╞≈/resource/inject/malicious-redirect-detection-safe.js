/**
 * 狗蛋蜜罐识别器 - 安全版恶意页面跳转检测模块
 * 简化版本，避免所有可能的错误
 */

'use strict';

// 安全的恶意跳转检测配置
const SafeMaliciousRedirectConfig = {
  enabled: true,
  
  // 基础恶意域名黑名单
  maliciousDomains: [
    'phishing-site.com', 'fake-bank.net', 'scam-alert.org',
    'malware-download.com', 'virus-site.net', 'trojan-host.org',
    'ad-fraud.com', 'click-fraud.net', 'fake-ads.org'
  ],
  
  // 可疑URL模式
  suspiciousPatterns: [
    /bit\.ly\/[a-zA-Z0-9]+/,
    /tinyurl\.com\/[a-zA-Z0-9]+/,
    /t\.co\/[a-zA-Z0-9]+/
  ]
};

// 安全的日志记录
function safeLog(message, data) {
  try {
    console.log('狗蛋蜜罐识别器:', message, data || '');
  } catch (e) {
    // 忽略日志错误
  }
}

// 安全的URL检查
function isSuspiciousURL(url) {
  if (!url || typeof url !== 'string') return false;
  
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.toLowerCase();
    
    // 检查黑名单域名
    if (SafeMaliciousRedirectConfig.maliciousDomains.includes(hostname)) {
      return true;
    }
    
    // 检查可疑模式
    return SafeMaliciousRedirectConfig.suspiciousPatterns.some(pattern => {
      try {
        return pattern.test(url);
      } catch (e) {
        return false;
      }
    });
  } catch (e) {
    return false;
  }
}

// 安全的通知函数
function safeNotify(message) {
  try {
    // 尝试发送消息到background script
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'maliciousRedirectDetected',
        message: message,
        url: window.location.href,
        timestamp: Date.now()
      }, () => {
        // 忽略响应错误
        if (chrome.runtime.lastError) {
          safeLog('通知发送失败:', chrome.runtime.lastError.message);
        }
      });
    }
    
    // 控制台警告
    safeLog('检测到可疑跳转:', message);
  } catch (e) {
    safeLog('通知函数出错:', e.message);
  }
}

// 拦截location跳转
function interceptLocationRedirects() {
  try {
    const originalAssign = window.location.assign;
    const originalReplace = window.location.replace;
    const originalReload = window.location.reload;
    
    // 拦截assign
    if (originalAssign) {
      window.location.assign = function(url) {
        if (isSuspiciousURL(url)) {
          safeNotify(`拦截location.assign跳转: ${url}`);
          return;
        }
        return originalAssign.call(this, url);
      };
    }
    
    // 拦截replace
    if (originalReplace) {
      window.location.replace = function(url) {
        if (isSuspiciousURL(url)) {
          safeNotify(`拦截location.replace跳转: ${url}`);
          return;
        }
        return originalReplace.call(this, url);
      };
    }
    
    // 拦截href设置
    let currentHref = window.location.href;
    Object.defineProperty(window.location, 'href', {
      get: function() {
        return currentHref;
      },
      set: function(url) {
        if (isSuspiciousURL(url)) {
          safeNotify(`拦截location.href跳转: ${url}`);
          return;
        }
        currentHref = url;
        originalAssign.call(window.location, url);
      }
    });
    
    safeLog('location跳转拦截已设置');
  } catch (e) {
    safeLog('location跳转拦截设置失败:', e.message);
  }
}

// 拦截window.open
function interceptWindowOpen() {
  try {
    const originalOpen = window.open;
    
    if (originalOpen) {
      window.open = function(url, name, features) {
        if (isSuspiciousURL(url)) {
          safeNotify(`拦截window.open: ${url}`);
          return null;
        }
        return originalOpen.call(this, url, name, features);
      };
    }
    
    safeLog('window.open拦截已设置');
  } catch (e) {
    safeLog('window.open拦截设置失败:', e.message);
  }
}

// 检测meta refresh
function detectMetaRefresh() {
  try {
    const metaTags = document.querySelectorAll('meta[http-equiv="refresh"]');
    metaTags.forEach(meta => {
      const content = meta.getAttribute('content');
      if (content) {
        const urlMatch = content.match(/url=(.+)/i);
        if (urlMatch && isSuspiciousURL(urlMatch[1])) {
          safeNotify(`检测到可疑meta refresh: ${urlMatch[1]}`);
          meta.remove();
        }
      }
    });
    
    safeLog('meta refresh检测完成');
  } catch (e) {
    safeLog('meta refresh检测失败:', e.message);
  }
}

// 检测自动提交表单
function detectAutoSubmitForms() {
  try {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      const action = form.getAttribute('action');
      if (action && isSuspiciousURL(action)) {
        safeNotify(`检测到可疑表单提交: ${action}`);
        form.addEventListener('submit', function(e) {
          e.preventDefault();
          safeNotify(`阻止可疑表单提交: ${action}`);
        });
      }
    });
    
    safeLog('自动提交表单检测完成');
  } catch (e) {
    safeLog('自动提交表单检测失败:', e.message);
  }
}

// 监听DOM变化
function setupMutationObserver() {
  try {
    if (!window.MutationObserver) {
      safeLog('MutationObserver不支持');
      return;
    }
    
    const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach(function(node) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检测新添加的meta标签
              if (node.tagName === 'META' && node.getAttribute('http-equiv') === 'refresh') {
                const content = node.getAttribute('content');
                if (content) {
                  const urlMatch = content.match(/url=(.+)/i);
                  if (urlMatch && isSuspiciousURL(urlMatch[1])) {
                    safeNotify(`检测到动态添加的可疑meta refresh: ${urlMatch[1]}`);
                    node.remove();
                  }
                }
              }
            }
          });
        }
      });
    });
    
    observer.observe(document, {
      childList: true,
      subtree: true
    });
    
    safeLog('DOM变化监听已设置');
  } catch (e) {
    safeLog('DOM变化监听设置失败:', e.message);
  }
}

// 安全的初始化函数
function initSafeMaliciousRedirectDetection() {
  if (!SafeMaliciousRedirectConfig.enabled) {
    safeLog('恶意跳转检测已禁用');
    return;
  }
  
  try {
    safeLog('开始初始化恶意跳转检测模块');
    
    // 设置各种拦截
    interceptLocationRedirects();
    interceptWindowOpen();
    
    // 检测现有内容
    detectMetaRefresh();
    detectAutoSubmitForms();
    
    // 设置DOM监听
    setupMutationObserver();
    
    safeLog('恶意跳转检测模块初始化完成');
  } catch (error) {
    safeLog('恶意跳转检测模块启动失败:', error.message);
  }
}

// 安全的页面加载检测
function safeInit() {
  try {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initSafeMaliciousRedirectDetection);
    } else {
      initSafeMaliciousRedirectDetection();
    }
  } catch (e) {
    safeLog('初始化调度失败:', e.message);
    // 延迟重试
    setTimeout(initSafeMaliciousRedirectDetection, 1000);
  }
}

// 立即执行安全初始化
safeInit();
