/**
 * 狗蛋蜜罐识别器 - 恶意页面跳转检测模块
 * 检测和拦截各种恶意页面跳转行为
 */

'use strict';

// ========== 恶意跳转检测配置 ==========
const MaliciousRedirectConfig = {
  enabled: true,
  
  // 恶意域名黑名单
  maliciousDomains: [
    // 钓鱼网站常用域名
    'phishing-site.com', 'fake-bank.net', 'scam-alert.org',
    // 恶意软件下载站点
    'malware-download.com', 'virus-site.net', 'trojan-host.org',
    // 广告欺诈域名
    'ad-fraud.com', 'click-fraud.net', 'fake-ads.org',
    // 加密货币诈骗
    'crypto-scam.com', 'fake-exchange.net', 'ponzi-scheme.org',
    // 社工钓鱼
    'social-engineering.com', 'fake-support.net', 'tech-scam.org'
  ],
  
  // 可疑URL模式
  suspiciousPatterns: [
    /bit\.ly\/[a-zA-Z0-9]+/,           // 短链接
    /tinyurl\.com\/[a-zA-Z0-9]+/,     // 短链接
    /t\.co\/[a-zA-Z0-9]+/,            // Twitter短链接
    /goo\.gl\/[a-zA-Z0-9]+/,          // Google短链接
    /[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/, // IP地址
    /[a-zA-Z0-9-]+\.tk$/,             // 免费域名
    /[a-zA-Z0-9-]+\.ml$/,             // 免费域名
    /[a-zA-Z0-9-]+\.ga$/,             // 免费域名
    /[a-zA-Z0-9-]+\.cf$/,             // 免费域名
    /download.*\.exe$/i,              // 可执行文件下载
    /install.*\.msi$/i,               // 安装包下载
    /update.*\.zip$/i,                // 更新包下载
    /urgent.*action/i,                // 紧急行动类
    /verify.*account/i,               // 账户验证类
    /suspended.*account/i,            // 账户暂停类
    /click.*here.*now/i,              // 点击诱导类
    /limited.*time.*offer/i,          // 限时优惠类
    /congratulations.*winner/i,       // 中奖诈骗类
    /security.*alert/i,               // 安全警报类
    /virus.*detected/i,               // 病毒检测类
    /system.*infected/i               // 系统感染类
  ],
  
  // 跳转方式检测
  redirectMethods: [
    'location.href',
    'location.replace',
    'location.assign',
    'window.open',
    'document.location',
    'top.location',
    'parent.location',
    'self.location',
    'history.pushState',
    'history.replaceState'
  ],
  
  // 时间阈值（毫秒）
  timeThresholds: {
    rapidRedirect: 1000,    // 快速跳转阈值
    delayedRedirect: 30000, // 延迟跳转阈值
    multipleRedirect: 5000  // 多次跳转时间窗口
  },
  
  // 跳转计数器
  redirectCounter: new Map(),
  
  // 白名单域名
  whitelistDomains: [
    'google.com', 'baidu.com', 'bing.com', 'yahoo.com',
    'github.com', 'stackoverflow.com', 'mozilla.org',
    'microsoft.com', 'apple.com', 'amazon.com'
  ]
};

// ========== 跳转检测状态管理 ==========
class RedirectDetectionState {
  constructor() {
    this.redirectHistory = [];
    this.lastRedirectTime = 0;
    this.redirectCount = 0;
    this.suspiciousRedirects = [];
    this.blockedRedirects = [];
  }
  
  addRedirect(url, method, timestamp) {
    this.redirectHistory.push({
      url: url,
      method: method,
      timestamp: timestamp
    });
    
    // 保持历史记录在合理范围内
    if (this.redirectHistory.length > 50) {
      this.redirectHistory.shift();
    }
    
    this.lastRedirectTime = timestamp;
    this.redirectCount++;
  }
  
  isRapidRedirect(timestamp) {
    return timestamp - this.lastRedirectTime < MaliciousRedirectConfig.timeThresholds.rapidRedirect;
  }
  
  getRecentRedirects(timeWindow) {
    const cutoff = Date.now() - timeWindow;
    return this.redirectHistory.filter(r => r.timestamp > cutoff);
  }
}

const redirectState = new RedirectDetectionState();

// ========== 核心检测函数 ==========

// 检查域名是否为恶意域名
function isMaliciousDomain(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    return MaliciousRedirectConfig.maliciousDomains.some(domain => 
      hostname.includes(domain.toLowerCase())
    );
  } catch (error) {
    return false;
  }
}

// 检查URL是否匹配可疑模式
function matchesSuspiciousPattern(url) {
  return MaliciousRedirectConfig.suspiciousPatterns.some(pattern => 
    pattern.test(url)
  );
}

// 检查域名是否在白名单中
function isWhitelistedDomain(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    return MaliciousRedirectConfig.whitelistDomains.some(domain => 
      hostname.endsWith(domain.toLowerCase())
    );
  } catch (error) {
    return false;
  }
}

// 分析跳转风险等级
function analyzeRedirectRisk(url, method, timestamp) {
  let riskScore = 0;
  let riskFactors = [];
  
  // 恶意域名检查
  if (isMaliciousDomain(url)) {
    riskScore += 100;
    riskFactors.push('恶意域名');
  }
  
  // 可疑模式检查
  if (matchesSuspiciousPattern(url)) {
    riskScore += 50;
    riskFactors.push('可疑URL模式');
  }
  
  // 白名单检查
  if (isWhitelistedDomain(url)) {
    riskScore -= 30;
    riskFactors.push('白名单域名');
  }
  
  // 快速跳转检查
  if (redirectState.isRapidRedirect(timestamp)) {
    riskScore += 30;
    riskFactors.push('快速跳转');
  }
  
  // 多次跳转检查
  const recentRedirects = redirectState.getRecentRedirects(
    MaliciousRedirectConfig.timeThresholds.multipleRedirect
  );
  if (recentRedirects.length > 3) {
    riskScore += 40;
    riskFactors.push('频繁跳转');
  }
  
  // 跳转方法风险评估
  const highRiskMethods = ['window.open', 'location.replace'];
  if (highRiskMethods.includes(method)) {
    riskScore += 20;
    riskFactors.push('高风险跳转方法');
  }
  
  // IP地址直接访问
  if (/^\d+\.\d+\.\d+\.\d+/.test(url)) {
    riskScore += 35;
    riskFactors.push('IP地址访问');
  }
  
  // 确定风险等级
  let riskLevel;
  if (riskScore >= 80) {
    riskLevel = 'high';
  } else if (riskScore >= 40) {
    riskLevel = 'medium';
  } else if (riskScore >= 20) {
    riskLevel = 'low';
  } else {
    riskLevel = 'safe';
  }
  
  return {
    score: riskScore,
    level: riskLevel,
    factors: riskFactors
  };
}

// 拦截恶意跳转
function blockMaliciousRedirect(url, method, risk) {
  // 记录被拦截的跳转
  redirectState.blockedRedirects.push({
    url: url,
    method: method,
    risk: risk,
    timestamp: Date.now()
  });
  
  // 显示拦截页面
  document.documentElement.innerHTML = `
    <html>
      <head>
        <title>恶意跳转已拦截</title>
        <style>
          body {
            font-family: 'Microsoft YaHei', sans-serif;
            text-align: center;
            padding: 50px;
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            color: white;
            margin: 0;
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
          }
          .icon { font-size: 64px; margin-bottom: 20px; }
          .title { font-size: 28px; margin-bottom: 15px; }
          .subtitle { font-size: 18px; margin-bottom: 25px; opacity: 0.9; }
          .details {
            background: rgba(0,0,0,0.2);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: left;
          }
          .risk-high { border-left: 4px solid #e74c3c; }
          .risk-medium { border-left: 4px solid #f39c12; }
          .risk-low { border-left: 4px solid #f1c40f; }
          .button {
            background: rgba(255,255,255,0.2);
            border: 2px solid white;
            color: white;
            padding: 12px 24px;
            border-radius: 25px;
            cursor: pointer;
            margin: 10px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
          }
          .button:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
          }
          .url { word-break: break-all; font-family: monospace; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="icon">🛡️</div>
          <div class="title">狗蛋蜜罐识别器</div>
          <div class="subtitle">恶意页面跳转已被拦截</div>
          
          <div class="details risk-${risk.level}">
            <h3>🚨 威胁详情</h3>
            <p><strong>目标URL:</strong> <span class="url">${url}</span></p>
            <p><strong>跳转方法:</strong> ${method}</p>
            <p><strong>风险等级:</strong> ${risk.level.toUpperCase()}</p>
            <p><strong>风险评分:</strong> ${risk.score}/100</p>
            <p><strong>风险因素:</strong> ${risk.factors.join(', ')}</p>
            <p><strong>拦截时间:</strong> ${new Date().toLocaleString()}</p>
          </div>
          
          <div>
            <button class="button" id="goBackBtn">🔙 返回上一页</button>
            <button class="button" id="closePageBtn">❌ 关闭页面</button>
          </div>
          <script>
            document.getElementById('goBackBtn').addEventListener('click', () => history.back());
            document.getElementById('closePageBtn').addEventListener('click', () => window.close());
          </script>
          
          <p style="font-size: 12px; margin-top: 30px; opacity: 0.7;">
            如果您认为这是误报，请检查URL的安全性后手动访问
          </p>
        </div>
      </body>
    </html>
  `;
  
  // 发送检测结果到background script
  window.top.postMessage({
    msgType: "maliciousRedirect",
    msgData: {
      url: url,
      method: method,
      risk: risk,
      action: 'blocked',
      timestamp: Date.now()
    }
  }, '*');
  
  return true;
}

// 记录可疑跳转
function recordSuspiciousRedirect(url, method, risk) {
  redirectState.suspiciousRedirects.push({
    url: url,
    method: method,
    risk: risk,
    timestamp: Date.now()
  });
  
  // 发送检测结果到background script
  window.top.postMessage({
    msgType: "maliciousRedirect",
    msgData: {
      url: url,
      method: method,
      risk: risk,
      action: 'detected',
      timestamp: Date.now()
    }
  }, '*');
}

// ========== 跳转方法拦截 ==========

// 拦截location相关跳转
function interceptLocationRedirects() {
  const originalLocationHref = Object.getOwnPropertyDescriptor(Location.prototype, 'href');
  const originalReplace = Location.prototype.replace;
  const originalAssign = Location.prototype.assign;
  
  // 拦截location.href设置
  Object.defineProperty(Location.prototype, 'href', {
    get: originalLocationHref.get,
    set: function(url) {
      const timestamp = Date.now();
      const risk = analyzeRedirectRisk(url, 'location.href', timestamp);
      
      redirectState.addRedirect(url, 'location.href', timestamp);
      
      if (risk.level === 'high') {
        return blockMaliciousRedirect(url, 'location.href', risk);
      } else if (risk.level === 'medium') {
        recordSuspiciousRedirect(url, 'location.href', risk);
      }
      
      return originalLocationHref.set.call(this, url);
    }
  });
  
  // 拦截location.replace
  Location.prototype.replace = function(url) {
    const timestamp = Date.now();
    const risk = analyzeRedirectRisk(url, 'location.replace', timestamp);
    
    redirectState.addRedirect(url, 'location.replace', timestamp);
    
    if (risk.level === 'high') {
      return blockMaliciousRedirect(url, 'location.replace', risk);
    } else if (risk.level === 'medium') {
      recordSuspiciousRedirect(url, 'location.replace', risk);
    }
    
    return originalReplace.call(this, url);
  };
  
  // 拦截location.assign
  Location.prototype.assign = function(url) {
    const timestamp = Date.now();
    const risk = analyzeRedirectRisk(url, 'location.assign', timestamp);
    
    redirectState.addRedirect(url, 'location.assign', timestamp);
    
    if (risk.level === 'high') {
      return blockMaliciousRedirect(url, 'location.assign', risk);
    } else if (risk.level === 'medium') {
      recordSuspiciousRedirect(url, 'location.assign', risk);
    }
    
    return originalAssign.call(this, url);
  };
}

// 拦截window.open
function interceptWindowOpen() {
  const originalOpen = window.open;
  
  window.open = function(url, name, features) {
    if (url) {
      const timestamp = Date.now();
      const risk = analyzeRedirectRisk(url, 'window.open', timestamp);
      
      redirectState.addRedirect(url, 'window.open', timestamp);
      
      if (risk.level === 'high') {
        blockMaliciousRedirect(url, 'window.open', risk);
        return null;
      } else if (risk.level === 'medium') {
        recordSuspiciousRedirect(url, 'window.open', risk);
      }
    }
    
    return originalOpen.call(this, url, name, features);
  };
}

// 拦截History API
function interceptHistoryAPI() {
  const originalPushState = History.prototype.pushState;
  const originalReplaceState = History.prototype.replaceState;
  
  History.prototype.pushState = function(state, title, url) {
    if (url) {
      const timestamp = Date.now();
      const risk = analyzeRedirectRisk(url, 'history.pushState', timestamp);
      
      redirectState.addRedirect(url, 'history.pushState', timestamp);
      
      if (risk.level === 'medium' || risk.level === 'high') {
        recordSuspiciousRedirect(url, 'history.pushState', risk);
      }
    }
    
    return originalPushState.call(this, state, title, url);
  };
  
  History.prototype.replaceState = function(state, title, url) {
    if (url) {
      const timestamp = Date.now();
      const risk = analyzeRedirectRisk(url, 'history.replaceState', timestamp);
      
      redirectState.addRedirect(url, 'history.replaceState', timestamp);
      
      if (risk.level === 'medium' || risk.level === 'high') {
        recordSuspiciousRedirect(url, 'history.replaceState', risk);
      }
    }
    
    return originalReplaceState.call(this, state, title, url);
  };
}

// ========== Meta刷新和自动跳转检测 ==========

// 检测Meta刷新跳转
function detectMetaRefresh() {
  const metaTags = document.querySelectorAll('meta[http-equiv="refresh"]');
  
  metaTags.forEach(meta => {
    const content = meta.getAttribute('content');
    if (content) {
      const match = content.match(/url=(.+)/i);
      if (match) {
        const url = match[1];
        const timestamp = Date.now();
        const risk = analyzeRedirectRisk(url, 'meta-refresh', timestamp);
        
        redirectState.addRedirect(url, 'meta-refresh', timestamp);
        
        if (risk.level === 'high') {
          meta.remove();
          blockMaliciousRedirect(url, 'meta-refresh', risk);
        } else if (risk.level === 'medium') {
          recordSuspiciousRedirect(url, 'meta-refresh', risk);
        }
      }
    }
  });
}

// 检测自动提交表单
function detectAutoSubmitForms() {
  const forms = document.querySelectorAll('form[action]');
  
  forms.forEach(form => {
    const action = form.getAttribute('action');
    if (action && action !== '#' && action !== '') {
      const timestamp = Date.now();
      const risk = analyzeRedirectRisk(action, 'form-submit', timestamp);
      
      if (risk.level === 'high') {
        form.addEventListener('submit', function(e) {
          e.preventDefault();
          blockMaliciousRedirect(action, 'form-submit', risk);
        });
      } else if (risk.level === 'medium') {
        recordSuspiciousRedirect(action, 'form-submit', risk);
      }
    }
  });
}

// ========== 初始化恶意跳转检测 ==========
function initMaliciousRedirectDetection() {
  if (!MaliciousRedirectConfig.enabled) return;
  
  try {
    // 拦截各种跳转方法
    interceptLocationRedirects();
    interceptWindowOpen();
    interceptHistoryAPI();
    
    // 检测页面中的自动跳转
    detectMetaRefresh();
    detectAutoSubmitForms();
    
    // 监听DOM变化，检测动态添加的跳转元素
    const observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach(function(node) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检测新添加的meta标签
              if (node.tagName === 'META' && node.getAttribute('http-equiv') === 'refresh') {
                detectMetaRefresh();
              }
              // 检测新添加的表单
              if (node.tagName === 'FORM') {
                detectAutoSubmitForms();
              }
              // 检测子元素中的meta和form
              const metaTags = node.querySelectorAll('meta[http-equiv="refresh"]');
              const forms = node.querySelectorAll('form[action]');
              if (metaTags.length > 0) detectMetaRefresh();
              if (forms.length > 0) detectAutoSubmitForms();
            }
          });
        }
      });
    });
    
    observer.observe(document, {
      childList: true,
      subtree: true
    });
    
    console.log('狗蛋蜜罐识别器: 恶意跳转检测模块已启动');
    
  } catch (error) {
    console.warn('狗蛋蜜罐识别器: 恶意跳转检测模块启动失败', error);
  }
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initMaliciousRedirectDetection);
} else {
  initMaliciousRedirectDetection();
}
