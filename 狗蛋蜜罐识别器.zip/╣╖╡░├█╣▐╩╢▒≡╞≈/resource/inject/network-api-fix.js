/**
 * 网络API错误修复脚本
 * 专门修复"Cannot read properties of undefined (reading 'network')"错误
 */

(function() {
    'use strict';
    
    console.log('🔧 网络API错误修复脚本开始加载...');
    
    // 1. 修复chrome.privacy.network访问错误
    function fixChromePrivacyNetwork() {
        try {
            if (typeof chrome !== 'undefined') {
                // 如果chrome.privacy不存在，创建安全代理
                if (!chrome.privacy) {
                    console.log('创建chrome.privacy安全代理');
                    chrome.privacy = {};
                }
                
                // 如果chrome.privacy.network不存在，创建安全代理
                if (!chrome.privacy.network) {
                    console.log('创建chrome.privacy.network安全代理');
                    chrome.privacy.network = {
                        webRTCIPHandlingPolicy: {
                            get: function(details, callback) {
                                console.log('chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（修复代理）');
                                if (callback && typeof callback === 'function') {
                                    setTimeout(() => {
                                        callback({ value: 'default' });
                                    }, 0);
                                }
                            },
                            set: function(details, callback) {
                                console.log('chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（修复代理）');
                                if (callback && typeof callback === 'function') {
                                    setTimeout(callback, 0);
                                }
                            }
                        }
                    };
                }
            }
        } catch (error) {
            console.warn('修复chrome.privacy.network失败:', error);
        }
    }
    
    // 2. 修复navigator.connection访问错误
    function fixNavigatorConnection() {
        try {
            if (typeof navigator !== 'undefined') {
                // 如果navigator.connection不存在，创建安全代理
                if (!navigator.connection && !navigator.mozConnection && !navigator.webkitConnection) {
                    console.log('创建navigator.connection安全代理');
                    
                    const fakeConnection = {
                        effectiveType: '4g',
                        downlink: 10,
                        rtt: 50,
                        saveData: false,
                        type: 'cellular',
                        addEventListener: function() {},
                        removeEventListener: function() {}
                    };
                    
                    // 尝试定义navigator.connection
                    try {
                        Object.defineProperty(navigator, 'connection', {
                            value: fakeConnection,
                            writable: false,
                            configurable: true
                        });
                    } catch (e) {
                        console.warn('无法定义navigator.connection:', e);
                    }
                }
            }
        } catch (error) {
            console.warn('修复navigator.connection失败:', error);
        }
    }
    
    // 3. 全局错误拦截器
    function setupGlobalErrorInterceptor() {
        // 拦截全局错误
        const originalErrorHandler = window.onerror;
        window.onerror = function(message, source, lineno, colno, error) {
            if (message && message.includes("Cannot read properties of undefined (reading 'network')")) {
                console.warn('🔧 拦截到network访问错误，尝试修复...');
                
                // 立即修复
                fixChromePrivacyNetwork();
                fixNavigatorConnection();
                
                // 阻止错误继续传播
                return true;
            }
            
            // 调用原始错误处理器
            if (originalErrorHandler) {
                return originalErrorHandler.apply(this, arguments);
            }
            
            return false;
        };
        
        // 拦截未处理的Promise拒绝
        window.addEventListener('unhandledrejection', function(event) {
            const reason = event.reason;
            if (reason && reason.message && reason.message.includes("Cannot read properties of undefined (reading 'network')")) {
                console.warn('🔧 拦截到Promise中的network访问错误，尝试修复...');
                
                // 立即修复
                fixChromePrivacyNetwork();
                fixNavigatorConnection();
                
                // 阻止错误显示
                event.preventDefault();
            }
        });
    }
    
    // 4. 安全的属性访问包装器
    function createSafeAccessors() {
        // 安全访问chrome.privacy.network
        window.safePrivacyNetworkAccess = function(callback) {
            try {
                if (chrome && chrome.privacy && chrome.privacy.network && chrome.privacy.network.webRTCIPHandlingPolicy) {
                    return chrome.privacy.network.webRTCIPHandlingPolicy;
                } else {
                    console.warn('chrome.privacy.network不可用，使用安全代理');
                    fixChromePrivacyNetwork();
                    return chrome.privacy.network.webRTCIPHandlingPolicy;
                }
            } catch (error) {
                console.error('安全访问chrome.privacy.network失败:', error);
                return null;
            }
        };
        
        // 安全访问navigator.connection
        window.safeConnectionAccess = function() {
            try {
                const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
                if (connection) {
                    return connection;
                } else {
                    console.warn('navigator.connection不可用，使用安全代理');
                    fixNavigatorConnection();
                    return navigator.connection;
                }
            } catch (error) {
                console.error('安全访问navigator.connection失败:', error);
                return null;
            }
        };
    }
    
    // 5. 重写可能出错的API调用
    function patchProblematicAPIs() {
        // 重写可能访问chrome.privacy.network的代码
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
            const originalAddListener = chrome.runtime.onMessage.addListener;
            chrome.runtime.onMessage.addListener = function(listener) {
                const safeListener = function(request, sender, sendResponse) {
                    try {
                        return listener(request, sender, sendResponse);
                    } catch (error) {
                        if (error.message && error.message.includes("Cannot read properties of undefined (reading 'network')")) {
                            console.warn('🔧 消息监听器中的network访问错误已修复');
                            fixChromePrivacyNetwork();
                            fixNavigatorConnection();
                            
                            // 重试
                            try {
                                return listener(request, sender, sendResponse);
                            } catch (retryError) {
                                console.error('重试后仍然失败:', retryError);
                                if (sendResponse) {
                                    sendResponse({ success: false, error: 'Network API访问错误' });
                                }
                            }
                        } else {
                            throw error;
                        }
                    }
                };
                
                return originalAddListener.call(this, safeListener);
            };
        }
    }
    
    // 6. 初始化所有修复
    function initializeNetworkAPIFixes() {
        console.log('🔧 初始化网络API错误修复...');
        
        try {
            // 立即修复
            fixChromePrivacyNetwork();
            fixNavigatorConnection();
            
            // 设置错误拦截
            setupGlobalErrorInterceptor();
            
            // 创建安全访问器
            createSafeAccessors();
            
            // 修补有问题的API
            patchProblematicAPIs();
            
            console.log('✅ 网络API错误修复初始化完成');
        } catch (error) {
            console.error('❌ 网络API错误修复初始化失败:', error);
        }
    }
    
    // 7. 立即执行修复
    initializeNetworkAPIFixes();
    
    // 8. 页面加载完成后再次确保修复
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeNetworkAPIFixes);
    } else {
        // DOM已加载，延迟执行确保其他脚本已加载
        setTimeout(initializeNetworkAPIFixes, 100);
    }
    
    // 9. 定期检查和修复
    setInterval(() => {
        try {
            if (typeof chrome !== 'undefined' && (!chrome.privacy || !chrome.privacy.network)) {
                console.log('🔧 定期检查发现network API缺失，重新修复...');
                fixChromePrivacyNetwork();
            }
            
            if (typeof navigator !== 'undefined' && !navigator.connection && !navigator.mozConnection && !navigator.webkitConnection) {
                console.log('🔧 定期检查发现connection API缺失，重新修复...');
                fixNavigatorConnection();
            }
        } catch (error) {
            console.warn('定期检查修复失败:', error);
        }
    }, 5000); // 每5秒检查一次
    
    console.log('✅ 网络API错误修复脚本加载完成');
    
})();
