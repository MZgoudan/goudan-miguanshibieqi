/**
 * 狗蛋蜜罐识别器 - 黑白名单管理模块
 * 作者: 蜜汁狗蛋
 * 版本: 1.0
 * 
 * 功能: 管理白名单和黑名单，防止误识别正常业务
 */

'use strict';

class WhitelistManager {
    constructor() {
        this.whitelist = new Set();
        this.blacklist = new Set();
        this.domainWhitelist = new Set();
        this.domainBlacklist = new Set();
        this.keywordWhitelist = new Set();
        this.keywordBlacklist = new Set();
        
        // 默认白名单 - 常见正常业务域名
        this.defaultWhitelist = [
            'google.com',
            'baidu.com',
            'github.com',
            'stackoverflow.com',
            'microsoft.com',
            'apple.com',
            'amazon.com',
            'taobao.com',
            'tmall.com',
            'jd.com',
            'qq.com',
            'weibo.com',
            'zhihu.com',
            'csdn.net',
            'cnblogs.com',
            'segmentfault.com',
            'juejin.cn',
            'oschina.net'
        ];
        
        // 默认黑名单 - 已知蜜罐域名模式
        this.defaultBlacklist = [
            'honeypot',
            'hfish',
            'canary',
            'trap',
            'fake',
            'decoy',
            'bait'
        ];
        
        this.init();
    }
    
    async init() {
        await this.loadFromStorage();
        this.setupDefaultLists();
        console.log('🛡️ 黑白名单管理器初始化完成');
    }
    
    // 设置默认列表
    setupDefaultLists() {
        // 添加默认白名单域名
        this.defaultWhitelist.forEach(domain => {
            this.domainWhitelist.add(domain);
        });
        
        // 添加默认黑名单关键词
        this.defaultBlacklist.forEach(keyword => {
            this.keywordBlacklist.add(keyword);
        });
    }
    
    // 从存储加载配置
    async loadFromStorage() {
        try {
            const result = await chrome.storage.local.get([
                'whitelist',
                'blacklist', 
                'domainWhitelist',
                'domainBlacklist',
                'keywordWhitelist',
                'keywordBlacklist'
            ]);
            
            if (result.whitelist) {
                this.whitelist = new Set(result.whitelist);
            }
            if (result.blacklist) {
                this.blacklist = new Set(result.blacklist);
            }
            if (result.domainWhitelist) {
                this.domainWhitelist = new Set(result.domainWhitelist);
            }
            if (result.domainBlacklist) {
                this.domainBlacklist = new Set(result.domainBlacklist);
            }
            if (result.keywordWhitelist) {
                this.keywordWhitelist = new Set(result.keywordWhitelist);
            }
            if (result.keywordBlacklist) {
                this.keywordBlacklist = new Set(result.keywordBlacklist);
            }
            
        } catch (error) {
            console.warn('⚠️ 加载黑白名单配置失败:', error);
        }
    }
    
    // 保存到存储
    async saveToStorage() {
        try {
            await chrome.storage.local.set({
                whitelist: Array.from(this.whitelist),
                blacklist: Array.from(this.blacklist),
                domainWhitelist: Array.from(this.domainWhitelist),
                domainBlacklist: Array.from(this.domainBlacklist),
                keywordWhitelist: Array.from(this.keywordWhitelist),
                keywordBlacklist: Array.from(this.keywordBlacklist)
            });
            console.log('💾 黑白名单配置已保存');
        } catch (error) {
            console.error('❌ 保存黑白名单配置失败:', error);
        }
    }
    
    // 检查URL是否在白名单中
    isWhitelisted(url) {
        try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname;
            const fullUrl = url.toLowerCase();
            
            // 检查完整URL白名单
            if (this.whitelist.has(fullUrl)) {
                return { isWhitelisted: true, reason: '完整URL在白名单中' };
            }
            
            // 检查域名白名单
            for (let domain of this.domainWhitelist) {
                if (hostname.includes(domain.toLowerCase())) {
                    return { isWhitelisted: true, reason: `域名匹配白名单: ${domain}` };
                }
            }
            
            // 检查关键词白名单
            for (let keyword of this.keywordWhitelist) {
                if (fullUrl.includes(keyword.toLowerCase())) {
                    return { isWhitelisted: true, reason: `关键词匹配白名单: ${keyword}` };
                }
            }
            
            return { isWhitelisted: false };
            
        } catch (error) {
            console.warn('⚠️ 白名单检查失败:', error);
            return { isWhitelisted: false };
        }
    }
    
    // 检查URL是否在黑名单中
    isBlacklisted(url) {
        try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname;
            const fullUrl = url.toLowerCase();
            
            // 检查完整URL黑名单
            if (this.blacklist.has(fullUrl)) {
                return { isBlacklisted: true, reason: '完整URL在黑名单中' };
            }
            
            // 检查域名黑名单
            for (let domain of this.domainBlacklist) {
                if (hostname.includes(domain.toLowerCase())) {
                    return { isBlacklisted: true, reason: `域名匹配黑名单: ${domain}` };
                }
            }
            
            // 检查关键词黑名单
            for (let keyword of this.keywordBlacklist) {
                if (fullUrl.includes(keyword.toLowerCase())) {
                    return { isBlacklisted: true, reason: `关键词匹配黑名单: ${keyword}` };
                }
            }
            
            return { isBlacklisted: false };
            
        } catch (error) {
            console.warn('⚠️ 黑名单检查失败:', error);
            return { isBlacklisted: false };
        }
    }
    
    // 添加到白名单
    async addToWhitelist(url, type = 'url') {
        try {
            const cleanUrl = url.trim().toLowerCase();
            
            switch (type) {
                case 'url':
                    this.whitelist.add(cleanUrl);
                    break;
                case 'domain':
                    this.domainWhitelist.add(cleanUrl);
                    break;
                case 'keyword':
                    this.keywordWhitelist.add(cleanUrl);
                    break;
            }
            
            await this.saveToStorage();
            console.log(`✅ 已添加到白名单 (${type}): ${cleanUrl}`);
            return true;
            
        } catch (error) {
            console.error('❌ 添加白名单失败:', error);
            return false;
        }
    }
    
    // 添加到黑名单
    async addToBlacklist(url, type = 'url') {
        try {
            const cleanUrl = url.trim().toLowerCase();
            
            switch (type) {
                case 'url':
                    this.blacklist.add(cleanUrl);
                    break;
                case 'domain':
                    this.domainBlacklist.add(cleanUrl);
                    break;
                case 'keyword':
                    this.keywordBlacklist.add(cleanUrl);
                    break;
            }
            
            await this.saveToStorage();
            console.log(`✅ 已添加到黑名单 (${type}): ${cleanUrl}`);
            return true;
            
        } catch (error) {
            console.error('❌ 添加黑名单失败:', error);
            return false;
        }
    }
    
    // 从白名单移除
    async removeFromWhitelist(url, type = 'url') {
        try {
            const cleanUrl = url.trim().toLowerCase();
            
            switch (type) {
                case 'url':
                    this.whitelist.delete(cleanUrl);
                    break;
                case 'domain':
                    this.domainWhitelist.delete(cleanUrl);
                    break;
                case 'keyword':
                    this.keywordWhitelist.delete(cleanUrl);
                    break;
            }
            
            await this.saveToStorage();
            console.log(`🗑️ 已从白名单移除 (${type}): ${cleanUrl}`);
            return true;
            
        } catch (error) {
            console.error('❌ 移除白名单失败:', error);
            return false;
        }
    }
    
    // 从黑名单移除
    async removeFromBlacklist(url, type = 'url') {
        try {
            const cleanUrl = url.trim().toLowerCase();
            
            switch (type) {
                case 'url':
                    this.blacklist.delete(cleanUrl);
                    break;
                case 'domain':
                    this.domainBlacklist.delete(cleanUrl);
                    break;
                case 'keyword':
                    this.keywordBlacklist.delete(cleanUrl);
                    break;
            }
            
            await this.saveToStorage();
            console.log(`🗑️ 已从黑名单移除 (${type}): ${cleanUrl}`);
            return true;
            
        } catch (error) {
            console.error('❌ 移除黑名单失败:', error);
            return false;
        }
    }
    
    // 获取所有列表
    getAllLists() {
        return {
            whitelist: Array.from(this.whitelist),
            blacklist: Array.from(this.blacklist),
            domainWhitelist: Array.from(this.domainWhitelist),
            domainBlacklist: Array.from(this.domainBlacklist),
            keywordWhitelist: Array.from(this.keywordWhitelist),
            keywordBlacklist: Array.from(this.keywordBlacklist)
        };
    }
    
    // 清空指定列表
    async clearList(listType) {
        try {
            switch (listType) {
                case 'whitelist':
                    this.whitelist.clear();
                    break;
                case 'blacklist':
                    this.blacklist.clear();
                    break;
                case 'domainWhitelist':
                    this.domainWhitelist.clear();
                    break;
                case 'domainBlacklist':
                    this.domainBlacklist.clear();
                    break;
                case 'keywordWhitelist':
                    this.keywordWhitelist.clear();
                    break;
                case 'keywordBlacklist':
                    this.keywordBlacklist.clear();
                    break;
            }
            
            await this.saveToStorage();
            console.log(`🗑️ 已清空列表: ${listType}`);
            return true;
            
        } catch (error) {
            console.error('❌ 清空列表失败:', error);
            return false;
        }
    }
    
    // 导入列表
    async importList(listType, items) {
        try {
            const itemsArray = Array.isArray(items) ? items : items.split('\n').filter(item => item.trim());
            
            for (let item of itemsArray) {
                const cleanItem = item.trim().toLowerCase();
                if (cleanItem) {
                    switch (listType) {
                        case 'whitelist':
                            this.whitelist.add(cleanItem);
                            break;
                        case 'blacklist':
                            this.blacklist.add(cleanItem);
                            break;
                        case 'domainWhitelist':
                            this.domainWhitelist.add(cleanItem);
                            break;
                        case 'domainBlacklist':
                            this.domainBlacklist.add(cleanItem);
                            break;
                        case 'keywordWhitelist':
                            this.keywordWhitelist.add(cleanItem);
                            break;
                        case 'keywordBlacklist':
                            this.keywordBlacklist.add(cleanItem);
                            break;
                    }
                }
            }
            
            await this.saveToStorage();
            console.log(`📥 已导入 ${itemsArray.length} 个项目到 ${listType}`);
            return true;
            
        } catch (error) {
            console.error('❌ 导入列表失败:', error);
            return false;
        }
    }
    
    // 导出列表
    exportList(listType) {
        try {
            let list;
            switch (listType) {
                case 'whitelist':
                    list = Array.from(this.whitelist);
                    break;
                case 'blacklist':
                    list = Array.from(this.blacklist);
                    break;
                case 'domainWhitelist':
                    list = Array.from(this.domainWhitelist);
                    break;
                case 'domainBlacklist':
                    list = Array.from(this.domainBlacklist);
                    break;
                case 'keywordWhitelist':
                    list = Array.from(this.keywordWhitelist);
                    break;
                case 'keywordBlacklist':
                    list = Array.from(this.keywordBlacklist);
                    break;
                default:
                    return '';
            }
            
            return list.join('\n');
            
        } catch (error) {
            console.error('❌ 导出列表失败:', error);
            return '';
        }
    }
}

// 全局实例
window.whitelistManager = new WhitelistManager();

// 设置就绪标志
window.whitelistManagerReady = true;
console.log('✅ 白名单管理器已就绪，设置全局标志');
