/**
 * 经典界面安全脚本
 * 替代可能有问题的压缩脚本
 */

console.log('经典界面安全脚本已加载');

document.addEventListener('DOMContentLoaded', function() {
    console.log('经典界面DOM加载完成');
    
    const app = document.getElementById('app');
    if (app) {
        app.innerHTML = `
            <div style="padding: 20px; text-align: center; font-family: 'Microsoft YaHei', Arial, sans-serif;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h2 style="margin: 0; font-size: 24px;">🐕 狗蛋蜜罐识别器</h2>
                    <p style="margin: 10px 0 0 0; opacity: 0.9;">经典界面 - 安全版本</p>
                </div>
                
                <div style="margin: 20px 0;">
                    <div style="padding: 15px; background: #f0f8ff; border-radius: 8px; margin: 10px 0; border-left: 4px solid #4299e1;">
                        <strong>✅ 蜜罐检测功能</strong>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">实时监控和识别蜜罐网站</div>
                    </div>
                    <div style="padding: 15px; background: #f0fff0; border-radius: 8px; margin: 10px 0; border-left: 4px solid #48bb78;">
                        <strong>✅ 指纹对抗功能</strong>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">防止浏览器指纹识别</div>
                    </div>
                    <div style="padding: 15px; background: #fff8f0; border-radius: 8px; margin: 10px 0; border-left: 4px solid #ed8936;">
                        <strong>✅ 恶意跳转检测</strong>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">阻止恶意重定向和跳转</div>
                    </div>
                    <div style="padding: 15px; background: #f8f0ff; border-radius: 8px; margin: 10px 0; border-left: 4px solid #9f7aea;">
                        <strong>🛡️ 黑白名单管理</strong>
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">防止误识别正常业务网站</div>
                        <button onclick="openWhitelistSettings()" style="margin-top: 8px; padding: 6px 12px; background: #9f7aea; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">管理设置</button>
                    </div>
                </div>
                
                <div style="background: #f7fafc; padding: 15px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="margin: 0 0 10px 0; color: #2d3748;">功能状态</h3>
                    <div style="display: flex; justify-content: space-around; text-align: center;">
                        <div>
                            <div style="font-size: 18px; font-weight: bold; color: #48bb78;">运行中</div>
                            <div style="font-size: 12px; color: #666;">检测引擎</div>
                        </div>
                        <div>
                            <div style="font-size: 18px; font-weight: bold; color: #4299e1;">活跃</div>
                            <div style="font-size: 12px; color: #666;">防护模块</div>
                        </div>
                        <div>
                            <div style="font-size: 18px; font-weight: bold; color: #ed8936;">监控</div>
                            <div style="font-size: 12px; color: #666;">网络请求</div>
                        </div>
                    </div>
                </div>
                
                <div style="margin: 20px 0;">
                    <button id="switchToSimpleUI" style="padding: 10px 20px; background: #4299e1; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 5px;">
                        切换到简单界面
                    </button>
                    <button id="switchToQuickUI" style="padding: 10px 20px; background: #48bb78; color: white; border: none; border-radius: 5px; cursor: pointer; margin: 5px;">
                        切换到快速配置
                    </button>
                </div>
                
                <p style="font-size: 12px; color: #666; margin-top: 20px;">
                    核心功能在后台运行，无需额外配置<br>
                    版本: 2.2.0 | 状态: 正常运行
                </p>
            </div>
        `;
        
        // 绑定按钮事件
        document.getElementById('switchToSimpleUI')?.addEventListener('click', function() {
            switchUI('simple');
        });
        
        document.getElementById('switchToQuickUI')?.addEventListener('click', function() {
            switchUI('quick');
        });
        
        console.log('经典界面内容已加载');
    } else {
        console.warn('未找到app容器');
    }
});

// UI切换函数
async function switchUI(uiType) {
    try {
        console.log('切换UI到:', uiType);
        
        if (chrome && chrome.runtime && chrome.runtime.sendMessage) {
            const response = await chrome.runtime.sendMessage({
                action: 'switchUI',
                uiType: uiType
            });
            
            if (response && response.success) {
                console.log('UI切换成功:', response.message);
                // 显示成功消息
                const app = document.getElementById('app');
                if (app) {
                    const successDiv = document.createElement('div');
                    successDiv.style.cssText = 'position: fixed; top: 10px; right: 10px; background: #48bb78; color: white; padding: 10px; border-radius: 5px; z-index: 1000;';
                    successDiv.textContent = response.message || '切换成功';
                    document.body.appendChild(successDiv);
                    
                    setTimeout(() => {
                        document.body.removeChild(successDiv);
                        window.close();
                    }, 1500);
                }
            } else {
                throw new Error(response?.message || '切换失败');
            }
        } else {
            throw new Error('Chrome API不可用');
        }
    } catch (error) {
        console.error('UI切换失败:', error);
        alert('UI切换失败: ' + error.message);
    }
}

// 错误处理
window.addEventListener('error', function(event) {
    console.error('经典界面脚本错误:', event.error);
});

// 打开黑白名单设置页面
function openWhitelistSettings() {
    console.log('🛡️ 尝试打开黑白名单设置页面');

    try {
        const settingsUrl = chrome.runtime.getURL('resource/popup/whitelist-simple.html');
        console.log('📍 设置页面URL:', settingsUrl);

        // 优先尝试在新标签页中打开
        if (chrome && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({
                url: settingsUrl
            }, function(tab) {
                if (chrome.runtime.lastError) {
                    console.error('❌ 创建标签页失败:', chrome.runtime.lastError);
                    // 降级到window.open
                    window.open(settingsUrl, '_blank');
                } else {
                    console.log('✅ 已在新标签页打开黑白名单设置');
                }
            });
        } else {
            console.log('⚠️ chrome.tabs API不可用，使用window.open');
            window.open(settingsUrl, '_blank');
        }
    } catch (error) {
        console.error('❌ 打开黑白名单设置失败:', error);

        // 最后的降级方案：显示提示信息
        alert('黑白名单设置功能\n\n请手动访问:\nchrome-extension://' + chrome.runtime.id + '/resource/popup/whitelist-settings.html\n\n或重新加载扩展后再试。');
    }
}

console.log('经典界面安全脚本初始化完成');
