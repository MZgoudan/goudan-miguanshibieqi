/**
 * 紧急安全popup脚本
 * 完全独立，无外部依赖，无CSP违规
 */

console.log('🚨 紧急安全popup脚本开始加载...');

// 全局错误处理
window.addEventListener('error', function(event) {
    console.error('Popup脚本错误:', event.error);
});

// 等待DOM加载完成
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚨 紧急安全popup DOM加载完成');
    
    initializePopup();
});

function initializePopup() {
    console.log('🚨 初始化紧急安全popup...');
    
    // 绑定按钮事件
    const testBtn = document.getElementById('testBtn');
    const debugBtn = document.getElementById('debugBtn');
    const honeypotBtn = document.getElementById('honeypotBtn');

    if (testBtn) {
        testBtn.addEventListener('click', testFunction);
    }

    if (debugBtn) {
        debugBtn.addEventListener('click', showDebugInfo);
    }

    if (honeypotBtn) {
        honeypotBtn.addEventListener('click', toggleHoneypotSection);
    }
    
    // 检查扩展状态
    checkExtensionStatus();
    
    console.log('✅ 紧急安全popup初始化完成');
}

// 蜜罐检测记录相关功能
async function toggleHoneypotSection() {
    console.log('🍯 蜜罐检测记录按钮被点击');

    const section = document.getElementById('honeypotSection');
    if (!section) return;

    if (section.style.display === 'none') {
        section.style.display = 'block';
        await loadHoneypotDetections();
    } else {
        section.style.display = 'none';
    }
}

async function loadHoneypotDetections() {
    console.log('🍯 加载蜜罐检测记录...');

    const statsElement = document.getElementById('honeypotStats');
    const listElement = document.getElementById('honeypotList');

    if (!statsElement || !listElement) return;

    try {
        // 从存储中获取蜜罐检测记录
        const result = await chrome.storage.local.get(['honeypotDetections']);
        const detections = result.honeypotDetections || [];

        console.log(`🍯 找到 ${detections.length} 条蜜罐检测记录`);

        // 统计不同置信度的数量
        const highCount = detections.filter(d => d.confidence === 'high').length;
        const mediumCount = detections.filter(d => d.confidence === 'medium').length;
        const lowCount = detections.filter(d => d.confidence === 'low').length;

        // 更新统计信息
        statsElement.innerHTML = `
            总计: ${detections.length} 条记录<br>
            🚨 高风险: ${highCount} | ⚠️ 中风险: ${mediumCount} | ℹ️ 低风险: ${lowCount}
        `;

        // 显示最近的检测记录（最多显示10条）
        const recentDetections = detections.slice(0, 10);

        if (recentDetections.length === 0) {
            listElement.innerHTML = '<div style="text-align: center; color: #666; padding: 20px;">暂无蜜罐检测记录</div>';
        } else {
            const html = recentDetections.map(detection => {
                const time = new Date(detection.timestamp).toLocaleString();
                const confidenceIcon = detection.confidence === 'high' ? '🚨' :
                                     detection.confidence === 'medium' ? '⚠️' : 'ℹ️';

                return `
                    <div style="border-bottom: 1px solid #eee; padding: 8px 0; font-size: 11px;">
                        <div style="font-weight: 600; color: #333;">
                            ${confidenceIcon} ${detection.honeypotType || '未知类型'}
                        </div>
                        <div style="color: #666; margin: 2px 0;">
                            域名: ${detection.domain || 'N/A'}
                        </div>
                        <div style="color: #999; font-size: 10px;">
                            ${time}
                        </div>
                    </div>
                `;
            }).join('');

            listElement.innerHTML = html;
        }

    } catch (error) {
        console.error('🍯 加载蜜罐检测记录失败:', error);
        statsElement.textContent = '加载失败，请重试';
        listElement.innerHTML = '<div style="text-align: center; color: #f44336; padding: 20px;">加载失败</div>';
    }
}

async function testFunction() {
    console.log('🧪 测试功能被点击');
    
    const testBtn = document.getElementById('testBtn');
    if (testBtn) {
        testBtn.textContent = '测试中...';
        testBtn.disabled = true;
    }
    
    try {
        // 测试Chrome API
        if (typeof chrome !== 'undefined' && chrome.runtime) {
            console.log('✅ Chrome API可用');
            
            // 测试发送消息到Service Worker
            const response = await chrome.runtime.sendMessage({
                action: 'ping',
                timestamp: Date.now()
            });
            
            if (response) {
                console.log('✅ Service Worker通信正常:', response);
                showMessage('✅ 功能测试通过', 'success');
            } else {
                console.warn('⚠️ Service Worker无响应');
                showMessage('⚠️ Service Worker无响应', 'warning');
            }
        } else {
            console.error('❌ Chrome API不可用');
            showMessage('❌ Chrome API不可用', 'error');
        }
    } catch (error) {
        console.error('❌ 测试失败:', error);
        showMessage('❌ 测试失败: ' + error.message, 'error');
    } finally {
        if (testBtn) {
            testBtn.textContent = '测试功能';
            testBtn.disabled = false;
        }
    }
}

function showDebugInfo() {
    console.log('🔍 显示调试信息');
    
    const debugInfo = {
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        chromeAvailable: typeof chrome !== 'undefined',
        runtimeAvailable: typeof chrome !== 'undefined' && !!chrome.runtime,
        extensionId: typeof chrome !== 'undefined' && chrome.runtime ? chrome.runtime.id : 'N/A',
        url: window.location.href,
        errors: getStoredErrors()
    };
    
    console.log('调试信息:', debugInfo);
    
    // 创建调试信息显示
    const debugText = JSON.stringify(debugInfo, null, 2);
    
    // 显示在新窗口或复制到剪贴板
    if (navigator.clipboard) {
        navigator.clipboard.writeText(debugText).then(() => {
            showMessage('✅ 调试信息已复制到剪贴板', 'success');
        }).catch(() => {
            showDebugModal(debugText);
        });
    } else {
        showDebugModal(debugText);
    }
}

function showDebugModal(debugText) {
    // 创建模态框显示调试信息
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    const content = document.createElement('div');
    content.style.cssText = `
        background: white;
        padding: 20px;
        border-radius: 8px;
        max-width: 90%;
        max-height: 90%;
        overflow: auto;
    `;
    
    const textarea = document.createElement('textarea');
    textarea.value = debugText;
    textarea.style.cssText = `
        width: 100%;
        height: 300px;
        font-family: monospace;
        font-size: 12px;
    `;
    
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '关闭';
    closeBtn.style.cssText = `
        margin-top: 10px;
        padding: 8px 16px;
        background: #667eea;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    `;
    
    closeBtn.addEventListener('click', () => {
        document.body.removeChild(modal);
    });
    
    content.appendChild(textarea);
    content.appendChild(closeBtn);
    modal.appendChild(content);
    document.body.appendChild(modal);
}

function showMessage(message, type = 'info') {
    console.log(`[${type.toUpperCase()}] ${message}`);
    
    // 创建消息提示
    const messageDiv = document.createElement('div');
    messageDiv.textContent = message;
    messageDiv.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        padding: 10px 15px;
        border-radius: 5px;
        color: white;
        font-size: 12px;
        z-index: 1000;
        max-width: 250px;
        word-wrap: break-word;
    `;
    
    // 根据类型设置颜色
    switch (type) {
        case 'success':
            messageDiv.style.background = '#28a745';
            break;
        case 'warning':
            messageDiv.style.background = '#ffc107';
            messageDiv.style.color = '#333';
            break;
        case 'error':
            messageDiv.style.background = '#dc3545';
            break;
        default:
            messageDiv.style.background = '#17a2b8';
    }
    
    document.body.appendChild(messageDiv);
    
    // 3秒后自动移除
    setTimeout(() => {
        if (document.body.contains(messageDiv)) {
            document.body.removeChild(messageDiv);
        }
    }, 3000);
}

async function checkExtensionStatus() {
    console.log('🔍 检查扩展状态...');
    
    try {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
            // 尝试获取扩展信息
            const manifest = chrome.runtime.getManifest();
            console.log('✅ 扩展manifest:', manifest);
            
            // 尝试ping Service Worker
            const response = await chrome.runtime.sendMessage({
                action: 'getStatus'
            });
            
            if (response) {
                console.log('✅ Service Worker状态:', response);
                updateStatusDisplay(response);
            }
        }
    } catch (error) {
        console.warn('⚠️ 状态检查失败:', error);
    }
}

function updateStatusDisplay(status) {
    // 更新状态显示
    const statusItems = document.querySelectorAll('.status-item');
    
    if (status && status.running) {
        statusItems.forEach(item => {
            item.classList.remove('warning', 'error');
        });
        
        // 更新系统状态
        const systemStatus = Array.from(statusItems).find(item => 
            item.querySelector('.status-label').textContent.includes('系统状态')
        );
        
        if (systemStatus) {
            systemStatus.classList.remove('warning');
            systemStatus.querySelector('.status-value').textContent = '正常';
        }
    }
}

function getStoredErrors() {
    // 获取存储的错误信息
    try {
        const errors = localStorage.getItem('extensionErrors');
        return errors ? JSON.parse(errors) : [];
    } catch (error) {
        return [];
    }
}

// 错误收集
window.addEventListener('error', function(event) {
    const errorInfo = {
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        timestamp: new Date().toISOString()
    };
    
    try {
        const errors = getStoredErrors();
        errors.push(errorInfo);
        
        // 只保留最近10个错误
        if (errors.length > 10) {
            errors.splice(0, errors.length - 10);
        }
        
        localStorage.setItem('extensionErrors', JSON.stringify(errors));
    } catch (e) {
        console.warn('无法存储错误信息:', e);
    }
});

console.log('✅ 紧急安全popup脚本加载完成');
