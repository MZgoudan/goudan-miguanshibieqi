/**
 * 狗蛋蜜罐识别器 - 增强配置界面
 */

'use strict';

class EnhancedConfigUI {
  constructor() {
    this.config = null;
    this.stats = null;
    this.init();
  }

  async init() {
    await this.loadConfig();
    await this.loadStats();
    this.setupEventListeners();
    this.updateUI();
    this.startStatsUpdate();
  }

  async loadConfig() {
    try {
      const result = await chrome.storage.local.get(['enhancedConfig']);
      this.config = result.enhancedConfig || {};
    } catch (error) {
      console.warn('加载配置失败:', error);
      this.config = {};
    }
  }

  async loadStats() {
    try {
      // 从background script获取统计信息
      const response = await chrome.runtime.sendMessage({
        action: 'getStats'
      });
      this.stats = response || {
        detectionCount: 0,
        notificationCount: 0,
        averageDetectionTime: 0,
        uptime: 0
      };
    } catch (error) {
      console.warn('加载统计失败:', error);
      this.stats = {
        detectionCount: 0,
        notificationCount: 0,
        averageDetectionTime: 0,
        uptime: 0
      };
    }
  }

  setupEventListeners() {
    // 核心检测模块开关
    this.setupToggle('antiHoneyPot-enabled', 'antiHoneyPot.enabled');
    this.setupToggle('niffler-enabled', 'niffler.enabled');
    this.setupToggle('antiFingerprint-enabled', 'antiFingerprint.enabled');
    this.setupToggle('honeypotDetection-enabled', 'honeypotDetection.enabled');

    // 用户界面开关
    this.setupToggle('ui-showNotifications', 'ui.showNotifications');
    this.setupToggle('ui-showBadge', 'ui.showBadge');
    this.setupToggle('ui-detailedLogs', 'ui.detailedLogs');

    // 选择框
    this.setupSelect('detection-sensitivity', 'antiHoneyPot.sensitivity');
    this.setupSelect('niffler-threshold', 'niffler.threshold');

    // 按钮事件
    document.getElementById('resetConfig').addEventListener('click', () => {
      this.resetConfig();
    });

    document.getElementById('clearStats').addEventListener('click', () => {
      this.clearStats();
    });

    document.getElementById('exportConfig').addEventListener('click', () => {
      this.exportConfig();
    });

    document.getElementById('importConfig').addEventListener('click', () => {
      this.importConfig();
    });
  }

  setupToggle(elementId, configPath) {
    const element = document.getElementById(elementId);
    if (!element) return;

    // 设置初始值
    const value = this.getConfigValue(configPath);
    element.checked = value !== undefined ? value : false;

    // 监听变更
    element.addEventListener('change', async () => {
      await this.setConfigValue(configPath, element.checked);
    });
  }

  setupSelect(elementId, configPath) {
    const element = document.getElementById(elementId);
    if (!element) return;

    // 设置初始值
    const value = this.getConfigValue(configPath);
    if (value !== undefined) {
      element.value = value;
    }

    // 监听变更
    element.addEventListener('change', async () => {
      let newValue = element.value;
      // 如果是数字，转换为数字类型
      if (!isNaN(newValue) && newValue !== '') {
        newValue = parseInt(newValue);
      }
      await this.setConfigValue(configPath, newValue);
    });
  }

  getConfigValue(path) {
    const keys = path.split('.');
    let value = this.config;
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return undefined;
      }
    }
    
    return value;
  }

  async setConfigValue(path, value) {
    const keys = path.split('.');
    const lastKey = keys.pop();
    let target = this.config;
    
    // 创建嵌套对象路径
    for (const key of keys) {
      if (!target[key] || typeof target[key] !== 'object') {
        target[key] = {};
      }
      target = target[key];
    }
    
    target[lastKey] = value;
    
    // 保存到存储
    try {
      await chrome.storage.local.set({ enhancedConfig: this.config });
      console.log('配置已保存:', path, '=', value);
    } catch (error) {
      console.warn('配置保存失败:', error);
    }
  }

  updateUI() {
    // 更新统计信息
    this.updateStats();
  }

  updateStats() {
    if (!this.stats) return;

    document.getElementById('stat-detectionCount').textContent = this.stats.detectionCount || 0;
    document.getElementById('stat-notificationCount').textContent = this.stats.notificationCount || 0;
    document.getElementById('stat-avgTime').textContent = `${Math.round(this.stats.averageDetectionTime || 0)}ms`;
    
    const uptimeMinutes = Math.round((this.stats.uptime || 0) / 60000);
    document.getElementById('stat-uptime').textContent = `${uptimeMinutes}分钟`;
  }

  startStatsUpdate() {
    // 每5秒更新一次统计信息
    setInterval(async () => {
      await this.loadStats();
      this.updateStats();
    }, 5000);
  }

  async resetConfig() {
    if (confirm('确定要重置所有配置吗？这将恢复默认设置。')) {
      try {
        // 发送重置消息到background script
        await chrome.runtime.sendMessage({
          action: 'resetConfig'
        });
        
        // 重新加载配置
        await this.loadConfig();
        this.updateUI();
        
        // 重新设置所有UI元素
        location.reload();
      } catch (error) {
        console.warn('重置配置失败:', error);
        alert('重置配置失败，请重试。');
      }
    }
  }

  async clearStats() {
    if (confirm('确定要清除所有统计数据吗？')) {
      try {
        await chrome.runtime.sendMessage({
          action: 'clearStats'
        });
        
        await this.loadStats();
        this.updateStats();
        
        alert('统计数据已清除。');
      } catch (error) {
        console.warn('清除统计失败:', error);
        alert('清除统计失败，请重试。');
      }
    }
  }

  exportConfig() {
    try {
      const configJson = JSON.stringify(this.config, null, 2);
      document.getElementById('configData').value = configJson;
      
      // 选中文本以便复制
      document.getElementById('configData').select();
      document.getElementById('configData').setSelectionRange(0, 99999);
      
      alert('配置已导出到文本框，您可以复制保存。');
    } catch (error) {
      console.warn('导出配置失败:', error);
      alert('导出配置失败，请重试。');
    }
  }

  async importConfig() {
    const configData = document.getElementById('configData').value.trim();
    
    if (!configData) {
      alert('请先在文本框中粘贴配置数据。');
      return;
    }
    
    try {
      const importedConfig = JSON.parse(configData);
      
      if (confirm('确定要导入这个配置吗？这将覆盖当前设置。')) {
        // 发送导入消息到background script
        await chrome.runtime.sendMessage({
          action: 'importConfig',
          config: importedConfig
        });
        
        // 重新加载配置
        await this.loadConfig();
        this.updateUI();
        
        // 重新设置所有UI元素
        location.reload();
        
        alert('配置导入成功！');
      }
    } catch (error) {
      console.warn('导入配置失败:', error);
      alert('配置格式错误，请检查后重试。');
    }
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  new EnhancedConfigUI();
});
