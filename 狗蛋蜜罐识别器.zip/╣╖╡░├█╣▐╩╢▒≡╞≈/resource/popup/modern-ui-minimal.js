/**
 * 狗蛋蜜罐识别器 - 最小化UI控制器
 * 只包含确实存在的元素，避免警告
 */

'use strict';

class ModernUIMinimal {
    constructor() {
        this.currentTab = 'dashboard';
        this.config = {};
        this.honeypotDetections = [];
        this.logs = [];
        this.updateInterval = null;
        
        this.init();
    }

    async init() {
        try {
            await this.loadConfig();
            await this.loadHoneypotDetections();
            await this.loadLogs();
            
            this.setupEventListeners();
            this.updateUI();
            this.startAutoUpdate();
            
            console.log('✅ 最小化UI初始化完成');
        } catch (error) {
            console.error('❌ UI初始化失败:', error);
        }
    }

    // 安全的DOM元素获取（无警告版本）
    safeGetElement(id) {
        return document.getElementById(id);
    }

    safeSetText(id, text) {
        const element = this.safeGetElement(id);
        if (element) {
            element.textContent = text;
            return true;
        }
        return false;
    }

    // 加载配置
    async loadConfig() {
        try {
            const result = await chrome.storage.local.get(['enhancedConfig']);
            this.config = result.enhancedConfig || this.getDefaultConfig();
        } catch (error) {
            console.warn('加载配置失败:', error);
            this.config = this.getDefaultConfig();
        }
    }

    // 加载蜜罐检测记录
    async loadHoneypotDetections() {
        try {
            const result = await chrome.storage.local.get(['honeypotDetections']);
            this.honeypotDetections = result.honeypotDetections || [];
        } catch (error) {
            console.warn('加载蜜罐检测记录失败:', error);
            this.honeypotDetections = [];
        }
    }

    // 加载日志
    async loadLogs() {
        try {
            const result = await chrome.storage.local.get(['detectionLogs']);
            this.logs = result.detectionLogs || [];
        } catch (error) {
            console.warn('加载日志失败:', error);
            this.logs = [];
        }
    }

    getDefaultConfig() {
        return {
            antiHoneyPot: { enabled: true, sensitivity: 'medium' },
            niffler: { enabled: true, threshold: 4 },
            antiFingerprint: { enabled: true },
            honeypotDetection: { enabled: true },
            ui: { showNotifications: true, showBadge: true, detailedLogs: false },
            performance: { maxLogEntries: 100, cleanupInterval: 30 }
        };
    }

    // 设置事件监听器
    setupEventListeners() {
        // 导航标签切换
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // 仪表板控制按钮
        const refreshBtn = this.safeGetElement('refreshHoneypotData');
        const clearBtn = this.safeGetElement('clearHoneypotData');
        
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshDashboardData());
        }
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearHoneypotDetections());
        }

        // 检测设置
        this.setupDetectionSettings();
        
        // 日志功能
        this.setupLogsFunctionality();
        
        // 高级设置
        this.setupAdvancedSettings();
    }

    setupDetectionSettings() {
        // 检测开关
        const toggles = [
            'antiHoneyPotEnabled',
            'nifflerEnabled', 
            'antiFingerprintEnabled',
            'honeypotDetectionEnabled'
        ];

        toggles.forEach(toggleId => {
            const toggle = this.safeGetElement(toggleId);
            if (toggle) {
                const configPath = this.getConfigPath(toggleId);
                toggle.checked = this.getConfigValue(configPath);
                
                toggle.addEventListener('change', async () => {
                    this.setConfigValue(configPath, toggle.checked);
                    await this.saveConfig();
                    console.log(`✅ 设置已更新: ${toggleId} = ${toggle.checked}`);
                });
            }
        });

        // 检测敏感度
        const detectionSensitivity = this.safeGetElement('detectionSensitivity');
        if (detectionSensitivity) {
            detectionSensitivity.value = this.config.antiHoneyPot?.sensitivity || 'medium';
            detectionSensitivity.addEventListener('change', async () => {
                this.setConfigValue('antiHoneyPot.sensitivity', detectionSensitivity.value);
                await this.saveConfig();
            });
        }

        // Niffler阈值滑块
        const nifflerThreshold = this.safeGetElement('nifflerThreshold');
        if (nifflerThreshold) {
            const currentValue = this.config.niffler?.threshold || 4;
            nifflerThreshold.value = currentValue;
            
            const sliderValueSpan = nifflerThreshold.parentElement.querySelector('.slider-value');
            if (sliderValueSpan) {
                sliderValueSpan.textContent = currentValue;
            }
            
            nifflerThreshold.addEventListener('input', async () => {
                const value = parseInt(nifflerThreshold.value);
                if (sliderValueSpan) {
                    sliderValueSpan.textContent = value;
                }
                this.setConfigValue('niffler.threshold', value);
                await this.saveConfig();
            });
        }
    }

    setupLogsFunctionality() {
        const clearLogsBtn = this.safeGetElement('clearLogs');
        const exportLogsBtn = this.safeGetElement('exportLogs');
        
        if (clearLogsBtn) {
            clearLogsBtn.addEventListener('click', () => this.clearAllLogs());
        }
        if (exportLogsBtn) {
            exportLogsBtn.addEventListener('click', () => this.exportLogs());
        }
    }

    setupAdvancedSettings() {
        // 配置管理按钮
        const exportConfigBtn = this.safeGetElement('exportConfig');
        const importConfigBtn = this.safeGetElement('importConfig');
        const resetConfigBtn = this.safeGetElement('resetConfig');
        const clearAllDataBtn = this.safeGetElement('clearAllData');
        
        if (exportConfigBtn) {
            exportConfigBtn.addEventListener('click', () => this.exportConfiguration());
        }
        if (importConfigBtn) {
            importConfigBtn.addEventListener('click', () => this.importConfiguration());
        }
        if (resetConfigBtn) {
            resetConfigBtn.addEventListener('click', () => this.resetConfiguration());
        }
        if (clearAllDataBtn) {
            clearAllDataBtn.addEventListener('click', () => this.clearAllData());
        }

        // UI设置开关
        const uiToggles = ['showNotifications', 'showBadge', 'detailedLogs'];
        uiToggles.forEach(toggleId => {
            const toggle = this.safeGetElement(toggleId);
            if (toggle) {
                const configPath = `ui.${toggleId}`;
                toggle.checked = this.getConfigValue(configPath) !== false;
                
                toggle.addEventListener('change', async () => {
                    this.setConfigValue(configPath, toggle.checked);
                    await this.saveConfig();
                });
            }
        });

        // 性能设置滑块
        const performanceSliders = [
            { id: 'maxLogEntries', path: 'performance.maxLogEntries', default: 100 },
            { id: 'cleanupInterval', path: 'performance.cleanupInterval', default: 30 }
        ];

        performanceSliders.forEach(({ id, path, default: defaultValue }) => {
            const slider = this.safeGetElement(id);
            const valueElement = this.safeGetElement(id + 'Value');
            
            if (slider) {
                const currentValue = this.getConfigValue(path) || defaultValue;
                slider.value = currentValue;
                
                if (valueElement) {
                    valueElement.textContent = currentValue;
                }
                
                slider.addEventListener('input', async () => {
                    const value = parseInt(slider.value);
                    if (valueElement) {
                        valueElement.textContent = value;
                    }
                    this.setConfigValue(path, value);
                    await this.saveConfig();
                });
            }
        });
    }

    // 切换标签页
    switchTab(tabName) {
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        const activeContent = this.safeGetElement(tabName);
        if (activeContent) {
            activeContent.classList.add('active');
        }

        this.currentTab = tabName;
        
        // 根据标签页更新内容
        if (tabName === 'logs') {
            this.updateLogsDisplay();
        }
    }

    // 更新UI
    updateUI() {
        this.updateCurrentSiteStatus();
        this.updateDashboardStats();
        this.renderDashboardHoneypotList();
    }

    // 当前网站状态检测
    async updateCurrentSiteStatus() {
        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tabs.length === 0) {
                this.showCurrentSiteStatus('unknown', '无法获取当前网站', '', '请确保有活动的标签页');
                return;
            }

            const currentTab = tabs[0];
            const url = currentTab.url;
            const hostname = new URL(url).hostname;

            if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('edge://')) {
                this.showCurrentSiteStatus('safe', '浏览器内部页面', hostname, '浏览器内部页面，无需检测');
                return;
            }

            const recentDetection = this.honeypotDetections.find(detection => {
                return detection.domain === hostname && (Date.now() - detection.timestamp) < 300000;
            });

            if (recentDetection) {
                const confidence = recentDetection.confidence;
                const honeypotType = recentDetection.honeypotType || '未知类型';
                const evidence = recentDetection.evidence || '无详细信息';
                
                if (confidence === 'high') {
                    this.showCurrentSiteStatus('danger', '🚨 检测到蜜罐！', hostname, `类型: ${honeypotType}`);
                } else if (confidence === 'medium') {
                    this.showCurrentSiteStatus('warning', '⚠️ 疑似蜜罐', hostname, `类型: ${honeypotType}`);
                } else {
                    this.showCurrentSiteStatus('warning', 'ℹ️ 低风险检测', hostname, `类型: ${honeypotType}`);
                }
            } else {
                this.showCurrentSiteStatus('safe', '✅ 未检测到蜜罐', hostname, '当前网站未发现蜜罐特征');
            }

        } catch (error) {
            console.error('更新当前网站状态失败:', error);
            this.showCurrentSiteStatus('unknown', '检测失败', '', '无法获取当前网站状态');
        }
    }

    showCurrentSiteStatus(type, title, url, details) {
        const statusCard = this.safeGetElement('currentSiteStatus');
        const statusIcon = this.safeGetElement('statusIcon');
        const statusTitle = this.safeGetElement('statusTitle');
        const statusUrl = this.safeGetElement('statusUrl');
        const statusDetails = this.safeGetElement('statusDetails');
        const statusBadge = this.safeGetElement('statusBadge');

        if (statusCard) {
            statusCard.className = 'status-card';
            statusCard.classList.add(type);
        }

        if (statusIcon) {
            const icons = {
                'safe': '✅',
                'warning': '⚠️',
                'danger': '🚨',
                'checking': '🔍',
                'unknown': '❓'
            };
            statusIcon.textContent = icons[type] || '❓';
        }

        this.safeSetText('statusTitle', title);
        this.safeSetText('statusUrl', url);
        this.safeSetText('statusDetails', details);

        if (statusBadge) {
            const badges = {
                'safe': '安全',
                'warning': '警告',
                'danger': '危险',
                'checking': '检测中',
                'unknown': '未知'
            };
            statusBadge.textContent = badges[type] || '未知';
            statusBadge.className = `status-badge ${type}`;
        }
    }

    updateDashboardStats() {
        const highCount = this.honeypotDetections.filter(d => d.confidence === 'high').length;
        const mediumCount = this.honeypotDetections.filter(d => d.confidence === 'medium').length;
        const lowCount = this.honeypotDetections.filter(d => d.confidence === 'low').length;
        const totalCount = this.honeypotDetections.length;

        this.safeSetText('highConfidenceCount', highCount);
        this.safeSetText('mediumConfidenceCount', mediumCount);
        this.safeSetText('lowConfidenceCount', lowCount);
        this.safeSetText('totalProtected', totalCount);
    }

    renderDashboardHoneypotList() {
        const container = this.safeGetElement('dashboardHoneypotList');
        if (!container) return;

        const recentDetections = this.honeypotDetections
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 5);
        
        if (recentDetections.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">暂无蜜罐检测记录</div><div class="empty-desc">当检测到蜜罐特征时，结果将在这里显示</div></div>';
            return;
        }

        const html = recentDetections.map(detection => {
            const time = new Date(detection.timestamp).toLocaleString();
            const confidenceClass = detection.confidence || 'medium';
            const icon = confidenceClass === 'high' ? '🚨' : confidenceClass === 'medium' ? '⚠️' : 'ℹ️';

            return `
                <div class="honeypot-item">
                    <div class="honeypot-icon">${icon}</div>
                    <div class="honeypot-content">
                        <div class="honeypot-title">${detection.honeypotType || '未知蜜罐类型'}</div>
                        <div class="honeypot-details">域名: ${detection.domain}</div>
                        <div class="honeypot-time">${time}</div>
                    </div>
                    <div class="honeypot-badge ${confidenceClass}">${this.getConfidenceText(confidenceClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    // 辅助方法
    getConfigPath(toggleId) {
        const pathMap = {
            'antiHoneyPotEnabled': 'antiHoneyPot.enabled',
            'nifflerEnabled': 'niffler.enabled',
            'honeypotDetectionEnabled': 'honeypotDetection.enabled',
            'antiFingerprintEnabled': 'antiFingerprint.enabled'
        };
        return pathMap[toggleId] || toggleId;
    }

    getConfigValue(path) {
        const keys = path.split('.');
        let value = this.config;
        for (const key of keys) {
            value = value?.[key];
        }
        return value;
    }

    setConfigValue(path, value) {
        const keys = path.split('.');
        let obj = this.config;
        for (let i = 0; i < keys.length - 1; i++) {
            if (!obj[keys[i]]) obj[keys[i]] = {};
            obj = obj[keys[i]];
        }
        obj[keys[keys.length - 1]] = value;
    }

    async saveConfig() {
        try {
            await chrome.storage.local.set({ enhancedConfig: this.config });
        } catch (error) {
            console.error('保存配置失败:', error);
        }
    }

    getConfidenceText(confidence) {
        const texts = {
            'high': '高风险',
            'medium': '中风险',
            'low': '低风险'
        };
        return texts[confidence] || '未知';
    }

    // 功能方法
    async refreshDashboardData() {
        await this.loadHoneypotDetections();
        this.updateUI();
    }

    async clearHoneypotDetections() {
        if (confirm('确定要清空所有蜜罐检测记录吗？')) {
            this.honeypotDetections = [];
            await chrome.storage.local.set({ honeypotDetections: [] });
            this.updateUI();
        }
    }

    async clearAllLogs() {
        if (confirm('确定要清空所有检测日志吗？')) {
            this.logs = [];
            await chrome.storage.local.set({ detectionLogs: [] });
            this.updateLogsDisplay();
        }
    }

    async exportLogs() {
        try {
            const exportData = {
                exportTime: new Date().toISOString(),
                totalLogs: this.logs.length,
                logs: this.logs
            };

            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `honeypot-logs-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('导出日志失败:', error);
            alert('导出失败，请重试');
        }
    }

    async exportConfiguration() {
        try {
            const exportData = {
                exportTime: new Date().toISOString(),
                version: '2.2.0',
                configuration: this.config
            };

            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `honeypot-config-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
            
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('导出配置失败:', error);
            alert('导出失败，请重试');
        }
    }

    async importConfiguration() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = async (event) => {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = async (e) => {
                try {
                    const importData = JSON.parse(e.target.result);
                    
                    if (importData.configuration) {
                        this.config = { ...this.getDefaultConfig(), ...importData.configuration };
                        await this.saveConfig();
                        
                        alert('配置导入成功！页面将刷新。');
                        location.reload();
                    } else {
                        alert('配置文件格式错误');
                    }
                } catch (error) {
                    console.error('解析配置文件失败:', error);
                    alert('配置文件格式错误');
                }
            };
            reader.readAsText(file);
        };
        
        input.click();
    }

    async resetConfiguration() {
        if (confirm('确定要重置所有配置到默认值吗？')) {
            this.config = this.getDefaultConfig();
            await this.saveConfig();
            alert('配置已重置！页面将刷新。');
            location.reload();
        }
    }

    async clearAllData() {
        if (confirm('⚠️ 警告：此操作将清空所有数据！确定要继续吗？')) {
            if (confirm('最后确认：真的要清空所有数据吗？')) {
                try {
                    await chrome.storage.local.clear();
                    this.config = this.getDefaultConfig();
                    await this.saveConfig();
                    
                    alert('所有数据已清空！页面将刷新。');
                    location.reload();
                } catch (error) {
                    console.error('清空数据失败:', error);
                    alert('清空数据失败，请重试');
                }
            }
        }
    }

    updateLogsDisplay() {
        const container = this.safeGetElement('logsContainer');
        if (!container) return;

        if (this.logs.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">📝</div><div class="empty-title">暂无检测日志</div><div class="empty-desc">检测活动将在这里显示</div></div>';
            return;
        }

        const recentLogs = this.logs.slice(0, 20);
        const html = recentLogs.map(log => {
            const time = new Date(log.timestamp).toLocaleString();
            const levelClass = log.level || 'medium';
            const icon = log.type === 'honeypot' ? '🍯' : '📝';

            return `
                <div class="log-item">
                    <div class="log-icon">${icon}</div>
                    <div class="log-content">
                        <div class="log-title">${log.title || log.type || '检测事件'}</div>
                        <div class="log-details">${log.details || log.message || '无详细信息'}</div>
                        <div class="log-time">${time}</div>
                    </div>
                    <div class="log-badge ${levelClass}">${this.getConfidenceText(levelClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    // 开始自动更新
    startAutoUpdate() {
        this.updateInterval = setInterval(async () => {
            await this.loadHoneypotDetections();
            this.updateUI();
        }, 5000);
    }

    // 停止自动更新
    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.modernUIMinimal = new ModernUIMinimal();
});

// 页面卸载时清理
window.addEventListener('beforeunload', () => {
    if (window.modernUIMinimal) {
        window.modernUIMinimal.stopAutoUpdate();
    }
});

// ========== 黑白名单管理功能 ==========
let whitelistManager = null;

// 初始化黑白名单管理器
async function initWhitelistManager() {
    try {
        console.log('🛡️ 开始初始化黑白名单管理器...');

        // 等待whitelistManager加载
        let attempts = 0;
        while (!window.whitelistManager && attempts < 50) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }

        if (window.whitelistManager) {
            whitelistManager = window.whitelistManager;
            console.log('✅ 黑白名单管理器已连接');

            // 初始化UI
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();

            // 设置事件监听器
            setupWhitelistEventListeners();
        } else {
            console.warn('⚠️ 黑白名单管理器未找到，可能需要重新加载扩展');
        }
    } catch (error) {
        console.error('❌ 初始化黑白名单管理器失败:', error);
    }
}

// 更新黑白名单统计
async function updateWhitelistStats() {
    if (!whitelistManager) return;

    try {
        const lists = whitelistManager.getAllLists();

        // 安全更新统计数字
        const whitelistCountEl = document.getElementById('whitelistCount');
        const blacklistCountEl = document.getElementById('blacklistCount');
        const domainWhitelistCountEl = document.getElementById('domainWhitelistCount');
        const domainBlacklistCountEl = document.getElementById('domainBlacklistCount');

        if (whitelistCountEl) whitelistCountEl.textContent = lists.whitelist.length;
        if (blacklistCountEl) blacklistCountEl.textContent = lists.blacklist.length;
        if (domainWhitelistCountEl) domainWhitelistCountEl.textContent = lists.domainWhitelist.length;
        if (domainBlacklistCountEl) domainBlacklistCountEl.textContent = lists.domainBlacklist.length;

        console.log('📊 黑白名单统计已更新');

    } catch (error) {
        console.error('❌ 更新黑白名单统计失败:', error);
    }
}

// 刷新黑白名单UI显示
async function refreshWhitelistUI() {
    if (!whitelistManager) return;

    try {
        const lists = whitelistManager.getAllLists();

        // 更新白名单显示
        const whitelistContainer = document.getElementById('whitelistContainer');
        if (whitelistContainer) {
            const allWhitelist = [
                ...lists.whitelist.map(item => ({ value: item, type: 'URL' })),
                ...lists.domainWhitelist.map(item => ({ value: item, type: '域名' })),
                ...lists.keywordWhitelist.map(item => ({ value: item, type: '关键词' }))
            ];

            if (allWhitelist.length === 0) {
                whitelistContainer.innerHTML = '<div class="empty-state">暂无白名单条目</div>';
            } else {
                whitelistContainer.innerHTML = allWhitelist.map((item, index) => `
                    <div class="list-item">
                        <div class="list-item-text">
                            <span class="list-item-type">${item.type}</span>
                            ${item.value}
                        </div>
                        <button class="btn btn-danger btn-sm" data-action="remove-whitelist" data-value="${item.value}" data-type="${item.type}">删除</button>
                    </div>
                `).join('');
            }
        }

        // 更新黑名单显示
        const blacklistContainer = document.getElementById('blacklistContainer');
        if (blacklistContainer) {
            const allBlacklist = [
                ...lists.blacklist.map(item => ({ value: item, type: 'URL' })),
                ...lists.domainBlacklist.map(item => ({ value: item, type: '域名' })),
                ...lists.keywordBlacklist.map(item => ({ value: item, type: '关键词' }))
            ];

            if (allBlacklist.length === 0) {
                blacklistContainer.innerHTML = '<div class="empty-state">暂无黑名单条目</div>';
            } else {
                blacklistContainer.innerHTML = allBlacklist.map((item, index) => `
                    <div class="list-item">
                        <div class="list-item-text">
                            <span class="list-item-type">${item.type}</span>
                            ${item.value}
                        </div>
                        <button class="btn btn-danger btn-sm" data-action="remove-blacklist" data-value="${item.value}" data-type="${item.type}">删除</button>
                    </div>
                `).join('');
            }
        }

        console.log('🔄 黑白名单UI已刷新');

    } catch (error) {
        console.error('❌ 刷新黑白名单UI失败:', error);
    }
}

// 更新当前网站信息
async function updateCurrentSiteInfo() {
    try {
        // 尝试获取当前标签页信息
        if (chrome && chrome.tabs) {
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                if (tabs[0]) {
                    const url = tabs[0].url;
                    const domain = new URL(url).hostname;

                    const currentUrlEl = document.getElementById('currentUrl');
                    const currentDomainEl = document.getElementById('currentDomain');
                    const currentStatusEl = document.getElementById('currentStatus');

                    if (currentUrlEl) currentUrlEl.textContent = url;
                    if (currentDomainEl) currentDomainEl.textContent = domain;

                    // 检查当前网站状态
                    if (whitelistManager && currentStatusEl) {
                        const whitelistCheck = whitelistManager.isWhitelisted(url);
                        const blacklistCheck = whitelistManager.isBlacklisted(url);

                        let status = '未知';
                        if (whitelistCheck.isWhitelisted) {
                            status = '✅ 在白名单中';
                        } else if (blacklistCheck.isBlacklisted) {
                            status = '🚫 在黑名单中';
                        } else {
                            status = '⚪ 未设置';
                        }

                        currentStatusEl.textContent = status;
                    }
                }
            });
        }
    } catch (error) {
        console.warn('⚠️ 更新当前网站信息失败:', error);
    }
}

// 添加到白名单
async function addToWhitelist() {
    const input = document.getElementById('whitelistInput');
    const typeSelect = document.getElementById('whitelistType');

    if (!input || !typeSelect) {
        console.warn('⚠️ 白名单输入元素未找到');
        return;
    }

    const value = input.value.trim();
    const type = typeSelect.value;

    if (!value) {
        alert('请输入要添加的内容');
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化，请重新加载扩展');
        return;
    }

    try {
        const success = await whitelistManager.addToWhitelist(value, type);

        if (success) {
            input.value = '';
            console.log(`✅ 已添加到白名单: ${value} (${type})`);

            // 更新UI
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        } else {
            alert('添加失败');
        }

    } catch (error) {
        console.error('❌ 添加白名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}

// 添加到黑名单
async function addToBlacklist() {
    const input = document.getElementById('blacklistInput');
    const typeSelect = document.getElementById('blacklistType');

    if (!input || !typeSelect) {
        console.warn('⚠️ 黑名单输入元素未找到');
        return;
    }

    const value = input.value.trim();
    const type = typeSelect.value;

    if (!value) {
        alert('请输入要添加的内容');
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化，请重新加载扩展');
        return;
    }

    try {
        const success = await whitelistManager.addToBlacklist(value, type);

        if (success) {
            input.value = '';
            console.log(`✅ 已添加到黑名单: ${value} (${type})`);

            // 更新UI
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        } else {
            alert('添加失败');
        }

    } catch (error) {
        console.error('❌ 添加黑名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}

// 从白名单移除
async function removeFromWhitelistUI(value, type) {
    if (!whitelistManager) return;

    try {
        const typeMap = { 'URL': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'domain';

        const success = await whitelistManager.removeFromWhitelist(value, actualType);

        if (success) {
            console.log(`🗑️ 已从白名单移除: ${value} (${type})`);

            // 更新UI
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        }

    } catch (error) {
        console.error('❌ 移除白名单失败:', error);
    }
}

// 从黑名单移除
async function removeFromBlacklistUI(value, type) {
    if (!whitelistManager) return;

    try {
        const typeMap = { 'URL': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'domain';

        const success = await whitelistManager.removeFromBlacklist(value, actualType);

        if (success) {
            console.log(`🗑️ 已从黑名单移除: ${value} (${type})`);

            // 更新UI
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        }

    } catch (error) {
        console.error('❌ 移除黑名单失败:', error);
    }
}

// 添加当前网站到白名单
async function addCurrentToWhitelist(type) {
    if (!chrome || !chrome.tabs) {
        alert('无法获取当前网站信息');
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
        if (tabs[0]) {
            const url = tabs[0].url;
            const domain = new URL(url).hostname;

            const value = type === 'domain' ? domain : url;

            if (whitelistManager) {
                try {
                    const success = await whitelistManager.addToWhitelist(value, type);
                    if (success) {
                        console.log(`✅ 已添加当前网站到白名单: ${value} (${type})`);

                        // 更新UI
                        await updateWhitelistStats();
                        await refreshWhitelistUI();
                        await updateCurrentSiteInfo();
                    }
                } catch (error) {
                    console.error('❌ 添加当前网站到白名单失败:', error);
                }
            }
        }
    });
}

// 添加当前网站到黑名单
async function addCurrentToBlacklist(type) {
    if (!chrome || !chrome.tabs) {
        alert('无法获取当前网站信息');
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
        if (tabs[0]) {
            const url = tabs[0].url;
            const domain = new URL(url).hostname;

            const value = type === 'domain' ? domain : url;

            if (whitelistManager) {
                try {
                    const success = await whitelistManager.addToBlacklist(value, type);
                    if (success) {
                        console.log(`✅ 已添加当前网站到黑名单: ${value} (${type})`);

                        // 更新UI
                        await updateWhitelistStats();
                        await refreshWhitelistUI();
                        await updateCurrentSiteInfo();
                    }
                } catch (error) {
                    console.error('❌ 添加当前网站到黑名单失败:', error);
                }
            }
        }
    });
}

// 刷新黑白名单UI（按钮调用）
async function refreshWhitelistUIManual() {
    console.log('🔄 手动刷新黑白名单UI...');
    await updateWhitelistStats();
    await refreshWhitelistUI();
    await updateCurrentSiteInfo();
}

// 导出黑白名单数据
function exportWhitelistData() {
    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        const lists = whitelistManager.getAllLists();
        const exportData = {
            ...lists,
            exportTime: new Date().toISOString(),
            version: '1.0',
            author: '蜜汁狗蛋'
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `whitelist-config-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);

        console.log('📤 黑白名单配置已导出');

    } catch (error) {
        console.error('❌ 导出黑白名单数据失败:', error);
        alert('导出失败');
    }
}

// 打开完整黑白名单设置
function openFullWhitelistSettings() {
    try {
        const settingsUrl = chrome.runtime.getURL('resource/popup/whitelist-settings.html');
        window.open(settingsUrl, '_blank');
        console.log('🔗 已打开完整黑白名单设置页面');
    } catch (error) {
        console.error('❌ 打开完整设置失败:', error);
        alert('打开设置页面失败');
    }
}

// 清空所有黑白名单数据
async function clearAllWhitelistData() {
    if (!confirm('确定要清空所有黑白名单吗？此操作不可恢复！')) {
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        await whitelistManager.clearList('whitelist');
        await whitelistManager.clearList('blacklist');
        await whitelistManager.clearList('domainWhitelist');
        await whitelistManager.clearList('domainBlacklist');
        await whitelistManager.clearList('keywordWhitelist');
        await whitelistManager.clearList('keywordBlacklist');

        console.log('🗑️ 所有黑白名单已清空');

        // 更新UI
        await updateWhitelistStats();
        await refreshWhitelistUI();
        await updateCurrentSiteInfo();

        alert('所有黑白名单已清空');

    } catch (error) {
        console.error('❌ 清空黑白名单失败:', error);
        alert('清空失败');
    }
}

// 设置黑白名单事件监听器
function setupWhitelistEventListeners() {
    console.log('🎯 设置黑白名单事件监听器...');

    // 添加白名单按钮
    const addWhitelistBtn = document.getElementById('addWhitelistBtn');
    if (addWhitelistBtn) {
        addWhitelistBtn.addEventListener('click', addToWhitelist);
    }

    // 添加黑名单按钮
    const addBlacklistBtn = document.getElementById('addBlacklistBtn');
    if (addBlacklistBtn) {
        addBlacklistBtn.addEventListener('click', addToBlacklist);
    }

    // 当前网站操作按钮
    const addCurrentUrlToWhitelistBtn = document.getElementById('addCurrentUrlToWhitelistBtn');
    if (addCurrentUrlToWhitelistBtn) {
        addCurrentUrlToWhitelistBtn.addEventListener('click', () => addCurrentToWhitelist('url'));
    }

    const addCurrentDomainToWhitelistBtn = document.getElementById('addCurrentDomainToWhitelistBtn');
    if (addCurrentDomainToWhitelistBtn) {
        addCurrentDomainToWhitelistBtn.addEventListener('click', () => addCurrentToWhitelist('domain'));
    }

    const addCurrentUrlToBlacklistBtn = document.getElementById('addCurrentUrlToBlacklistBtn');
    if (addCurrentUrlToBlacklistBtn) {
        addCurrentUrlToBlacklistBtn.addEventListener('click', () => addCurrentToBlacklist('url'));
    }

    const addCurrentDomainToBlacklistBtn = document.getElementById('addCurrentDomainToBlacklistBtn');
    if (addCurrentDomainToBlacklistBtn) {
        addCurrentDomainToBlacklistBtn.addEventListener('click', () => addCurrentToBlacklist('domain'));
    }

    // 管理操作按钮
    const refreshWhitelistBtn = document.getElementById('refreshWhitelistBtn');
    if (refreshWhitelistBtn) {
        refreshWhitelistBtn.addEventListener('click', refreshWhitelistUIManual);
    }

    const exportWhitelistBtn = document.getElementById('exportWhitelistBtn');
    if (exportWhitelistBtn) {
        exportWhitelistBtn.addEventListener('click', exportWhitelistData);
    }

    const openFullSettingsBtn = document.getElementById('openFullSettingsBtn');
    if (openFullSettingsBtn) {
        openFullSettingsBtn.addEventListener('click', openFullWhitelistSettings);
    }

    const clearAllWhitelistBtn = document.getElementById('clearAllWhitelistBtn');
    if (clearAllWhitelistBtn) {
        clearAllWhitelistBtn.addEventListener('click', clearAllWhitelistData);
    }

    // 列表删除按钮事件委托
    document.addEventListener('click', function(event) {
        if (event.target.dataset.action === 'remove-whitelist') {
            const value = event.target.dataset.value;
            const type = event.target.dataset.type;
            removeFromWhitelistUI(value, type);
        } else if (event.target.dataset.action === 'remove-blacklist') {
            const value = event.target.dataset.value;
            const type = event.target.dataset.type;
            removeFromBlacklistUI(value, type);
        }
    });

    console.log('✅ 黑白名单事件监听器设置完成');
}

// ========== 检测日志管理 ==========
class DetectionLogger {
    constructor() {
        this.logs = [];
        this.maxLogs = 100;
        this.loadLogs();
    }

    // 添加日志
    addLog(type, title, details, level = 'medium') {
        const log = {
            id: Date.now(),
            type: type,
            title: title,
            details: details,
            level: level,
            time: new Date().toLocaleString('zh-CN'),
            url: window.location.href
        };

        this.logs.unshift(log);

        // 限制日志数量
        if (this.logs.length > this.maxLogs) {
            this.logs = this.logs.slice(0, this.maxLogs);
        }

        this.saveLogs();
        this.updateLogsDisplay();

        console.log('📝 添加检测日志:', log);
    }

    // 保存日志到本地存储
    saveLogs() {
        try {
            localStorage.setItem('honeypot_detection_logs', JSON.stringify(this.logs));
        } catch (error) {
            console.warn('⚠️ 保存日志失败:', error);
        }
    }

    // 从本地存储加载日志
    loadLogs() {
        try {
            const saved = localStorage.getItem('honeypot_detection_logs');
            if (saved) {
                this.logs = JSON.parse(saved);
            }
        } catch (error) {
            console.warn('⚠️ 加载日志失败:', error);
            this.logs = [];
        }
    }

    // 更新日志显示
    updateLogsDisplay() {
        const container = document.getElementById('logsContainer');
        if (!container) return;

        if (this.logs.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📝</div>
                    <div class="empty-title">暂无检测日志</div>
                    <div class="empty-desc">当检测到蜜罐或执行对抗措施时，日志将在这里显示</div>
                </div>
            `;
            return;
        }

        container.innerHTML = this.logs.map(log => `
            <div class="log-item ${log.level}">
                <div class="log-icon">${this.getLogIcon(log.type, log.level)}</div>
                <div class="log-content">
                    <div class="log-title">${log.title}</div>
                    <div class="log-details">${log.details}</div>
                    <div class="log-time">${log.time}</div>
                </div>
                <div class="log-badge ${log.level}">${this.getLevelText(log.level)}</div>
            </div>
        `).join('');
    }

    // 获取日志图标
    getLogIcon(type, level) {
        const icons = {
            honeypot: level === 'high' ? '🚨' : '🔍',
            whitelist: '✅',
            blacklist: '🚫',
            fingerprint: '🛡️',
            jsonp: '🔒',
            storage: '💾'
        };
        return icons[type] || '📝';
    }

    // 获取级别文本
    getLevelText(level) {
        const texts = {
            high: '高风险',
            medium: '中风险',
            low: '低风险',
            safe: '安全'
        };
        return texts[level] || '未知';
    }

    // 清空日志
    clearLogs() {
        this.logs = [];
        this.saveLogs();
        this.updateLogsDisplay();
    }

    // 导出日志
    exportLogs() {
        const exportData = {
            logs: this.logs,
            exportTime: new Date().toISOString(),
            version: '1.0'
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `detection-logs-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }
}

// 全局检测日志管理器
let detectionLogger = null;
window.detectionLogger = null;

// 初始化检测日志
function initDetectionLogger() {
    detectionLogger = new DetectionLogger();
    window.detectionLogger = detectionLogger;

    // 设置日志控制按钮事件
    const clearLogsBtn = document.getElementById('clearLogs');
    if (clearLogsBtn) {
        clearLogsBtn.addEventListener('click', () => {
            if (confirm('确定要清空所有检测日志吗？')) {
                detectionLogger.clearLogs();
            }
        });
    }

    const exportLogsBtn = document.getElementById('exportLogs');
    if (exportLogsBtn) {
        exportLogsBtn.addEventListener('click', () => {
            detectionLogger.exportLogs();
        });
    }

    // 初始显示
    detectionLogger.updateLogsDisplay();

    console.log('📝 检测日志管理器初始化完成');
}

// ========== 实时检测活动图表 ==========
function initActivityChart() {
    const canvas = document.getElementById('activityChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // 模拟检测活动数据
    const activityData = Array.from({length: 24}, (_, i) => Math.floor(Math.random() * 10));

    // 清空画布
    ctx.clearRect(0, 0, width, height);

    // 设置样式
    ctx.strokeStyle = '#667eea';
    ctx.fillStyle = 'rgba(102, 126, 234, 0.2)';
    ctx.lineWidth = 2;

    // 绘制折线图
    const stepX = width / (activityData.length - 1);
    const maxValue = Math.max(...activityData) || 1;

    ctx.beginPath();
    activityData.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value / maxValue) * height * 0.8 - height * 0.1;

        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    ctx.stroke();

    // 填充区域
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fill();

    console.log('📊 实时检测活动图表已初始化');
}

// 页面加载完成后延迟初始化黑白名单管理器
setTimeout(() => {
    console.log('⏰ 开始延迟初始化黑白名单管理器...');
    initWhitelistManager();

    // 初始化检测日志
    initDetectionLogger();

    // 初始化活动图表
    initActivityChart();

    // 添加一些示例日志
    setTimeout(() => {
        if (detectionLogger) {
            detectionLogger.addLog('honeypot', '检测到潜在蜜罐特征', '域名: example.com | 特征: 异常响应头', 'medium');
            detectionLogger.addLog('whitelist', '白名单网站访问', '域名: google.com | 状态: 跳过检测', 'safe');
            detectionLogger.addLog('fingerprint', '浏览器指纹对抗', '已启用指纹随机化保护', 'low');
        }
    }, 2000);
}, 3000);
