/**
 * 狗蛋蜜罐识别器 - 安全版本UI控制器
 * 专门处理DOM元素不存在的情况
 */

'use strict';

class ModernUISafe {
    constructor() {
        this.currentTab = 'dashboard';
        this.config = {};
        this.stats = {};
        this.logs = [];
        this.honeypotDetections = [];
        this.updateInterval = null;
        
        this.init();
    }

    async init() {
        try {
            await this.loadConfig();
            await this.loadStats();
            await this.loadLogs();
            await this.loadHoneypotDetections();
            
            this.setupEventListeners();
            this.updateUI();
            this.startAutoUpdate();
            
            console.log('安全版本UI初始化完成');
        } catch (error) {
            console.error('UI初始化失败:', error);
        }
    }

    // 安全的DOM元素获取
    safeGetElement(id) {
        const element = document.getElementById(id);
        if (!element) {
            console.warn(`元素不存在: ${id}`);
            // 调试信息：列出所有可用的ID
            const allElements = document.querySelectorAll('[id]');
            const allIds = Array.from(allElements).map(el => el.id).filter(id => id);
            console.log('可用的元素ID:', allIds);
        }
        return element;
    }

    safeSetText(id, text) {
        const element = this.safeGetElement(id);
        if (element) {
            element.textContent = text;
        }
    }

    // 加载配置
    async loadConfig() {
        try {
            const result = await chrome.storage.local.get(['enhancedConfig']);
            this.config = result.enhancedConfig || this.getDefaultConfig();
        } catch (error) {
            console.warn('加载配置失败:', error);
            this.config = this.getDefaultConfig();
        }
    }

    // 加载统计数据
    async loadStats() {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getStats' });
            this.stats = response || {
                detectionCount: 0,
                threatsBlocked: 0,
                fingerprintBlocked: 0,
                averageDetectionTime: 0,
                uptime: 0
            };
        } catch (error) {
            console.warn('加载统计数据失败:', error);
            this.stats = {
                detectionCount: 0,
                threatsBlocked: 0,
                fingerprintBlocked: 0,
                averageDetectionTime: 0,
                uptime: 0
            };
        }
    }

    // 加载日志
    async loadLogs() {
        try {
            const result = await chrome.storage.local.get(['detectionLogs']);
            this.logs = result.detectionLogs || [];
        } catch (error) {
            console.warn('加载日志失败:', error);
            this.logs = [];
        }
    }

    // 加载蜜罐检测记录
    async loadHoneypotDetections() {
        try {
            const result = await chrome.storage.local.get(['honeypotDetections']);
            this.honeypotDetections = result.honeypotDetections || [];
        } catch (error) {
            console.warn('加载蜜罐检测记录失败:', error);
            this.honeypotDetections = [];
        }
    }

    // 获取默认配置
    getDefaultConfig() {
        return {
            antiHoneyPot: { enabled: true, sensitivity: 'medium' },
            niffler: { enabled: true, threshold: 4 },
            antiFingerprint: { enabled: true },
            honeypotDetection: { enabled: true },
            ui: { showNotifications: true, showBadge: true, detailedLogs: false },
            performance: { maxLogEntries: 100, cleanupInterval: 30 }
        };
    }

    // 设置事件监听器
    setupEventListeners() {
        // 导航标签切换
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // 蜜罐检测相关事件
        this.setupHoneypotListeners();

        // 设置页面事件
        this.setupSettingsListeners();

        // 日志页面事件
        this.setupLogsListeners();

        // 高级设置事件
        this.setupAdvancedSettingsListeners();
    }

    // 设置蜜罐检测监听器
    setupHoneypotListeners() {
        // 仪表板控制按钮
        const refreshBtn = this.safeGetElement('refreshHoneypotData');
        const clearBtn = this.safeGetElement('clearHoneypotData');
        const dashboardTimeFilter = this.safeGetElement('dashboardTimeFilter');
        const dashboardConfidenceFilter = this.safeGetElement('dashboardConfidenceFilter');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshDashboardHoneypotData());
        }
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearHoneypotDetections());
        }
        if (dashboardTimeFilter) {
            dashboardTimeFilter.addEventListener('change', () => this.updateDashboardHoneypotDisplay());
        }
        if (dashboardConfidenceFilter) {
            dashboardConfidenceFilter.addEventListener('change', () => this.updateDashboardHoneypotDisplay());
        }
    }

    // 设置页面监听器
    setupSettingsListeners() {
        // 检测设置开关
        const toggles = [
            'antiHoneyPotEnabled',
            'nifflerEnabled',
            'honeypotDetectionEnabled',
            'antiFingerprintEnabled'
        ];

        toggles.forEach(toggleId => {
            const toggle = this.safeGetElement(toggleId);
            if (toggle) {
                // 设置初始状态
                const configPath = this.getConfigPath(toggleId);
                toggle.checked = this.getConfigValue(configPath);

                // 监听变化
                toggle.addEventListener('change', async () => {
                    this.setConfigValue(configPath, toggle.checked);
                    await this.saveConfig();
                    console.log(`设置已更新: ${toggleId} = ${toggle.checked}`);
                });
            }
        });

        // 检测敏感度下拉框
        const detectionSensitivity = this.safeGetElement('detectionSensitivity');
        if (detectionSensitivity) {
            detectionSensitivity.value = this.config.antiHoneyPot?.sensitivity || 'medium';
            detectionSensitivity.addEventListener('change', async () => {
                this.setConfigValue('antiHoneyPot.sensitivity', detectionSensitivity.value);
                await this.saveConfig();
            });
        }

        // Niffler阈值滑块
        const nifflerThreshold = this.safeGetElement('nifflerThreshold');
        if (nifflerThreshold) {
            const currentValue = this.config.niffler?.threshold || 4;
            nifflerThreshold.value = currentValue;

            // 更新显示值
            const sliderValueSpan = nifflerThreshold.parentElement.querySelector('.slider-value');
            if (sliderValueSpan) {
                sliderValueSpan.textContent = currentValue;
            }

            nifflerThreshold.addEventListener('input', async () => {
                const value = parseInt(nifflerThreshold.value);
                if (sliderValueSpan) {
                    sliderValueSpan.textContent = value;
                }
                this.setConfigValue('niffler.threshold', value);
                await this.saveConfig();
            });
        }
    }

    getConfigPath(toggleId) {
        const pathMap = {
            'antiHoneyPotEnabled': 'antiHoneyPot.enabled',
            'nifflerEnabled': 'niffler.enabled',
            'honeypotDetectionEnabled': 'honeypotDetection.enabled',
            'antiFingerprintEnabled': 'antiFingerprint.enabled'
        };
        return pathMap[toggleId] || toggleId;
    }

    getConfigValue(path) {
        const keys = path.split('.');
        let value = this.config;
        for (const key of keys) {
            value = value?.[key];
        }
        return value;
    }

    setConfigValue(path, value) {
        const keys = path.split('.');
        let obj = this.config;
        for (let i = 0; i < keys.length - 1; i++) {
            if (!obj[keys[i]]) obj[keys[i]] = {};
            obj = obj[keys[i]];
        }
        obj[keys[keys.length - 1]] = value;
    }

    async saveConfig() {
        try {
            await chrome.storage.local.set({ enhancedConfig: this.config });
        } catch (error) {
            console.error('保存配置失败:', error);
        }
    }

    // 日志页面监听器
    setupLogsListeners() {
        // 清空日志按钮
        const clearLogsBtn = this.safeGetElement('clearLogs');
        if (clearLogsBtn) {
            clearLogsBtn.addEventListener('click', () => this.clearAllLogs());
        }

        // 导出日志按钮
        const exportLogsBtn = this.safeGetElement('exportLogs');
        if (exportLogsBtn) {
            exportLogsBtn.addEventListener('click', () => this.exportLogs());
        }

        // 日志过滤器
        const logTypeFilter = this.safeGetElement('logTypeFilter');
        const logLevelFilter = this.safeGetElement('logLevelFilter');

        if (logTypeFilter) {
            logTypeFilter.addEventListener('change', () => this.filterLogs());
        }
        if (logLevelFilter) {
            logLevelFilter.addEventListener('change', () => this.filterLogs());
        }
    }

    // 高级设置监听器
    setupAdvancedSettingsListeners() {
        // 导出配置按钮
        const exportConfigBtn = this.safeGetElement('exportConfig');
        if (exportConfigBtn) {
            exportConfigBtn.addEventListener('click', () => this.exportConfiguration());
        }

        // 导入配置按钮
        const importConfigBtn = this.safeGetElement('importConfig');
        if (importConfigBtn) {
            importConfigBtn.addEventListener('click', () => this.importConfiguration());
        }

        // 重置配置按钮
        const resetConfigBtn = this.safeGetElement('resetConfig');
        if (resetConfigBtn) {
            resetConfigBtn.addEventListener('click', () => this.resetConfiguration());
        }

        // 清空所有数据按钮
        const clearAllDataBtn = this.safeGetElement('clearAllData');
        if (clearAllDataBtn) {
            clearAllDataBtn.addEventListener('click', () => this.clearAllData());
        }

        // 性能设置
        const maxLogEntriesSlider = this.safeGetElement('maxLogEntries');
        const maxLogEntriesValue = this.safeGetElement('maxLogEntriesValue');
        if (maxLogEntriesSlider && maxLogEntriesValue) {
            const currentValue = this.config.performance?.maxLogEntries || 100;
            maxLogEntriesSlider.value = currentValue;
            maxLogEntriesValue.textContent = currentValue;

            maxLogEntriesSlider.addEventListener('input', async () => {
                const value = parseInt(maxLogEntriesSlider.value);
                maxLogEntriesValue.textContent = value;
                this.setConfigValue('performance.maxLogEntries', value);
                await this.saveConfig();
            });
        }

        // 清理间隔设置
        const cleanupIntervalSlider = this.safeGetElement('cleanupInterval');
        const cleanupIntervalValue = this.safeGetElement('cleanupIntervalValue');
        if (cleanupIntervalSlider && cleanupIntervalValue) {
            const currentValue = this.config.performance?.cleanupInterval || 30;
            cleanupIntervalSlider.value = currentValue;
            cleanupIntervalValue.textContent = currentValue;

            cleanupIntervalSlider.addEventListener('input', async () => {
                const value = parseInt(cleanupIntervalSlider.value);
                cleanupIntervalValue.textContent = value;
                this.setConfigValue('performance.cleanupInterval', value);
                await this.saveConfig();
            });
        }

        // 详细日志开关
        const detailedLogsToggle = this.safeGetElement('detailedLogs');
        if (detailedLogsToggle) {
            detailedLogsToggle.checked = this.config.ui?.detailedLogs || false;
            detailedLogsToggle.addEventListener('change', async () => {
                this.setConfigValue('ui.detailedLogs', detailedLogsToggle.checked);
                await this.saveConfig();
            });
        }

        // 显示通知开关
        const showNotificationsToggle = this.safeGetElement('showNotifications');
        if (showNotificationsToggle) {
            showNotificationsToggle.checked = this.config.ui?.showNotifications !== false;
            showNotificationsToggle.addEventListener('change', async () => {
                this.setConfigValue('ui.showNotifications', showNotificationsToggle.checked);
                await this.saveConfig();
            });
        }

        // 显示徽章开关
        const showBadgeToggle = this.safeGetElement('showBadge');
        if (showBadgeToggle) {
            showBadgeToggle.checked = this.config.ui?.showBadge !== false;
            showBadgeToggle.addEventListener('change', async () => {
                this.setConfigValue('ui.showBadge', showBadgeToggle.checked);
                await this.saveConfig();
            });
        }
    }

    // 切换标签页
    switchTab(tabName) {
        // 更新导航标签状态
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // 更新内容区域
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        const activeContent = this.safeGetElement(tabName);
        if (activeContent) {
            activeContent.classList.add('active');
        }

        this.currentTab = tabName;
    }

    // 更新UI
    updateUI() {
        this.updateCurrentSiteStatus();
        this.updateDashboardHoneypotDisplay();
        if (this.currentTab === 'logs') {
            this.updateLogsDisplay();
        }
    }

    // 仪表板蜜罐检测相关方法
    async updateDashboardHoneypotDisplay() {
        await this.loadHoneypotDetections();
        this.updateDashboardStats();
        this.renderDashboardHoneypotList();
    }

    updateDashboardStats() {
        const highCount = this.honeypotDetections.filter(d => d.confidence === 'high').length;
        const mediumCount = this.honeypotDetections.filter(d => d.confidence === 'medium').length;
        const lowCount = this.honeypotDetections.filter(d => d.confidence === 'low').length;
        const totalCount = this.honeypotDetections.length;

        // 安全地更新仪表板统计数字
        this.safeSetText('highConfidenceCount', highCount);
        this.safeSetText('mediumConfidenceCount', mediumCount);
        this.safeSetText('lowConfidenceCount', lowCount);
        this.safeSetText('totalProtected', totalCount);
    }

    renderDashboardHoneypotList() {
        const container = this.safeGetElement('dashboardHoneypotList');
        const emptyState = this.safeGetElement('dashboardEmptyState');
        
        if (!container) return;

        const filteredDetections = this.getDashboardFilteredDetections();

        if (filteredDetections.length === 0) {
            if (emptyState) emptyState.style.display = 'block';
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">暂无蜜罐检测记录</div><div class="empty-desc">当检测到蜜罐特征时，结果将在这里显示</div></div>';
            return;
        }

        if (emptyState) emptyState.style.display = 'none';

        // 只显示最近5条记录
        const recentDetections = filteredDetections.slice(0, 5);
        
        const html = recentDetections.map(detection => {
            const time = new Date(detection.timestamp).toLocaleString();
            const confidenceClass = detection.confidence || 'medium';
            const icon = confidenceClass === 'high' ? '🚨' : confidenceClass === 'medium' ? '⚠️' : 'ℹ️';

            return `
                <div class="honeypot-item">
                    <div class="honeypot-icon">${icon}</div>
                    <div class="honeypot-content">
                        <div class="honeypot-title">${detection.honeypotType || '未知蜜罐类型'}</div>
                        <div class="honeypot-details">域名: ${detection.domain}</div>
                        <div class="honeypot-time">${time}</div>
                    </div>
                    <div class="honeypot-badge ${confidenceClass}">${this.getConfidenceText(confidenceClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    getDashboardFilteredDetections() {
        let filtered = [...this.honeypotDetections];

        // 置信度过滤
        const confidenceFilter = this.safeGetElement('dashboardConfidenceFilter');
        if (confidenceFilter && confidenceFilter.value !== 'all') {
            filtered = filtered.filter(d => d.confidence === confidenceFilter.value);
        }

        // 时间过滤
        const timeFilter = this.safeGetElement('dashboardTimeFilter');
        if (timeFilter && timeFilter.value !== 'all') {
            const now = Date.now();
            const timeRange = {
                'today': 24 * 60 * 60 * 1000,
                'week': 7 * 24 * 60 * 60 * 1000,
                'month': 30 * 24 * 60 * 60 * 1000
            };
            const range = timeRange[timeFilter.value];
            if (range) {
                filtered = filtered.filter(d => (now - d.timestamp) <= range);
            }
        }

        return filtered.sort((a, b) => b.timestamp - a.timestamp);
    }

    getConfidenceText(confidence) {
        const texts = {
            'high': '高风险',
            'medium': '中风险',
            'low': '低风险'
        };
        return texts[confidence] || '未知';
    }

    async clearHoneypotDetections() {
        if (confirm('确定要清空所有蜜罐检测记录吗？')) {
            this.honeypotDetections = [];
            await chrome.storage.local.set({ honeypotDetections: [] });
            this.updateDashboardHoneypotDisplay();
        }
    }

    async refreshDashboardHoneypotData() {
        await this.updateDashboardHoneypotDisplay();
    }

    // 当前网站蜜罐检测状态
    async updateCurrentSiteStatus() {
        try {
            // 获取当前活动标签页
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tabs.length === 0) {
                this.showCurrentSiteStatus('unknown', '无法获取当前网站', '', '请确保有活动的标签页');
                return;
            }

            const currentTab = tabs[0];
            const url = currentTab.url;
            const hostname = new URL(url).hostname;

            // 检查是否为特殊页面
            if (url.startsWith('chrome://') || url.startsWith('chrome-extension://') || url.startsWith('edge://')) {
                this.showCurrentSiteStatus('safe', '浏览器内部页面', hostname, '浏览器内部页面，无需检测');
                return;
            }

            // 检查当前网站的蜜罐检测结果
            const recentDetection = this.honeypotDetections.find(detection => {
                return detection.domain === hostname && (Date.now() - detection.timestamp) < 300000; // 5分钟内
            });

            if (recentDetection) {
                // 找到最近的检测结果
                const confidence = recentDetection.confidence;
                const honeypotType = recentDetection.honeypotType || '未知类型';
                const evidence = recentDetection.evidence || '无详细信息';

                if (confidence === 'high') {
                    this.showCurrentSiteStatus('danger', '🚨 检测到蜜罐！', hostname, `类型: ${honeypotType}\n证据: ${evidence}`);
                } else if (confidence === 'medium') {
                    this.showCurrentSiteStatus('warning', '⚠️ 疑似蜜罐', hostname, `类型: ${honeypotType}\n证据: ${evidence}`);
                } else {
                    this.showCurrentSiteStatus('warning', 'ℹ️ 低风险检测', hostname, `类型: ${honeypotType}\n证据: ${evidence}`);
                }
            } else {
                // 没有检测结果，显示安全状态
                this.showCurrentSiteStatus('safe', '✅ 未检测到蜜罐', hostname, '当前网站未发现蜜罐特征');
            }

        } catch (error) {
            console.error('更新当前网站状态失败:', error);
            this.showCurrentSiteStatus('unknown', '检测失败', '', '无法获取当前网站状态');
        }
    }

    showCurrentSiteStatus(type, title, url, details) {
        const statusCard = this.safeGetElement('currentSiteStatus');
        const statusIcon = this.safeGetElement('statusIcon');
        const statusTitle = this.safeGetElement('statusTitle');
        const statusUrl = this.safeGetElement('statusUrl');
        const statusDetails = this.safeGetElement('statusDetails');
        const statusBadge = this.safeGetElement('statusBadge');

        if (statusCard) {
            // 移除所有状态类
            statusCard.className = 'status-card';
            statusCard.classList.add(type);
        }

        if (statusIcon) {
            const icons = {
                'safe': '✅',
                'warning': '⚠️',
                'danger': '🚨',
                'checking': '🔍',
                'unknown': '❓'
            };
            statusIcon.textContent = icons[type] || '❓';
        }

        if (statusTitle) statusTitle.textContent = title;
        if (statusUrl) statusUrl.textContent = url;
        if (statusDetails) statusDetails.textContent = details;

        if (statusBadge) {
            const badges = {
                'safe': '安全',
                'warning': '警告',
                'danger': '危险',
                'checking': '检测中',
                'unknown': '未知'
            };
            statusBadge.textContent = badges[type] || '未知';
            statusBadge.className = `status-badge ${type}`;
        }
    }

    // 日志管理功能
    async updateLogsDisplay() {
        await this.loadLogs();
        this.renderLogs();
    }

    renderLogs() {
        const container = this.safeGetElement('logsContainer');
        if (!container) return;

        const filteredLogs = this.getFilteredLogs();

        if (filteredLogs.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">📝</div><div class="empty-title">暂无检测日志</div><div class="empty-desc">检测活动将在这里显示</div></div>';
            return;
        }

        const html = filteredLogs.map(log => {
            const time = new Date(log.timestamp).toLocaleString();
            const levelClass = log.level || 'medium';
            const icon = this.getLogIcon(log.type);

            return `
                <div class="log-item">
                    <div class="log-icon">${icon}</div>
                    <div class="log-content">
                        <div class="log-title">${log.title || log.type || '未知事件'}</div>
                        <div class="log-details">${log.details || log.message || '无详细信息'}</div>
                        <div class="log-time">${time}</div>
                    </div>
                    <div class="log-badge ${levelClass}">${this.getLevelText(levelClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    getFilteredLogs() {
        let filtered = [...this.logs];

        // 类型过滤
        const typeFilter = this.safeGetElement('logTypeFilter');
        if (typeFilter && typeFilter.value !== 'all') {
            filtered = filtered.filter(log => log.type === typeFilter.value);
        }

        // 级别过滤
        const levelFilter = this.safeGetElement('logLevelFilter');
        if (levelFilter && levelFilter.value !== 'all') {
            filtered = filtered.filter(log => log.level === levelFilter.value);
        }

        return filtered.sort((a, b) => b.timestamp - a.timestamp).slice(0, 50); // 最多显示50条
    }

    getLogIcon(type) {
        const icons = {
            'honeypot': '🍯',
            'fingerprint': '🔒',
            'jsonp': '🚫',
            'storage': '💾',
            'redirect': '↗️',
            'default': '📝'
        };
        return icons[type] || icons.default;
    }

    getLevelText(level) {
        const texts = {
            'high': '高风险',
            'medium': '中风险',
            'low': '低风险'
        };
        return texts[level] || '未知';
    }

    async clearAllLogs() {
        if (confirm('确定要清空所有检测日志吗？此操作不可撤销。')) {
            this.logs = [];
            await chrome.storage.local.set({ detectionLogs: [] });
            this.renderLogs();
        }
    }

    async exportLogs() {
        try {
            const exportData = {
                exportTime: new Date().toISOString(),
                totalLogs: this.logs.length,
                logs: this.logs
            };

            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = `honeypot-detection-logs-${new Date().toISOString().split('T')[0]}.json`;
            a.click();

            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('导出日志失败:', error);
            alert('导出失败，请重试');
        }
    }

    filterLogs() {
        this.renderLogs();
    }

    // 配置管理功能
    async exportConfiguration() {
        try {
            const exportData = {
                exportTime: new Date().toISOString(),
                version: '2.2.0',
                configuration: this.config
            };

            const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = `honeypot-detector-config-${new Date().toISOString().split('T')[0]}.json`;
            a.click();

            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('导出配置失败:', error);
            alert('导出失败，请重试');
        }
    }

    async importConfiguration() {
        try {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';

            input.onchange = async (event) => {
                const file = event.target.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = async (e) => {
                    try {
                        const importData = JSON.parse(e.target.result);

                        if (importData.configuration) {
                            // 合并配置，保留默认值
                            this.config = { ...this.getDefaultConfig(), ...importData.configuration };
                            await this.saveConfig();

                            alert('配置导入成功！页面将刷新以应用新配置。');
                            location.reload();
                        } else {
                            alert('配置文件格式错误');
                        }
                    } catch (error) {
                        console.error('解析配置文件失败:', error);
                        alert('配置文件格式错误，请检查文件内容');
                    }
                };
                reader.readAsText(file);
            };

            input.click();
        } catch (error) {
            console.error('导入配置失败:', error);
            alert('导入失败，请重试');
        }
    }

    async resetConfiguration() {
        if (confirm('确定要重置所有配置到默认值吗？此操作不可撤销。')) {
            this.config = this.getDefaultConfig();
            await this.saveConfig();
            alert('配置已重置！页面将刷新以应用默认配置。');
            location.reload();
        }
    }

    async clearAllData() {
        if (confirm('⚠️ 警告：此操作将清空所有数据，包括：\n• 所有检测日志\n• 所有蜜罐检测记录\n• 所有统计数据\n• 用户配置\n\n此操作不可撤销，确定要继续吗？')) {
            if (confirm('最后确认：真的要清空所有数据吗？')) {
                try {
                    // 清空所有存储数据
                    await chrome.storage.local.clear();

                    // 重新设置默认配置
                    this.config = this.getDefaultConfig();
                    await this.saveConfig();

                    alert('所有数据已清空！页面将刷新。');
                    location.reload();
                } catch (error) {
                    console.error('清空数据失败:', error);
                    alert('清空数据失败，请重试');
                }
            }
        }
    }

    // 开始自动更新
    startAutoUpdate() {
        this.updateInterval = setInterval(async () => {
            await this.loadStats();
            await this.loadHoneypotDetections();
            this.updateUI();
        }, 5000); // 每5秒更新一次
    }

    // 停止自动更新
    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.modernUISafe = new ModernUISafe();
});

// 页面卸载时清理
window.addEventListener('beforeunload', () => {
    if (window.modernUISafe) {
        window.modernUISafe.stopAutoUpdate();
    }
});
