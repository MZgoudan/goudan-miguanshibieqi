/**
 * 狗蛋蜜罐识别器 - 现代化UI控制器
 */

'use strict';

class ModernUI {
    constructor() {
        this.currentTab = 'dashboard';
        this.config = {};
        this.stats = {};
        this.logs = [];
        this.honeypotDetections = [];
        this.activityChart = null;
        this.updateInterval = null;
        
        this.init();
    }

    async init() {
        await this.loadConfig();
        await this.loadStats();
        await this.loadLogs();
        await this.loadHoneypotDetections();

        this.setupEventListeners();
        this.setupChart();
        this.updateUI();
        this.startAutoUpdate();

        console.log('现代化UI初始化完成');
    }

    // 加载配置
    async loadConfig() {
        try {
            const result = await chrome.storage.local.get(['enhancedConfig']);
            this.config = result.enhancedConfig || this.getDefaultConfig();
        } catch (error) {
            console.warn('加载配置失败:', error);
            this.config = this.getDefaultConfig();
        }
    }

    // 加载统计数据
    async loadStats() {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getStats' });
            this.stats = response || {
                detectionCount: 0,
                notificationCount: 0,
                averageDetectionTime: 0,
                uptime: 0,
                threatsBlocked: 0,
                fingerprintBlocked: 0
            };
        } catch (error) {
            console.warn('加载统计失败:', error);
            this.stats = {
                detectionCount: 0,
                notificationCount: 0,
                averageDetectionTime: 0,
                uptime: 0,
                threatsBlocked: 0,
                fingerprintBlocked: 0
            };
        }
    }

    // 加载日志
    async loadLogs() {
        try {
            const result = await chrome.storage.local.get(['detectionLogs']);
            this.logs = result.detectionLogs || [];
        } catch (error) {
            console.warn('加载日志失败:', error);
            this.logs = [];
        }
    }

    // 加载蜜罐检测记录
    async loadHoneypotDetections() {
        try {
            const result = await chrome.storage.local.get(['honeypotDetections']);
            this.honeypotDetections = result.honeypotDetections || [];
        } catch (error) {
            console.warn('加载蜜罐检测记录失败:', error);
            this.honeypotDetections = [];
        }
    }

    // 获取默认配置
    getDefaultConfig() {
        return {
            antiHoneyPot: { enabled: true, sensitivity: 'medium' },
            niffler: { enabled: true, threshold: 4 },
            antiFingerprint: { enabled: true },
            honeypotDetection: { enabled: true },
            ui: { showNotifications: true, showBadge: true, detailedLogs: false },
            performance: { maxLogEntries: 100, cleanupInterval: 30 }
        };
    }

    // 设置事件监听器
    setupEventListeners() {
        // 导航标签切换
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.dataset.tab;
                this.switchTab(tabName);
            });
        });

        // 设置项监听
        this.setupSettingsListeners();
        
        // 按钮事件
        this.setupButtonListeners();

        // 滑块事件
        this.setupSliderListeners();

        // 模态框事件
        this.setupModalListeners();

        // 蜜罐检测相关事件
        this.setupHoneypotListeners();
    }

    // 设置设置项监听器
    setupSettingsListeners() {
        // 切换开关
        const toggles = [
            { id: 'antiHoneyPotEnabled', path: 'antiHoneyPot.enabled' },
            { id: 'nifflerEnabled', path: 'niffler.enabled' },
            { id: 'antiFingerprintEnabled', path: 'antiFingerprint.enabled' },
            { id: 'honeypotDetectionEnabled', path: 'honeypotDetection.enabled' },
            { id: 'showNotifications', path: 'ui.showNotifications' },
            { id: 'showBadge', path: 'ui.showBadge' },
            { id: 'detailedLogs', path: 'ui.detailedLogs' }
        ];

        toggles.forEach(({ id, path }) => {
            const element = document.getElementById(id);
            if (element) {
                element.checked = this.getConfigValue(path);
                element.addEventListener('change', () => {
                    this.setConfigValue(path, element.checked);
                });
            }
        });

        // 选择框
        const selects = [
            { id: 'detectionSensitivity', path: 'antiHoneyPot.sensitivity' }
        ];

        selects.forEach(({ id, path }) => {
            const element = document.getElementById(id);
            if (element) {
                element.value = this.getConfigValue(path) || 'medium';
                element.addEventListener('change', () => {
                    this.setConfigValue(path, element.value);
                });
            }
        });
    }

    // 设置按钮监听器
    setupButtonListeners() {
        // 日志控制按钮
        document.getElementById('clearLogs')?.addEventListener('click', () => {
            this.clearLogs();
        });

        document.getElementById('exportLogs')?.addEventListener('click', () => {
            this.exportLogs();
        });

        // 配置管理按钮
        document.getElementById('exportConfig')?.addEventListener('click', () => {
            this.showConfigModal('export');
        });

        document.getElementById('importConfig')?.addEventListener('click', () => {
            this.showConfigModal('import');
        });

        document.getElementById('resetConfig')?.addEventListener('click', () => {
            this.resetConfig();
        });

        document.getElementById('clearAllData')?.addEventListener('click', () => {
            this.clearAllData();
        });

        // 底部按钮
        document.getElementById('aboutBtn')?.addEventListener('click', () => {
            this.showAbout();
        });

        document.getElementById('helpBtn')?.addEventListener('click', () => {
            this.showHelp();
        });
    }

    // 设置滑块监听器
    setupSliderListeners() {
        const sliders = [
            { id: 'nifflerThreshold', path: 'niffler.threshold' },
            { id: 'maxLogEntries', path: 'performance.maxLogEntries' },
            { id: 'cleanupInterval', path: 'performance.cleanupInterval' }
        ];

        sliders.forEach(({ id, path }) => {
            const slider = document.getElementById(id);
            const valueDisplay = slider?.parentElement.querySelector('.slider-value');
            
            if (slider && valueDisplay) {
                slider.value = this.getConfigValue(path) || slider.value;
                valueDisplay.textContent = slider.value;
                
                slider.addEventListener('input', () => {
                    valueDisplay.textContent = slider.value;
                    this.setConfigValue(path, parseInt(slider.value));
                });
            }
        });
    }

    // 设置模态框监听器
    setupModalListeners() {
        const modal = document.getElementById('configModal');
        const closeBtn = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelModal');
        const confirmBtn = document.getElementById('confirmModal');

        [closeBtn, cancelBtn].forEach(btn => {
            btn?.addEventListener('click', () => {
                this.hideConfigModal();
            });
        });

        confirmBtn?.addEventListener('click', () => {
            this.handleConfigModalConfirm();
        });

        // 点击背景关闭模态框
        modal?.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.hideConfigModal();
            }
        });
    }

    // 切换标签页
    switchTab(tabName) {
        // 更新导航状态
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // 更新内容显示
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.toggle('active', content.id === tabName);
        });

        this.currentTab = tabName;

        // 特定标签页的初始化
        if (tabName === 'logs') {
            this.updateLogsDisplay();
        }
    }

    // 设置图表
    setupChart() {
        const canvas = document.getElementById('activityChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        
        // 简单的活动图表绘制
        this.drawActivityChart(ctx, canvas.width, canvas.height);
    }

    // 绘制活动图表
    drawActivityChart(ctx, width, height) {
        ctx.clearRect(0, 0, width, height);
        
        // 绘制网格
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1;
        
        for (let i = 0; i <= 10; i++) {
            const x = (width / 10) * i;
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, height);
            ctx.stroke();
        }
        
        for (let i = 0; i <= 5; i++) {
            const y = (height / 5) * i;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(width, y);
            ctx.stroke();
        }
        
        // 绘制数据线
        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 2;
        ctx.beginPath();
        
        const dataPoints = this.generateChartData();
        dataPoints.forEach((point, index) => {
            const x = (width / (dataPoints.length - 1)) * index;
            const y = height - (point / 100) * height;
            
            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        
        ctx.stroke();
        
        // 绘制数据点
        ctx.fillStyle = '#667eea';
        dataPoints.forEach((point, index) => {
            const x = (width / (dataPoints.length - 1)) * index;
            const y = height - (point / 100) * height;
            
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, 2 * Math.PI);
            ctx.fill();
        });
    }

    // 生成图表数据
    generateChartData() {
        // 模拟数据，实际应该从统计中获取
        return [20, 35, 45, 30, 55, 40, 65, 50, 70, 60, 80];
    }

    // 设置蜜罐检测监听器
    setupHoneypotListeners() {
        // 仪表板控制按钮
        const refreshBtn = document.getElementById('refreshHoneypotData');
        const clearBtn = document.getElementById('clearHoneypotData');
        const dashboardTimeFilter = document.getElementById('dashboardTimeFilter');
        const dashboardConfidenceFilter = document.getElementById('dashboardConfidenceFilter');

        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshDashboardHoneypotData());
        }
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearHoneypotDetections());
        }
        if (dashboardTimeFilter) {
            dashboardTimeFilter.addEventListener('change', () => this.updateDashboardHoneypotDisplay());
        }
        if (dashboardConfidenceFilter) {
            dashboardConfidenceFilter.addEventListener('change', () => this.updateDashboardHoneypotDisplay());
        }
    }

    // 更新UI
    updateUI() {
        this.updateStats();
        this.updateStatus();
        this.updateDashboardHoneypotDisplay();
        this.updateHoneypotDetections();
    }

    // 更新统计数据
    updateStats() {
        // 安全地更新统计数据，检查元素是否存在
        const totalDetectionsEl = document.getElementById('totalDetections');
        const threatsBlockedEl = document.getElementById('threatsBlocked');
        const fingerprintBlockedEl = document.getElementById('fingerprintBlocked');
        const avgResponseTimeEl = document.getElementById('avgResponseTime');
        const uptimeEl = document.getElementById('uptime');

        if (totalDetectionsEl) totalDetectionsEl.textContent = this.stats.detectionCount || 0;
        if (threatsBlockedEl) threatsBlockedEl.textContent = this.stats.threatsBlocked || 0;
        if (fingerprintBlockedEl) fingerprintBlockedEl.textContent = this.stats.fingerprintBlocked || 0;
        if (avgResponseTimeEl) avgResponseTimeEl.textContent = `${Math.round(this.stats.averageDetectionTime || 0)}ms`;

        // 更新运行时间
        if (uptimeEl) {
            const uptimeMinutes = Math.round((this.stats.uptime || 0) / 60000);
            uptimeEl.textContent = `运行时间: ${uptimeMinutes}分钟`;
        }
    }

    // 更新状态指示器
    updateStatus() {
        const statusDot = document.querySelector('.status-dot');
        const statusText = document.querySelector('.status-text');

        if (statusDot && statusText) {
            if (this.config.antiHoneyPot?.enabled || this.config.niffler?.enabled) {
                statusDot.className = 'status-dot active';
                statusText.textContent = '运行中';
            } else {
                statusDot.className = 'status-dot inactive';
                statusText.textContent = '已停用';
            }
        }
    }

    // 更新最近活动
    updateRecentActivity() {
        const container = document.getElementById('recentActivity');
        if (!container) return;

        container.innerHTML = '';
        
        const recentLogs = this.logs.slice(-5).reverse();
        
        if (recentLogs.length === 0) {
            container.innerHTML = '<div class="activity-item"><div class="activity-content"><div class="activity-title">暂无活动记录</div></div></div>';
            return;
        }

        recentLogs.forEach(log => {
            const item = document.createElement('div');
            item.className = 'activity-item';
            
            const iconClass = this.getLogIconClass(log.level);
            const timeAgo = this.getTimeAgo(log.timestamp);
            
            item.innerHTML = `
                <div class="activity-icon ${iconClass}">${this.getLogIcon(log.type)}</div>
                <div class="activity-content">
                    <div class="activity-title">${log.title}</div>
                    <div class="activity-time">${timeAgo}</div>
                </div>
            `;
            
            container.appendChild(item);
        });
    }

    // 获取日志图标类
    getLogIconClass(level) {
        switch (level) {
            case 'high': return 'danger';
            case 'medium': return 'warning';
            case 'low': return 'success';
            default: return 'success';
        }
    }

    // 获取日志图标
    getLogIcon(type) {
        const icons = {
            honeypot: '🕷️',
            fingerprint: '🛡️',
            jsonp: '🌐',
            storage: '💾',
            clipboard: '📋'
        };
        return icons[type] || '✓';
    }

    // 获取时间差
    getTimeAgo(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        
        if (minutes < 1) return '刚刚';
        if (minutes < 60) return `${minutes}分钟前`;
        
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}小时前`;
        
        const days = Math.floor(hours / 24);
        return `${days}天前`;
    }

    // 配置相关方法
    getConfigValue(path) {
        const keys = path.split('.');
        let value = this.config;
        
        for (const key of keys) {
            if (value && typeof value === 'object' && key in value) {
                value = value[key];
            } else {
                return undefined;
            }
        }
        
        return value;
    }

    async setConfigValue(path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        let target = this.config;
        
        for (const key of keys) {
            if (!target[key] || typeof target[key] !== 'object') {
                target[key] = {};
            }
            target = target[key];
        }
        
        target[lastKey] = value;
        
        try {
            await chrome.storage.local.set({ enhancedConfig: this.config });
            console.log('配置已保存:', path, '=', value);
        } catch (error) {
            console.warn('配置保存失败:', error);
        }
    }

    // 日志相关方法
    updateLogsDisplay() {
        const container = document.getElementById('logsContainer');
        if (!container) return;

        container.innerHTML = '';
        
        if (this.logs.length === 0) {
            container.innerHTML = '<div class="log-item"><div class="log-content"><div class="log-title">暂无日志记录</div></div></div>';
            return;
        }

        this.logs.slice().reverse().forEach(log => {
            const item = document.createElement('div');
            item.className = `log-item ${log.level}`;
            
            item.innerHTML = `
                <div class="log-icon">${this.getLogIcon(log.type)}</div>
                <div class="log-content">
                    <div class="log-title">${log.title}</div>
                    <div class="log-details">${log.details}</div>
                    <div class="log-time">${new Date(log.timestamp).toLocaleString()}</div>
                </div>
                <div class="log-badge ${log.level}">${this.getLevelText(log.level)}</div>
            `;
            
            container.appendChild(item);
        });
    }

    getLevelText(level) {
        const texts = {
            high: '高风险',
            medium: '中风险',
            low: '低风险'
        };
        return texts[level] || '未知';
    }

    async clearLogs() {
        if (confirm('确定要清空所有日志吗？')) {
            this.logs = [];
            await chrome.storage.local.set({ detectionLogs: [] });
            this.updateLogsDisplay();
            this.updateRecentActivity();
        }
    }

    exportLogs() {
        const data = JSON.stringify(this.logs, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `honeypot-logs-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        
        URL.revokeObjectURL(url);
    }

    // 模态框相关方法
    showConfigModal(mode) {
        const modal = document.getElementById('configModal');
        const textarea = document.getElementById('configData');
        const title = document.querySelector('.modal-title');

        if (modal && textarea && title) {
            if (mode === 'export') {
                title.textContent = '导出配置';
                textarea.value = JSON.stringify(this.config, null, 2);
                textarea.readOnly = true;
            } else {
                title.textContent = '导入配置';
                textarea.value = '';
                textarea.readOnly = false;
                textarea.placeholder = '请粘贴配置JSON数据...';
            }

            modal.classList.add('show');
            this.modalMode = mode;
        }
    }

    hideConfigModal() {
        const modal = document.getElementById('configModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    async handleConfigModalConfirm() {
        const textarea = document.getElementById('configData');

        if (textarea) {
            if (this.modalMode === 'export') {
                // 复制到剪贴板
                textarea.select();
                try {
                    document.execCommand('copy');
                    alert('配置已复制到剪贴板！');
                } catch (error) {
                    console.warn('复制失败:', error);
                    alert('复制失败，请手动复制');
                }
            } else {
                // 导入配置
                try {
                    const newConfig = JSON.parse(textarea.value);
                    this.config = { ...this.getDefaultConfig(), ...newConfig };
                    await chrome.storage.local.set({ enhancedConfig: this.config });

                    // 重新加载UI
                    location.reload();
                } catch (error) {
                    alert('配置格式错误，请检查JSON格式！');
                    return;
                }
            }

            this.hideConfigModal();
        }
    }

    async resetConfig() {
        if (confirm('确定要重置所有配置吗？这将恢复默认设置。')) {
            this.config = this.getDefaultConfig();
            await chrome.storage.local.set({ enhancedConfig: this.config });
            location.reload();
        }
    }

    async clearAllData() {
        if (confirm('确定要清空所有数据吗？这将删除配置、日志和统计数据。')) {
            await chrome.storage.local.clear();
            await chrome.runtime.sendMessage({ action: 'clearStats' });
            location.reload();
        }
    }

    showAbout() {
        alert(`狗蛋蜜罐识别器 v2.0.0\n\n融合四大插件优势的全能蜜罐识别与对抗工具\n\n• Anti-HoneyPot轻量级检测\n• Niffler双重验证机制\n• AntiHoneypot多层次检测\n• Heimdallr规则引擎\n\n开发者: AI Assistant`);
    }

    showHelp() {
        const helpText = `使用帮助：

1. 仪表板：查看实时统计和活动
2. 检测设置：配置各种检测模块
3. 检测日志：查看详细的检测记录
4. 高级设置：管理配置和性能选项

快捷操作：
• 点击状态指示器查看详情
• 使用滑块调整参数
• 导出/导入配置进行备份

如需更多帮助，请查看README.md文档。`;
        
        alert(helpText);
    }

    // 启动自动更新
    startAutoUpdate() {
        this.updateInterval = setInterval(async () => {
            await this.loadStats();
            await this.loadLogs();
            this.updateUI();
            
            // 更新图表
            if (this.currentTab === 'dashboard') {
                this.setupChart();
            }
        }, 5000); // 每5秒更新一次
    }

    // 停止自动更新
    stopAutoUpdate() {
        if (this.updateInterval) {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }

    // 蜜罐检测相关方法
    async updateHoneypotDetections() {
        await this.loadHoneypotDetections();
        this.renderHoneypotDetections();
        this.updateHoneypotStats();
    }

    renderHoneypotDetections() {
        const container = document.getElementById('honeypotContainer');
        const emptyState = document.getElementById('honeypotEmptyState');

        if (!container) return;

        const filteredDetections = this.getFilteredHoneypotDetections();

        if (filteredDetections.length === 0) {
            if (emptyState) emptyState.style.display = 'block';
            container.innerHTML = '<div class="empty-state" id="honeypotEmptyState"><div class="empty-icon">🔍</div><div class="empty-title">暂无蜜罐检测记录</div><div class="empty-desc">当检测到蜜罐特征时，结果将在这里显示</div></div>';
            return;
        }

        if (emptyState) emptyState.style.display = 'none';

        const html = filteredDetections.map(detection => {
            const time = new Date(detection.timestamp).toLocaleString();
            const confidenceClass = detection.confidence || 'medium';
            const icon = confidenceClass === 'high' ? '🚨' : confidenceClass === 'medium' ? '⚠️' : 'ℹ️';

            return `
                <div class="honeypot-item">
                    <div class="honeypot-icon">${icon}</div>
                    <div class="honeypot-content">
                        <div class="honeypot-title">${detection.honeypotType || '未知蜜罐类型'}</div>
                        <div class="honeypot-details">域名: ${detection.domain} | 规则: ${detection.ruleName || 'N/A'}</div>
                        <div class="honeypot-evidence">${detection.evidence || '无证据信息'}</div>
                        <div class="honeypot-time">${time}</div>
                    </div>
                    <div class="honeypot-badge ${confidenceClass}">${this.getConfidenceText(confidenceClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    getFilteredHoneypotDetections() {
        let filtered = [...this.honeypotDetections];

        // 置信度过滤
        const confidenceFilter = document.getElementById('honeypotConfidenceFilter');
        if (confidenceFilter && confidenceFilter.value !== 'all') {
            filtered = filtered.filter(d => d.confidence === confidenceFilter.value);
        }

        // 时间过滤
        const timeFilter = document.getElementById('honeypotTimeFilter');
        if (timeFilter && timeFilter.value !== 'all') {
            const now = Date.now();
            const timeRange = {
                'today': 24 * 60 * 60 * 1000,
                'week': 7 * 24 * 60 * 60 * 1000,
                'month': 30 * 24 * 60 * 60 * 1000
            };
            const range = timeRange[timeFilter.value];
            if (range) {
                filtered = filtered.filter(d => (now - d.timestamp) <= range);
            }
        }

        return filtered.sort((a, b) => b.timestamp - a.timestamp);
    }

    updateHoneypotStats() {
        const highCount = this.honeypotDetections.filter(d => d.confidence === 'high').length;
        const mediumCount = this.honeypotDetections.filter(d => d.confidence === 'medium').length;
        const lowCount = this.honeypotDetections.filter(d => d.confidence === 'low').length;

        const highElement = document.getElementById('highConfidenceCount');
        const mediumElement = document.getElementById('mediumConfidenceCount');
        const lowElement = document.getElementById('lowConfidenceCount');

        if (highElement) highElement.textContent = highCount;
        if (mediumElement) mediumElement.textContent = mediumCount;
        if (lowElement) lowElement.textContent = lowCount;
    }

    getConfidenceText(confidence) {
        const texts = {
            'high': '高风险',
            'medium': '中风险',
            'low': '未知'
        };
        return texts[confidence] || '未知';
    }

    async clearHoneypotDetections() {
        if (confirm('确定要清空所有蜜罐检测记录吗？')) {
            this.honeypotDetections = [];
            await chrome.storage.local.set({ honeypotDetections: [] });
            this.updateHoneypotDetections();
        }
    }

    async refreshHoneypotDetections() {
        await this.updateHoneypotDetections();
    }

    filterHoneypotDetections() {
        this.renderHoneypotDetections();
    }

    // 仪表板蜜罐检测相关方法
    async updateDashboardHoneypotDisplay() {
        await this.loadHoneypotDetections();
        this.updateDashboardStats();
        this.renderDashboardHoneypotList();
    }

    updateDashboardStats() {
        const highCount = this.honeypotDetections.filter(d => d.confidence === 'high').length;
        const mediumCount = this.honeypotDetections.filter(d => d.confidence === 'medium').length;
        const lowCount = this.honeypotDetections.filter(d => d.confidence === 'low').length;
        const totalCount = this.honeypotDetections.length;

        // 更新仪表板统计数字
        const highElement = document.getElementById('highConfidenceCount');
        const mediumElement = document.getElementById('mediumConfidenceCount');
        const lowElement = document.getElementById('lowConfidenceCount');
        const totalElement = document.getElementById('totalProtected');

        if (highElement) highElement.textContent = highCount;
        if (mediumElement) mediumElement.textContent = mediumCount;
        if (lowElement) lowElement.textContent = lowCount;
        if (totalElement) totalElement.textContent = totalCount;
    }

    renderDashboardHoneypotList() {
        const container = document.getElementById('dashboardHoneypotList');
        const emptyState = document.getElementById('dashboardEmptyState');

        if (!container) return;

        const filteredDetections = this.getDashboardFilteredDetections();

        if (filteredDetections.length === 0) {
            if (emptyState) emptyState.style.display = 'block';
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-title">暂无蜜罐检测记录</div><div class="empty-desc">当检测到蜜罐特征时，结果将在这里显示</div></div>';
            return;
        }

        if (emptyState) emptyState.style.display = 'none';

        // 只显示最近5条记录
        const recentDetections = filteredDetections.slice(0, 5);

        const html = recentDetections.map(detection => {
            const time = new Date(detection.timestamp).toLocaleString();
            const confidenceClass = detection.confidence || 'medium';
            const icon = confidenceClass === 'high' ? '🚨' : confidenceClass === 'medium' ? '⚠️' : 'ℹ️';

            return `
                <div class="honeypot-item">
                    <div class="honeypot-icon">${icon}</div>
                    <div class="honeypot-content">
                        <div class="honeypot-title">${detection.honeypotType || '未知蜜罐类型'}</div>
                        <div class="honeypot-details">域名: ${detection.domain}</div>
                        <div class="honeypot-time">${time}</div>
                    </div>
                    <div class="honeypot-badge ${confidenceClass}">${this.getConfidenceText(confidenceClass)}</div>
                </div>
            `;
        }).join('');

        container.innerHTML = html;
    }

    getDashboardFilteredDetections() {
        let filtered = [...this.honeypotDetections];

        // 置信度过滤
        const confidenceFilter = document.getElementById('dashboardConfidenceFilter');
        if (confidenceFilter && confidenceFilter.value !== 'all') {
            filtered = filtered.filter(d => d.confidence === confidenceFilter.value);
        }

        // 时间过滤
        const timeFilter = document.getElementById('dashboardTimeFilter');
        if (timeFilter && timeFilter.value !== 'all') {
            const now = Date.now();
            const timeRange = {
                'today': 24 * 60 * 60 * 1000,
                'week': 7 * 24 * 60 * 60 * 1000,
                'month': 30 * 24 * 60 * 60 * 1000
            };
            const range = timeRange[timeFilter.value];
            if (range) {
                filtered = filtered.filter(d => (now - d.timestamp) <= range);
            }
        }

        return filtered.sort((a, b) => b.timestamp - a.timestamp);
    }

    async refreshDashboardHoneypotData() {
        await this.updateDashboardHoneypotDisplay();
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.modernUI = new ModernUI();
});

// 页面卸载时清理
window.addEventListener('beforeunload', () => {
    if (window.modernUI) {
        window.modernUI.stopAutoUpdate();
    }
});

// 黑白名单管理功能
let whitelistManager = null;

// 初始化黑白名单管理器
async function initWhitelistManager() {
    try {
        // 等待whitelistManager加载
        let attempts = 0;
        while (!window.whitelistManager && attempts < 50) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }

        if (window.whitelistManager) {
            whitelistManager = window.whitelistManager;
            console.log('✅ 黑白名单管理器已连接');
            updateWhitelistStats();
            refreshWhitelistUI();
            updateCurrentSiteInfo();
        } else {
            console.warn('⚠️ 黑白名单管理器未找到');
        }
    } catch (error) {
        console.error('❌ 初始化黑白名单管理器失败:', error);
    }
}

// 更新黑白名单统计
async function updateWhitelistStats() {
    if (!whitelistManager) return;

    try {
        const lists = whitelistManager.getAllLists();

        const whitelistCountEl = document.getElementById('whitelistCount');
        const blacklistCountEl = document.getElementById('blacklistCount');
        const domainWhitelistCountEl = document.getElementById('domainWhitelistCount');
        const domainBlacklistCountEl = document.getElementById('domainBlacklistCount');

        if (whitelistCountEl) whitelistCountEl.textContent = lists.whitelist.length;
        if (blacklistCountEl) blacklistCountEl.textContent = lists.blacklist.length;
        if (domainWhitelistCountEl) domainWhitelistCountEl.textContent = lists.domainWhitelist.length;
        if (domainBlacklistCountEl) domainBlacklistCountEl.textContent = lists.domainBlacklist.length;

    } catch (error) {
        console.error('❌ 更新黑白名单统计失败:', error);
    }
}

// 刷新黑白名单UI
async function refreshWhitelistUI() {
    if (!whitelistManager) return;

    try {
        const lists = whitelistManager.getAllLists();

        // 更新白名单显示
        const whitelistContainer = document.getElementById('whitelistContainer');
        if (whitelistContainer) {
            const allWhitelist = [
                ...lists.whitelist.map(item => ({ value: item, type: 'URL' })),
                ...lists.domainWhitelist.map(item => ({ value: item, type: '域名' })),
                ...lists.keywordWhitelist.map(item => ({ value: item, type: '关键词' }))
            ];

            if (allWhitelist.length === 0) {
                whitelistContainer.innerHTML = '<div class="empty-state">暂无白名单条目</div>';
            } else {
                whitelistContainer.innerHTML = allWhitelist.map(item => `
                    <div class="list-item">
                        <div class="list-item-text">
                            <span class="list-item-type">${item.type}</span>
                            ${item.value}
                        </div>
                        <button class="btn btn-danger btn-sm" onclick="removeFromWhitelistUI('${item.value}', '${item.type}')">删除</button>
                    </div>
                `).join('');
            }
        }

        // 更新黑名单显示
        const blacklistContainer = document.getElementById('blacklistContainer');
        if (blacklistContainer) {
            const allBlacklist = [
                ...lists.blacklist.map(item => ({ value: item, type: 'URL' })),
                ...lists.domainBlacklist.map(item => ({ value: item, type: '域名' })),
                ...lists.keywordBlacklist.map(item => ({ value: item, type: '关键词' }))
            ];

            if (allBlacklist.length === 0) {
                blacklistContainer.innerHTML = '<div class="empty-state">暂无黑名单条目</div>';
            } else {
                blacklistContainer.innerHTML = allBlacklist.map(item => `
                    <div class="list-item">
                        <div class="list-item-text">
                            <span class="list-item-type">${item.type}</span>
                            ${item.value}
                        </div>
                        <button class="btn btn-danger btn-sm" onclick="removeFromBlacklistUI('${item.value}', '${item.type}')">删除</button>
                    </div>
                `).join('');
            }
        }

    } catch (error) {
        console.error('❌ 刷新黑白名单UI失败:', error);
    }
}

// 更新当前网站信息
async function updateCurrentSiteInfo() {
    try {
        // 尝试获取当前标签页信息
        if (chrome && chrome.tabs) {
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                if (tabs[0]) {
                    const url = tabs[0].url;
                    const domain = new URL(url).hostname;

                    const currentUrlEl = document.getElementById('currentUrl');
                    const currentDomainEl = document.getElementById('currentDomain');
                    const currentStatusEl = document.getElementById('currentStatus');

                    if (currentUrlEl) currentUrlEl.textContent = url;
                    if (currentDomainEl) currentDomainEl.textContent = domain;

                    // 检查当前网站状态
                    if (whitelistManager && currentStatusEl) {
                        const whitelistCheck = whitelistManager.isWhitelisted(url);
                        const blacklistCheck = whitelistManager.isBlacklisted(url);

                        let status = '未知';
                        if (whitelistCheck.isWhitelisted) {
                            status = '✅ 在白名单中';
                        } else if (blacklistCheck.isBlacklisted) {
                            status = '🚫 在黑名单中';
                        } else {
                            status = '⚪ 未设置';
                        }

                        currentStatusEl.textContent = status;
                    }
                }
            });
        }
    } catch (error) {
        console.warn('⚠️ 更新当前网站信息失败:', error);
    }
}

// 添加到白名单
async function addToWhitelist() {
    const input = document.getElementById('whitelistInput');
    const typeSelect = document.getElementById('whitelistType');

    if (!input || !typeSelect) return;

    const value = input.value.trim();
    const type = typeSelect.value;

    if (!value) {
        alert('请输入要添加的内容');
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        const success = await whitelistManager.addToWhitelist(value, type);

        if (success) {
            input.value = '';
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        } else {
            alert('添加失败');
        }

    } catch (error) {
        console.error('❌ 添加白名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}

// 添加到黑名单
async function addToBlacklist() {
    const input = document.getElementById('blacklistInput');
    const typeSelect = document.getElementById('blacklistType');

    if (!input || !typeSelect) return;

    const value = input.value.trim();
    const type = typeSelect.value;

    if (!value) {
        alert('请输入要添加的内容');
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        const success = await whitelistManager.addToBlacklist(value, type);

        if (success) {
            input.value = '';
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        } else {
            alert('添加失败');
        }

    } catch (error) {
        console.error('❌ 添加黑名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}

// 从白名单移除
async function removeFromWhitelistUI(value, type) {
    if (!whitelistManager) return;

    try {
        const typeMap = { 'URL': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'domain';

        const success = await whitelistManager.removeFromWhitelist(value, actualType);

        if (success) {
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        }

    } catch (error) {
        console.error('❌ 移除白名单失败:', error);
    }
}

// 从黑名单移除
async function removeFromBlacklistUI(value, type) {
    if (!whitelistManager) return;

    try {
        const typeMap = { 'URL': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'domain';

        const success = await whitelistManager.removeFromBlacklist(value, actualType);

        if (success) {
            await updateWhitelistStats();
            await refreshWhitelistUI();
            await updateCurrentSiteInfo();
        }

    } catch (error) {
        console.error('❌ 移除黑名单失败:', error);
    }
}

// 添加当前网站到白名单
async function addCurrentToWhitelist(type) {
    if (!chrome || !chrome.tabs) {
        alert('无法获取当前网站信息');
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
        if (tabs[0]) {
            const url = tabs[0].url;
            const domain = new URL(url).hostname;

            const value = type === 'domain' ? domain : url;

            if (whitelistManager) {
                try {
                    const success = await whitelistManager.addToWhitelist(value, type);
                    if (success) {
                        await updateWhitelistStats();
                        await refreshWhitelistUI();
                        await updateCurrentSiteInfo();
                    }
                } catch (error) {
                    console.error('❌ 添加当前网站到白名单失败:', error);
                }
            }
        }
    });
}

// 添加当前网站到黑名单
async function addCurrentToBlacklist(type) {
    if (!chrome || !chrome.tabs) {
        alert('无法获取当前网站信息');
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
        if (tabs[0]) {
            const url = tabs[0].url;
            const domain = new URL(url).hostname;

            const value = type === 'domain' ? domain : url;

            if (whitelistManager) {
                try {
                    const success = await whitelistManager.addToBlacklist(value, type);
                    if (success) {
                        await updateWhitelistStats();
                        await refreshWhitelistUI();
                        await updateCurrentSiteInfo();
                    }
                } catch (error) {
                    console.error('❌ 添加当前网站到黑名单失败:', error);
                }
            }
        }
    });
}

// 刷新黑白名单UI
async function refreshWhitelistUI() {
    await updateWhitelistStats();
    await refreshWhitelistUI();
    await updateCurrentSiteInfo();
}

// 导出黑白名单数据
function exportWhitelistData() {
    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        const lists = whitelistManager.getAllLists();
        const exportData = {
            ...lists,
            exportTime: new Date().toISOString(),
            version: '2025.1.0'
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `whitelist-config-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);

    } catch (error) {
        console.error('❌ 导出黑白名单数据失败:', error);
        alert('导出失败');
    }
}

// 打开完整黑白名单设置
function openFullWhitelistSettings() {
    const settingsUrl = chrome.runtime.getURL('resource/popup/whitelist-settings.html');
    window.open(settingsUrl, '_blank');
}

// 清空所有黑白名单数据
async function clearAllWhitelistData() {
    if (!confirm('确定要清空所有黑白名单吗？此操作不可恢复！')) {
        return;
    }

    if (!whitelistManager) {
        alert('黑白名单管理器未初始化');
        return;
    }

    try {
        await whitelistManager.clearList('whitelist');
        await whitelistManager.clearList('blacklist');
        await whitelistManager.clearList('domainWhitelist');
        await whitelistManager.clearList('domainBlacklist');
        await whitelistManager.clearList('keywordWhitelist');
        await whitelistManager.clearList('keywordBlacklist');

        await updateWhitelistStats();
        await refreshWhitelistUI();
        await updateCurrentSiteInfo();

        alert('所有黑白名单已清空');

    } catch (error) {
        console.error('❌ 清空黑白名单失败:', error);
        alert('清空失败');
    }
}

// 页面加载完成后初始化黑白名单管理器
setTimeout(initWhitelistManager, 2000);
