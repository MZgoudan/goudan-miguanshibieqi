/**
 * 狗蛋蜜罐识别器 - 快速配置UI脚本
 */

// 快速配置UI控制器
class QuickConfigUI {
    constructor() {
        this.config = {};
        this.stats = {};
        this.init();
    }

    async init() {
        try {
            await this.loadConfig();
            await this.loadStats();
            this.setupEventListeners();
            this.updateUI();
            this.startAutoUpdate();
            console.log('快速配置UI初始化完成');
        } catch (error) {
            console.error('快速配置UI初始化失败:', error);
        }
    }

    async loadConfig() {
        try {
            if (chrome.storage && chrome.storage.local) {
                const result = await chrome.storage.local.get(['enhancedConfig']);
                this.config = result.enhancedConfig || {};
            }
        } catch (error) {
            console.warn('加载配置失败:', error);
            this.config = {};
        }
    }

    async loadStats() {
        try {
            if (chrome.runtime && chrome.runtime.sendMessage) {
                const response = await chrome.runtime.sendMessage({ action: 'getStats' });
                if (response && response.success) {
                    this.stats = response.stats || {};
                } else {
                    this.stats = {};
                }
            }
        } catch (error) {
            console.warn('加载统计失败:', error);
            this.stats = {};
        }
    }

    setupEventListeners() {
        // 模块切换按钮
        const moduleButtons = [
            { id: 'antiHoneyPotBtn', path: 'antiHoneyPot.enabled' },
            { id: 'nifflerBtn', path: 'niffler.enabled' },
            { id: 'antiFingerprintBtn', path: 'antiFingerprint.enabled' },
            { id: 'honeypotDetectionBtn', path: 'honeypotDetection.enabled' }
        ];

        moduleButtons.forEach(({ id, path }) => {
            const btn = document.getElementById(id);
            if (btn) {
                btn.addEventListener('click', () => {
                    const isActive = btn.classList.contains('active');
                    btn.classList.toggle('active');
                    this.setConfigValue(path, !isActive);
                });
            }
        });

        // 设置切换
        const toggles = [
            { id: 'notificationToggle', path: 'ui.showNotifications' },
            { id: 'badgeToggle', path: 'ui.showBadge' },
            { id: 'detailedLogsToggle', path: 'ui.detailedLogs' }
        ];

        toggles.forEach(({ id, path }) => {
            const toggle = document.getElementById(id);
            if (toggle) {
                toggle.addEventListener('click', () => {
                    const isActive = toggle.classList.contains('active');
                    toggle.classList.toggle('active');
                    this.setConfigValue(path, !isActive);
                });
            }
        });

        // 底部按钮
        document.getElementById('settingsBtn')?.addEventListener('click', () => {
            try {
                if (chrome.tabs && chrome.runtime) {
                    chrome.tabs.create({ 
                        url: chrome.runtime.getURL('resource/popup/modern-ui.html') 
                    });
                }
            } catch (error) {
                console.error('打开设置页面失败:', error);
            }
        });

        document.getElementById('helpBtn')?.addEventListener('click', () => {
            alert('狗蛋蜜罐识别器 v2.2.0\n\n快速配置界面，点击模块图标可开启/关闭功能。\n点击设置按钮打开完整配置界面。');
        });
    }

    updateUI() {
        // 更新统计数据
        document.getElementById('totalDetections').textContent = this.stats.detectionCount || 0;
        document.getElementById('threatsBlocked').textContent = this.stats.blockCount || 0;
        document.getElementById('fingerprintBlocked').textContent = this.stats.fingerprintBlocked || 0;
        
        const uptimeMinutes = Math.round((this.stats.uptime || 0) / 60000);
        document.getElementById('uptime').textContent = `${uptimeMinutes}分钟`;

        // 更新模块状态
        this.updateModuleStatus('antiHoneyPotBtn', 'antiHoneyPot.enabled');
        this.updateModuleStatus('nifflerBtn', 'niffler.enabled');
        this.updateModuleStatus('antiFingerprintBtn', 'antiFingerprint.enabled');
        this.updateModuleStatus('honeypotDetectionBtn', 'honeypotDetection.enabled');

        // 更新设置状态
        this.updateToggleStatus('notificationToggle', 'ui.showNotifications');
        this.updateToggleStatus('badgeToggle', 'ui.showBadge');
        this.updateToggleStatus('detailedLogsToggle', 'ui.detailedLogs');
    }

    updateModuleStatus(btnId, configPath) {
        const btn = document.getElementById(btnId);
        const isEnabled = this.getConfigValue(configPath);
        if (btn) {
            btn.classList.toggle('active', isEnabled !== false);
        }
    }

    updateToggleStatus(toggleId, configPath) {
        const toggle = document.getElementById(toggleId);
        const isEnabled = this.getConfigValue(configPath);
        if (toggle) {
            toggle.classList.toggle('active', isEnabled !== false);
        }
    }

    getConfigValue(path) {
        const keys = path.split('.');
        let value = this.config;
        
        for (const key of keys) {
            if (value && typeof value === 'object' && key in value) {
                value = value[key];
            } else {
                return undefined;
            }
        }
        
        return value;
    }

    async setConfigValue(path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        let target = this.config;
        
        for (const key of keys) {
            if (!target[key] || typeof target[key] !== 'object') {
                target[key] = {};
            }
            target = target[key];
        }
        
        target[lastKey] = value;
        
        try {
            if (chrome.storage && chrome.storage.local) {
                await chrome.storage.local.set({ enhancedConfig: this.config });
                console.log('配置已保存:', path, '=', value);
            }
        } catch (error) {
            console.warn('配置保存失败:', error);
        }
    }

    startAutoUpdate() {
        setInterval(async () => {
            try {
                await this.loadStats();
                this.updateUI();
            } catch (error) {
                console.warn('自动更新失败:', error);
            }
        }, 3000);
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('快速配置页面已加载');
    try {
        new QuickConfigUI();
    } catch (error) {
        console.error('快速配置UI创建失败:', error);
    }
});

// 错误处理
window.addEventListener('error', (event) => {
    console.error('快速配置页面错误:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('快速配置未处理的Promise拒绝:', event.reason);
});
