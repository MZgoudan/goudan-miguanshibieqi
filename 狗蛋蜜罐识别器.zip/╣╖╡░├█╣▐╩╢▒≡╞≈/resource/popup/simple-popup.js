/**
 * 狗蛋蜜罐识别器 - 简单弹窗UI脚本
 */

class SimplePopupUI {
    constructor() {
        console.log('SimplePopupUI构造函数被调用');
        window.simplePopupInitialized = true;
        this.init();
    }

    async init() {
        try {
            // 检查Chrome API可用性
            if (typeof chrome === 'undefined') {
                throw new Error('Chrome扩展API不可用');
            }

            await this.loadStatus();
            this.bindEvents();
            this.startAutoUpdate();
            this.showSuccess('界面加载成功');
        } catch (error) {
            console.error('初始化失败:', error);
            this.showError('初始化失败: ' + error.message);
        }
    }



    async loadStatus() {
        try {
            // 检查插件状态
            document.getElementById('pluginStatus').textContent = '运行中';

            // 从background script获取真实统计数据
            if (chrome.runtime && chrome.runtime.sendMessage) {
                try {
                    const response = await chrome.runtime.sendMessage({ action: 'getStats' });
                    if (response && response.success) {
                        document.getElementById('detectionCount').textContent = response.stats.detectionCount || 0;
                        document.getElementById('blockCount').textContent = response.stats.blockCount || 0;

                        // 显示最近检测结果
                        this.displayRecentDetections(response.stats.recentDetections || []);
                    } else {
                        // 使用默认数据
                        document.getElementById('detectionCount').textContent = '0';
                        document.getElementById('blockCount').textContent = '0';
                    }
                } catch (error) {
                    console.warn('获取统计数据失败:', error);
                    document.getElementById('detectionCount').textContent = '0';
                    document.getElementById('blockCount').textContent = '0';
                }
            }

        } catch (error) {
            console.warn('加载状态失败:', error);
            document.getElementById('pluginStatus').textContent = '状态未知';
        }
    }

    displayRecentDetections(detections) {
        // 在状态卡片下方显示最近的检测结果
        const existingResults = document.getElementById('recentDetections');
        if (existingResults) {
            existingResults.remove();
        }

        if (detections.length === 0) return;

        const resultsDiv = document.createElement('div');
        resultsDiv.id = 'recentDetections';
        resultsDiv.style.cssText = `
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            border-left: 4px solid #e74c3c;
        `;

        let html = '<h4 style="margin: 0 0 10px 0; color: #e74c3c; font-size: 14px;">🚨 最近检测到的威胁</h4>';

        detections.slice(0, 3).forEach(detection => {
            const time = new Date(detection.timestamp).toLocaleTimeString();
            html += `
                <div style="margin-bottom: 8px; padding: 8px; background: #fff5f5; border-radius: 4px; font-size: 12px;">
                    <div style="font-weight: 600; color: #c53030;">${detection.type}</div>
                    <div style="color: #666; margin-top: 2px;">${detection.host} - ${time}</div>
                    <div style="color: #888; font-size: 11px; margin-top: 2px;">${detection.evidence}</div>
                </div>
            `;
        });

        resultsDiv.innerHTML = html;

        // 插入到状态卡片后面
        const statusCard = document.querySelector('.status-card');
        if (statusCard && statusCard.parentNode) {
            statusCard.parentNode.insertBefore(resultsDiv, statusCard.nextSibling);
        }
    }

    bindEvents() {
        // 设置按钮
        document.getElementById('settingsBtn')?.addEventListener('click', () => {
            try {
                if (chrome.tabs && chrome.runtime) {
                    chrome.tabs.create({
                        url: chrome.runtime.getURL('resource/popup/modern-ui.html')
                    });
                } else {
                    throw new Error('Chrome API不可用');
                }
            } catch (error) {
                this.showError('打开设置页面失败: ' + error.message);
            }
        });

        // 测试按钮
        document.getElementById('testBtn')?.addEventListener('click', () => {
            try {
                chrome.tabs.create({
                    url: chrome.runtime.getURL('test/malicious-redirect-test.html')
                });
            } catch (error) {
                this.showError('打开测试页面失败');
            }
        });

        // UI选择按钮 - 显示UI选择菜单
        document.getElementById('uiSelectorBtn')?.addEventListener('click', () => {
            this.showUISelector();
        });

        // 关于按钮
        document.getElementById('aboutBtn')?.addEventListener('click', () => {
            alert('🐕 狗蛋蜜罐识别器 v2.2.0\n\n✨ 新功能:\n• 恶意页面跳转检测与拦截\n• 2025年最新规则库\n• 智能风险评估系统\n\n🛡️ 核心功能:\n• 蜜罐识别与对抗\n• 指纹识别防护\n• JSONP请求拦截\n• 多层次安全检测\n\n💡 使用提示:\n点击"界面风格"可切换不同UI\n点击"功能测试"可验证检测效果');
        });

        // 开关事件
        const switches = ['honeypotDetection', 'antiFingerprint', 'redirectBlock'];
        switches.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.addEventListener('change', (e) => {
                    this.showSuccess(`${this.getSwitchName(id)} ${e.target.checked ? '已开启' : '已关闭'}`);
                });
            }
        });
    }

    getSwitchName(id) {
        const names = {
            'honeypotDetection': '蜜罐检测',
            'antiFingerprint': '指纹对抗',
            'redirectBlock': '跳转拦截'
        };
        return names[id] || id;
    }

    startAutoUpdate() {
        setInterval(() => {
            this.loadStatus();
        }, 5000);
    }

    showError(message) {
        const errorDiv = document.getElementById('errorMsg');
        const successDiv = document.getElementById('successMsg');
        
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
        }
        
        if (successDiv) {
            successDiv.style.display = 'none';
        }
        
        setTimeout(() => {
            if (errorDiv) errorDiv.style.display = 'none';
        }, 3000);
    }

    showSuccess(message) {
        const errorDiv = document.getElementById('errorMsg');
        const successDiv = document.getElementById('successMsg');
        
        if (successDiv) {
            successDiv.textContent = message;
            successDiv.style.display = 'block';
        }
        
        if (errorDiv) {
            errorDiv.style.display = 'none';
        }
        
        setTimeout(() => {
            if (successDiv) successDiv.style.display = 'none';
        }, 2000);
    }

    showUISelector() {
        // 创建UI选择菜单
        const selectorDiv = document.createElement('div');
        selectorDiv.id = 'uiSelectorMenu';
        selectorDiv.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
        `;

        const menuDiv = document.createElement('div');
        menuDiv.style.cssText = `
            background: white;
            border-radius: 8px;
            padding: 20px;
            min-width: 280px;
            text-align: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        `;

        menuDiv.innerHTML = `
            <h3 style="margin-bottom: 15px; color: #333;">🎨 切换popup界面风格</h3>
            <p style="font-size: 12px; color: #666; margin-bottom: 20px; line-height: 1.4;">
                选择后，下次点击插件图标将直接显示所选界面
            </p>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                <button id="selectQuickUI" style="padding: 12px; border: 1px solid #ddd; border-radius: 4px; background: #f8f9fa; cursor: pointer; text-align: left;">
                    🚀 <strong>快速配置界面</strong><br><small style="color: #666;">简洁的模块开关，适合日常使用</small>
                </button>
                <button id="selectModernUI" style="padding: 12px; border: 1px solid #ddd; border-radius: 4px; background: #f8f9fa; cursor: pointer; text-align: left;">
                    ⚡ <strong>现代界面</strong><br><small style="color: #666;">完整的高级配置，功能丰富</small>
                </button>
                <button id="selectClassicUI" style="padding: 12px; border: 1px solid #ddd; border-radius: 4px; background: #f8f9fa; cursor: pointer; text-align: left;">
                    📋 <strong>经典界面</strong><br><small style="color: #666;">传统的设置管理界面</small>
                </button>
                <button id="selectSimpleUI" style="padding: 12px; border: 1px solid #ddd; border-radius: 4px; background: #fff3cd; cursor: pointer; text-align: left;">
                    🏠 <strong>默认简单界面</strong><br><small style="color: #666;">当前界面，基础信息显示</small>
                </button>
                <button id="cancelUISelector" style="padding: 8px; border: 1px solid #ccc; border-radius: 4px; background: #e9ecef; cursor: pointer; margin-top: 10px;">
                    取消
                </button>
            </div>
        `;

        selectorDiv.appendChild(menuDiv);
        document.body.appendChild(selectorDiv);

        // 绑定事件
        document.getElementById('selectQuickUI').addEventListener('click', () => {
            this.switchToUI('quick-config.html');
        });

        document.getElementById('selectModernUI').addEventListener('click', () => {
            this.switchToUI('modern-ui.html');
        });

        document.getElementById('selectClassicUI').addEventListener('click', () => {
            this.switchToUI('index.html');
        });

        document.getElementById('selectSimpleUI').addEventListener('click', () => {
            this.switchToUI('simple-popup.html');
        });

        document.getElementById('cancelUISelector').addEventListener('click', () => {
            document.body.removeChild(selectorDiv);
        });

        // 点击背景关闭
        selectorDiv.addEventListener('click', (e) => {
            if (e.target === selectorDiv) {
                document.body.removeChild(selectorDiv);
            }
        });
    }

    async switchToUI(uiFile) {
        try {
            // 关闭选择菜单
            const menu = document.getElementById('uiSelectorMenu');
            if (menu) {
                document.body.removeChild(menu);
            }

            // 显示切换提示
            this.showSuccess('正在切换界面...');

            // 确定UI类型
            let uiType;
            switch (uiFile) {
                case 'quick-config.html':
                    uiType = 'quick';
                    break;
                case 'modern-ui.html':
                    uiType = 'modern';
                    break;
                case 'index.html':
                    uiType = 'classic';
                    break;
                default:
                    uiType = 'simple';
            }

            // 通过background script切换UI
            if (chrome.runtime && chrome.runtime.sendMessage) {
                const response = await chrome.runtime.sendMessage({
                    action: 'switchUI',
                    uiType: uiType
                });

                if (response && response.success) {
                    this.showSuccess(response.message || '界面切换成功');

                    // 延迟关闭popup，让用户看到成功消息
                    setTimeout(() => {
                        window.close();
                    }, 1000);
                } else {
                    throw new Error(response?.message || '切换失败');
                }
            } else {
                throw new Error('Chrome API不可用');
            }
        } catch (error) {
            console.error('切换UI失败:', error);
            this.showError('切换界面失败: ' + error.message);
        }
    }
}

// 初始化 - 多种方式确保加载
function initializeUI() {
    try {
        console.log('开始初始化SimplePopupUI...');
        new SimplePopupUI();
    } catch (error) {
        console.error('SimplePopupUI初始化失败:', error);
        // 显示错误信息
        document.body.innerHTML = `
            <div style="padding: 20px; text-align: center; color: red;">
                <h3>❌ 界面初始化失败</h3>
                <p>${error.message}</p>
                <button onclick="location.reload()" style="padding: 10px 20px; margin-top: 10px;">重新加载</button>
            </div>
        `;
    }
}

// 多种初始化方式
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeUI);
} else {
    // DOM已经加载完成
    initializeUI();
}

// 备用初始化
setTimeout(() => {
    if (!window.simplePopupInitialized) {
        console.warn('备用初始化触发');
        initializeUI();
    }
}, 100);

// 错误处理
window.addEventListener('error', (e) => {
    console.error('页面错误:', e.error);
});

// 标记初始化状态
window.simplePopupInitialized = false;
