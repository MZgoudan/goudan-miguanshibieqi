/**
 * 狗蛋蜜罐识别器 - UI选择器脚本
 */

class UISelector {
    constructor() {
        this.selectedUI = 'quick'; // 默认选择快速配置
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadSavedPreference();
    }

    setupEventListeners() {
        // UI选项点击
        document.querySelectorAll('.ui-option').forEach(option => {
            option.addEventListener('click', () => {
                this.selectUI(option.dataset.ui);
            });
        });

        // 按钮事件
        document.getElementById('confirmBtn')?.addEventListener('click', () => {
            this.confirmSelection();
        });

        document.getElementById('cancelBtn')?.addEventListener('click', () => {
            window.close();
        });
    }

    selectUI(uiType) {
        // 更新选中状态
        document.querySelectorAll('.ui-option').forEach(option => {
            option.classList.toggle('selected', option.dataset.ui === uiType);
        });

        this.selectedUI = uiType;
        console.log('选择UI:', uiType);
    }

    async loadSavedPreference() {
        try {
            if (chrome.storage && chrome.storage.local) {
                const result = await chrome.storage.local.get(['preferredUI']);
                if (result.preferredUI) {
                    this.selectUI(result.preferredUI);
                    console.log('加载保存的UI偏好:', result.preferredUI);
                }
            }
        } catch (error) {
            console.warn('加载UI偏好失败:', error);
        }
    }

    async confirmSelection() {
        try {
            console.log('确认选择UI:', this.selectedUI);

            // 保存用户偏好
            if (chrome.storage && chrome.storage.local) {
                await chrome.storage.local.set({ preferredUI: this.selectedUI });
                console.log('UI偏好已保存');
            }

            // 根据选择打开对应界面
            let url;
            switch (this.selectedUI) {
                case 'modern':
                    url = 'modern-ui.html';
                    break;
                case 'quick':
                    url = 'quick-config.html';
                    break;
                case 'classic':
                    url = 'index.html';
                    break;
                default:
                    url = 'quick-config.html';
            }

            console.log('准备打开URL:', url);

            // 检查Chrome API可用性
            if (chrome.tabs && chrome.runtime) {
                // 在新标签页中打开选择的界面
                chrome.tabs.create({
                    url: chrome.runtime.getURL(`resource/popup/${url}`)
                }, (tab) => {
                    if (chrome.runtime.lastError) {
                        console.error('打开标签页失败:', chrome.runtime.lastError);
                        this.showError('打开界面失败，请重试');
                    } else {
                        console.log('成功打开标签页:', tab.id);
                        // 关闭当前弹窗
                        window.close();
                    }
                });
            } else {
                throw new Error('Chrome API不可用');
            }

        } catch (error) {
            console.error('确认选择失败:', error);
            this.showError('操作失败: ' + error.message);
        }
    }

    showError(message) {
        // 创建错误提示
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = `
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: #f8d7da;
            color: #721c24;
            padding: 10px 15px;
            border-radius: 4px;
            border: 1px solid #f5c6cb;
            z-index: 1000;
            font-size: 12px;
        `;
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);

        // 3秒后自动移除
        setTimeout(() => {
            if (document.body.contains(errorDiv)) {
                document.body.removeChild(errorDiv);
            }
        }, 3000);
    }

    showSuccess(message) {
        // 创建成功提示
        const successDiv = document.createElement('div');
        successDiv.style.cssText = `
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: #d4edda;
            color: #155724;
            padding: 10px 15px;
            border-radius: 4px;
            border: 1px solid #c3e6cb;
            z-index: 1000;
            font-size: 12px;
        `;
        successDiv.textContent = message;
        document.body.appendChild(successDiv);

        // 2秒后自动移除
        setTimeout(() => {
            if (document.body.contains(successDiv)) {
                document.body.removeChild(successDiv);
            }
        }, 2000);
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('UI选择器页面已加载');
    try {
        new UISelector();
    } catch (error) {
        console.error('UI选择器初始化失败:', error);
    }
});

// 错误处理
window.addEventListener('error', (event) => {
    console.error('UI选择器页面错误:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('UI选择器未处理的Promise拒绝:', event.reason);
});
