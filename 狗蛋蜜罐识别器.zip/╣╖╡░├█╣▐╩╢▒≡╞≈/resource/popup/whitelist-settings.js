/**
 * 狗蛋蜜罐识别器 - 黑白名单设置界面
 * 作者: 蜜汁狗蛋
 * 版本: 1.0
 */

'use strict';

let whitelistManager;
let currentTab = 'whitelist';

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', async function() {
    console.log('🛡️ 黑白名单设置页面加载完成');
    
    // 等待whitelistManager初始化
    await waitForWhitelistManager();
    
    // 初始化界面
    await initializeUI();
    
    // 获取当前网站信息
    await getCurrentSiteInfo();
    
    console.log('✅ 黑白名单设置界面初始化完成');
});

// 等待whitelistManager初始化
async function waitForWhitelistManager() {
    let attempts = 0;
    while (!window.whitelistManager && attempts < 50) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
    }
    
    if (window.whitelistManager) {
        whitelistManager = window.whitelistManager;
        console.log('✅ WhitelistManager已连接');
    } else {
        console.error('❌ 无法连接到WhitelistManager');
    }
}

// 初始化界面
async function initializeUI() {
    await updateStats();
    await refreshAllLists();
}

// 切换标签页
function switchTab(tabName) {
    // 隐藏所有标签内容
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // 移除所有标签的active类
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // 显示选中的标签内容
    document.getElementById(tabName).classList.add('active');
    
    // 激活选中的标签
    event.target.classList.add('active');
    
    currentTab = tabName;
    
    // 如果切换到当前网站标签，更新信息
    if (tabName === 'current') {
        getCurrentSiteInfo();
    }
}

// 更新统计信息
async function updateStats() {
    if (!whitelistManager) return;
    
    try {
        const lists = whitelistManager.getAllLists();
        
        document.getElementById('whitelistCount').textContent = lists.whitelist.length;
        document.getElementById('blacklistCount').textContent = lists.blacklist.length;
        document.getElementById('domainWhitelistCount').textContent = lists.domainWhitelist.length;
        document.getElementById('domainBlacklistCount').textContent = lists.domainBlacklist.length;
        
    } catch (error) {
        console.error('❌ 更新统计信息失败:', error);
    }
}

// 刷新所有列表
async function refreshAllLists() {
    await refreshWhitelist();
    await refreshBlacklist();
}

// 刷新白名单显示
async function refreshWhitelist() {
    if (!whitelistManager) return;
    
    try {
        const lists = whitelistManager.getAllLists();
        const container = document.getElementById('whitelistContainer');
        
        // 合并所有白名单类型
        const allWhitelist = [
            ...lists.whitelist.map(item => ({ value: item, type: 'URL' })),
            ...lists.domainWhitelist.map(item => ({ value: item, type: '域名' })),
            ...lists.keywordWhitelist.map(item => ({ value: item, type: '关键词' }))
        ];
        
        if (allWhitelist.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div>📝</div>
                    <p>暂无白名单条目</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = allWhitelist.map(item => `
            <div class="list-item">
                <div class="list-item-text">
                    <strong>[${item.type}]</strong> ${item.value}
                </div>
                <div class="list-item-actions">
                    <button class="btn btn-danger btn-small" onclick="removeFromWhitelist('${item.value}', '${item.type.toLowerCase()}')">删除</button>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('❌ 刷新白名单失败:', error);
    }
}

// 刷新黑名单显示
async function refreshBlacklist() {
    if (!whitelistManager) return;
    
    try {
        const lists = whitelistManager.getAllLists();
        const container = document.getElementById('blacklistContainer');
        
        // 合并所有黑名单类型
        const allBlacklist = [
            ...lists.blacklist.map(item => ({ value: item, type: 'URL' })),
            ...lists.domainBlacklist.map(item => ({ value: item, type: '域名' })),
            ...lists.keywordBlacklist.map(item => ({ value: item, type: '关键词' }))
        ];
        
        if (allBlacklist.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div>📝</div>
                    <p>暂无黑名单条目</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = allBlacklist.map(item => `
            <div class="list-item">
                <div class="list-item-text">
                    <strong>[${item.type}]</strong> ${item.value}
                </div>
                <div class="list-item-actions">
                    <button class="btn btn-danger btn-small" onclick="removeFromBlacklist('${item.value}', '${item.type.toLowerCase()}')">删除</button>
                </div>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('❌ 刷新黑名单失败:', error);
    }
}

// 添加到白名单
async function addToWhitelist() {
    const input = document.getElementById('whitelistInput');
    const typeSelect = document.getElementById('whitelistType');
    const alert = document.getElementById('whitelistAlert');
    
    const value = input.value.trim();
    const type = typeSelect.value;
    
    if (!value) {
        showAlert(alert, '请输入要添加的内容', 'danger');
        return;
    }
    
    if (!whitelistManager) {
        showAlert(alert, 'WhitelistManager未初始化', 'danger');
        return;
    }
    
    try {
        const success = await whitelistManager.addToWhitelist(value, type);
        
        if (success) {
            showAlert(alert, `已添加到白名单: ${value}`, 'success');
            input.value = '';
            await updateStats();
            await refreshWhitelist();
        } else {
            showAlert(alert, '添加失败', 'danger');
        }
        
    } catch (error) {
        console.error('❌ 添加白名单失败:', error);
        showAlert(alert, '添加失败: ' + error.message, 'danger');
    }
}

// 添加到黑名单
async function addToBlacklist() {
    const input = document.getElementById('blacklistInput');
    const typeSelect = document.getElementById('blacklistType');
    const alert = document.getElementById('blacklistAlert');
    
    const value = input.value.trim();
    const type = typeSelect.value;
    
    if (!value) {
        showAlert(alert, '请输入要添加的内容', 'danger');
        return;
    }
    
    if (!whitelistManager) {
        showAlert(alert, 'WhitelistManager未初始化', 'danger');
        return;
    }
    
    try {
        const success = await whitelistManager.addToBlacklist(value, type);
        
        if (success) {
            showAlert(alert, `已添加到黑名单: ${value}`, 'success');
            input.value = '';
            await updateStats();
            await refreshBlacklist();
        } else {
            showAlert(alert, '添加失败', 'danger');
        }
        
    } catch (error) {
        console.error('❌ 添加黑名单失败:', error);
        showAlert(alert, '添加失败: ' + error.message, 'danger');
    }
}

// 从白名单移除
async function removeFromWhitelist(value, type) {
    if (!whitelistManager) return;
    
    try {
        // 转换类型名称
        const typeMap = { 'url': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'url';
        
        const success = await whitelistManager.removeFromWhitelist(value, actualType);
        
        if (success) {
            await updateStats();
            await refreshWhitelist();
        }
        
    } catch (error) {
        console.error('❌ 移除白名单失败:', error);
    }
}

// 从黑名单移除
async function removeFromBlacklist(value, type) {
    if (!whitelistManager) return;
    
    try {
        // 转换类型名称
        const typeMap = { 'url': 'url', '域名': 'domain', '关键词': 'keyword' };
        const actualType = typeMap[type] || 'url';
        
        const success = await whitelistManager.removeFromBlacklist(value, actualType);
        
        if (success) {
            await updateStats();
            await refreshBlacklist();
        }
        
    } catch (error) {
        console.error('❌ 移除黑名单失败:', error);
    }
}

// 显示提示信息
function showAlert(alertElement, message, type = 'success') {
    alertElement.className = `alert alert-${type}`;
    alertElement.textContent = message;
    alertElement.style.display = 'block';
    
    setTimeout(() => {
        alertElement.style.display = 'none';
    }, 3000);
}

// 导出白名单
function exportWhitelist() {
    if (!whitelistManager) return;
    
    try {
        const lists = whitelistManager.getAllLists();
        const exportData = {
            whitelist: lists.whitelist,
            domainWhitelist: lists.domainWhitelist,
            keywordWhitelist: lists.keywordWhitelist,
            exportTime: new Date().toISOString(),
            version: '1.0'
        };
        
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `whitelist-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
    } catch (error) {
        console.error('❌ 导出白名单失败:', error);
    }
}

// 导出黑名单
function exportBlacklist() {
    if (!whitelistManager) return;
    
    try {
        const lists = whitelistManager.getAllLists();
        const exportData = {
            blacklist: lists.blacklist,
            domainBlacklist: lists.domainBlacklist,
            keywordBlacklist: lists.keywordBlacklist,
            exportTime: new Date().toISOString(),
            version: '1.0'
        };
        
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `blacklist-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
    } catch (error) {
        console.error('❌ 导出黑名单失败:', error);
    }
}

// 显示导入白名单界面
function showImportWhitelist() {
    document.getElementById('importWhitelistContainer').style.display = 'block';
}

// 隐藏导入白名单界面
function hideImportWhitelist() {
    document.getElementById('importWhitelistContainer').style.display = 'none';
    document.getElementById('importWhitelistText').value = '';
}

// 导入白名单
async function importWhitelist() {
    const textarea = document.getElementById('importWhitelistText');
    const typeSelect = document.getElementById('importWhitelistType');
    
    const text = textarea.value.trim();
    const type = typeSelect.value;
    
    if (!text) {
        alert('请输入要导入的内容');
        return;
    }
    
    if (!whitelistManager) {
        alert('WhitelistManager未初始化');
        return;
    }
    
    try {
        const items = text.split('\n').filter(item => item.trim());
        
        for (let item of items) {
            await whitelistManager.addToWhitelist(item.trim(), type);
        }
        
        alert(`成功导入 ${items.length} 个白名单条目`);
        hideImportWhitelist();
        await updateStats();
        await refreshWhitelist();
        
    } catch (error) {
        console.error('❌ 导入白名单失败:', error);
        alert('导入失败: ' + error.message);
    }
}

// 显示导入黑名单界面
function showImportBlacklist() {
    document.getElementById('importBlacklistContainer').style.display = 'block';
}

// 隐藏导入黑名单界面
function hideImportBlacklist() {
    document.getElementById('importBlacklistContainer').style.display = 'none';
    document.getElementById('importBlacklistText').value = '';
}

// 导入黑名单
async function importBlacklist() {
    const textarea = document.getElementById('importBlacklistText');
    const typeSelect = document.getElementById('importBlacklistType');
    
    const text = textarea.value.trim();
    const type = typeSelect.value;
    
    if (!text) {
        alert('请输入要导入的内容');
        return;
    }
    
    if (!whitelistManager) {
        alert('WhitelistManager未初始化');
        return;
    }
    
    try {
        const items = text.split('\n').filter(item => item.trim());
        
        for (let item of items) {
            await whitelistManager.addToBlacklist(item.trim(), type);
        }
        
        alert(`成功导入 ${items.length} 个黑名单条目`);
        hideImportBlacklist();
        await updateStats();
        await refreshBlacklist();
        
    } catch (error) {
        console.error('❌ 导入黑名单失败:', error);
        alert('导入失败: ' + error.message);
    }
}

// 清空白名单
async function clearWhitelist() {
    if (!confirm('确定要清空所有白名单吗？此操作不可恢复！')) {
        return;
    }
    
    if (!whitelistManager) return;
    
    try {
        await whitelistManager.clearList('whitelist');
        await whitelistManager.clearList('domainWhitelist');
        await whitelistManager.clearList('keywordWhitelist');
        
        await updateStats();
        await refreshWhitelist();
        
        alert('白名单已清空');
        
    } catch (error) {
        console.error('❌ 清空白名单失败:', error);
        alert('清空失败: ' + error.message);
    }
}

// 清空黑名单
async function clearBlacklist() {
    if (!confirm('确定要清空所有黑名单吗？此操作不可恢复！')) {
        return;
    }
    
    if (!whitelistManager) return;
    
    try {
        await whitelistManager.clearList('blacklist');
        await whitelistManager.clearList('domainBlacklist');
        await whitelistManager.clearList('keywordBlacklist');
        
        await updateStats();
        await refreshBlacklist();
        
        alert('黑名单已清空');
        
    } catch (error) {
        console.error('❌ 清空黑名单失败:', error);
        alert('清空失败: ' + error.message);
    }
}

// 获取当前网站信息
async function getCurrentSiteInfo() {
    try {
        // 尝试从chrome.tabs获取当前标签页信息
        if (chrome && chrome.tabs) {
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
                if (tabs[0]) {
                    const url = tabs[0].url;
                    const domain = new URL(url).hostname;
                    
                    document.getElementById('currentUrl').textContent = url;
                    document.getElementById('currentDomain').textContent = domain;
                    
                    // 检查当前网站状态
                    checkCurrentSiteStatus(url);
                }
            });
        } else {
            document.getElementById('currentUrl').textContent = '无法获取当前网站信息';
            document.getElementById('currentDomain').textContent = '-';
            document.getElementById('currentStatus').textContent = '需要在网页中使用';
        }
    } catch (error) {
        console.warn('⚠️ 获取当前网站信息失败:', error);
    }
}

// 检查当前网站状态
async function checkCurrentSiteStatus(url) {
    if (!whitelistManager) return;
    
    try {
        const whitelistCheck = whitelistManager.isWhitelisted(url);
        const blacklistCheck = whitelistManager.isBlacklisted(url);
        
        let status = '未知';
        if (whitelistCheck.isWhitelisted) {
            status = '✅ 在白名单中';
        } else if (blacklistCheck.isBlacklisted) {
            status = '🚫 在黑名单中';
        } else {
            status = '⚪ 未设置';
        }
        
        document.getElementById('currentStatus').textContent = status;
        
    } catch (error) {
        console.warn('⚠️ 检查网站状态失败:', error);
    }
}

// 添加当前网站到白名单
async function addCurrentToWhitelist(type) {
    const url = document.getElementById('currentUrl').textContent;
    const domain = document.getElementById('currentDomain').textContent;
    
    if (url === '请在网页中打开扩展' || url === '无法获取当前网站信息') {
        alert('无法获取当前网站信息');
        return;
    }
    
    if (!whitelistManager) {
        alert('WhitelistManager未初始化');
        return;
    }
    
    try {
        const value = type === 'domain' ? domain : url;
        const success = await whitelistManager.addToWhitelist(value, type);
        
        if (success) {
            alert(`已添加到白名单: ${value}`);
            await updateStats();
            await refreshWhitelist();
            await checkCurrentSiteStatus(url);
        } else {
            alert('添加失败');
        }
        
    } catch (error) {
        console.error('❌ 添加当前网站到白名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}

// 添加当前网站到黑名单
async function addCurrentToBlacklist(type) {
    const url = document.getElementById('currentUrl').textContent;
    const domain = document.getElementById('currentDomain').textContent;
    
    if (url === '请在网页中打开扩展' || url === '无法获取当前网站信息') {
        alert('无法获取当前网站信息');
        return;
    }
    
    if (!whitelistManager) {
        alert('WhitelistManager未初始化');
        return;
    }
    
    try {
        const value = type === 'domain' ? domain : url;
        const success = await whitelistManager.addToBlacklist(value, type);
        
        if (success) {
            alert(`已添加到黑名单: ${value}`);
            await updateStats();
            await refreshBlacklist();
            await checkCurrentSiteStatus(url);
        } else {
            alert('添加失败');
        }
        
    } catch (error) {
        console.error('❌ 添加当前网站到黑名单失败:', error);
        alert('添加失败: ' + error.message);
    }
}
