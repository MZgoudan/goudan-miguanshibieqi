/**
 * Service Worker专用的Chrome Privacy API修复脚本
 * 专门为Service Worker环境设计，不使用window对象
 */

console.log('🔧 Service Worker Chrome Privacy API修复脚本开始执行...');

// Service Worker环境中立即创建chrome.privacy.network，防止任何访问错误
(function() {
    'use strict';
    
    try {
        // 确保chrome对象存在
        if (typeof chrome === 'undefined') {
            console.warn('Service Worker中chrome对象不存在，跳过修复');
            return;
        }
        
        // 如果chrome.privacy不存在，立即创建
        if (!chrome.privacy) {
            chrome.privacy = {};
            console.log('✅ Service Worker中创建chrome.privacy');
        }
        
        // 如果chrome.privacy.network不存在，立即创建
        if (!chrome.privacy.network) {
            chrome.privacy.network = {};
            console.log('✅ Service Worker中创建chrome.privacy.network');
        }
        
        // 如果webRTCIPHandlingPolicy不存在，立即创建
        if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
            chrome.privacy.network.webRTCIPHandlingPolicy = {
                get: function(details, callback) {
                    console.log('🔧 Service Worker chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（修复代理）');
                    if (callback && typeof callback === 'function') {
                        // 异步返回默认值
                        setTimeout(() => {
                            try {
                                callback({ value: 'default' });
                            } catch (error) {
                                console.warn('Service Worker Privacy API callback执行失败:', error);
                            }
                        }, 0);
                    }
                },
                set: function(details, callback) {
                    console.log('🔧 Service Worker chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（修复代理）');
                    if (callback && typeof callback === 'function') {
                        // 异步确认设置
                        setTimeout(() => {
                            try {
                                callback();
                            } catch (error) {
                                console.warn('Service Worker Privacy API set callback执行失败:', error);
                            }
                        }, 0);
                    }
                }
            };
            console.log('✅ Service Worker中创建chrome.privacy.network.webRTCIPHandlingPolicy');
        }
        
        console.log('✅ Service Worker Chrome Privacy API修复完成');
        
    } catch (error) {
        console.error('❌ Service Worker Chrome Privacy API修复失败:', error);
        
        // 最后的紧急修复
        try {
            if (typeof chrome !== 'undefined') {
                chrome.privacy = chrome.privacy || {};
                chrome.privacy.network = chrome.privacy.network || {};
                chrome.privacy.network.webRTCIPHandlingPolicy = chrome.privacy.network.webRTCIPHandlingPolicy || {
                    get: function(details, callback) {
                        if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                    },
                    set: function(details, callback) {
                        if (callback) setTimeout(callback, 0);
                    }
                };
                console.log('✅ Service Worker紧急修复完成');
            }
        } catch (finalError) {
            console.error('❌ Service Worker最终修复也失败了:', finalError);
        }
    }
    
})();

// Service Worker专用的错误处理
// 注意：Service Worker中没有window对象，使用self代替
if (typeof self !== 'undefined') {
    // Service Worker错误处理
    self.addEventListener('error', function(event) {
        const message = event.message || (event.error && event.error.message);
        if (message && message.includes("Cannot read properties of undefined (reading 'network')")) {
            console.error('🚨 Service Worker中捕获到network访问错误:', {
                message: message,
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno
            });
            
            // 紧急修复
            try {
                if (typeof chrome !== 'undefined') {
                    if (!chrome.privacy) chrome.privacy = {};
                    if (!chrome.privacy.network) chrome.privacy.network = {};
                    if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
                        chrome.privacy.network.webRTCIPHandlingPolicy = {
                            get: function(details, callback) {
                                if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                            },
                            set: function(details, callback) {
                                if (callback) setTimeout(callback, 0);
                            }
                        };
                    }
                    console.log('🔧 Service Worker错误处理中紧急修复chrome.privacy.network完成');
                }
            } catch (error) {
                console.error('Service Worker错误处理中紧急修复失败:', error);
            }
        }
    });
    
    // Service Worker中的Promise错误处理
    self.addEventListener('unhandledrejection', function(event) {
        const reason = event.reason;
        if (reason && reason.message && reason.message.includes("Cannot read properties of undefined (reading 'network')")) {
            console.error('🚨 Service Worker Promise中捕获到network访问错误:', reason);
            
            // 紧急修复
            try {
                if (typeof chrome !== 'undefined') {
                    if (!chrome.privacy) chrome.privacy = {};
                    if (!chrome.privacy.network) chrome.privacy.network = {};
                    if (!chrome.privacy.network.webRTCIPHandlingPolicy) {
                        chrome.privacy.network.webRTCIPHandlingPolicy = {
                            get: function(details, callback) {
                                if (callback) setTimeout(() => callback({ value: 'default' }), 0);
                            },
                            set: function(details, callback) {
                                if (callback) setTimeout(callback, 0);
                            }
                        };
                    }
                    console.log('🔧 Service Worker Promise错误处理中紧急修复chrome.privacy.network完成');
                }
            } catch (error) {
                console.error('Service Worker Promise错误处理中紧急修复失败:', error);
            }
            
            // 阻止错误显示
            event.preventDefault();
        }
    });
}

console.log('✅ Service Worker Chrome Privacy API修复脚本加载完成');
