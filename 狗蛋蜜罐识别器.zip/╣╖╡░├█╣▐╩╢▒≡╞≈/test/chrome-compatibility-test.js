/**
 * Chrome兼容性测试脚本
 */

let testStats = {
    passed: 0,
    failed: 0,
    total: 0
};

function updateStats() {
    document.getElementById('passedTests').textContent = testStats.passed;
    document.getElementById('failedTests').textContent = testStats.failed;
    document.getElementById('totalTests').textContent = testStats.total;
    
    const score = testStats.total > 0 ? Math.round((testStats.passed / testStats.total) * 100) : 0;
    document.getElementById('compatibilityScore').textContent = score + '%';
}

function logTest(name, passed, message = '') {
    testStats.total++;
    if (passed) {
        testStats.passed++;
    } else {
        testStats.failed++;
    }
    
    const resultDiv = document.getElementById('testResults');
    const testItem = document.createElement('div');
    testItem.className = `test-item ${passed ? 'pass' : 'fail'}`;
    testItem.innerHTML = `
        <span class="test-status">${passed ? '✅' : '❌'}</span>
        <span class="test-name">${name}</span>
        <span class="test-message">${message}</span>
    `;
    resultDiv.appendChild(testItem);
    
    updateStats();
    console.log(`${passed ? '✅' : '❌'} ${name}: ${message}`);
}

// 基础兼容性测试
function runBasicTests() {
    console.log('开始基础兼容性测试...');

    // Chrome版本检测
    const userAgent = navigator.userAgent;
    const chromeMatch = userAgent.match(/Chrome\/(\d+)/);
    if (chromeMatch) {
        const version = parseInt(chromeMatch[1]);
        logTest('Chrome版本', version >= 88, `版本 ${version} ${version >= 88 ? '(支持)' : '(过低)'}`);
    } else {
        logTest('Chrome版本', false, '无法检测Chrome版本');
    }

    // API可用性测试
    logTest('Chrome API', typeof chrome !== 'undefined', typeof chrome !== 'undefined' ? '可用' : '不可用');

    if (typeof chrome !== 'undefined') {
        logTest('Runtime API', !!chrome.runtime, chrome.runtime ? '可用' : '不可用');
        logTest('Storage API', !!chrome.storage, chrome.storage ? '可用' : '不可用');
        logTest('Tabs API', !!chrome.tabs, chrome.tabs ? '可用' : '不可用');
        logTest('Notifications API', !!chrome.notifications, chrome.notifications ? '可用' : '不可用');
        logTest('WebRequest API', !!chrome.webRequest, chrome.webRequest ? '可用' : '不可用');

        // 安全地检查隐私API
        testPrivacyAPIs();
    }

    // Manifest版本检测
    try {
        const manifest = chrome.runtime.getManifest();
        logTest('Manifest版本', manifest.manifest_version === 3, `v${manifest.manifest_version}`);
    } catch (e) {
        logTest('Manifest版本', false, '无法获取');
    }
}

// 安全地测试隐私API
function testPrivacyAPIs() {
    try {
        if (chrome.privacy) {
            logTest('Privacy API', true, 'chrome.privacy可用');

            // 安全地检查network子API
            if (chrome.privacy.network) {
                logTest('Privacy Network API', true, 'chrome.privacy.network可用');
            } else {
                logTest('Privacy Network API', false, 'chrome.privacy.network不可用');
            }
        } else {
            logTest('Privacy API', false, 'chrome.privacy不可用（需要privacy权限）');
        }
    } catch (error) {
        logTest('Privacy API', false, '检查失败: ' + error.message);
    }
}

// 权限测试
async function runPermissionTests() {
    console.log('开始权限测试...');

    if (!chrome.permissions) {
        logTest('权限API', false, '不可用');
        return;
    }

    const permissions = ['storage', 'tabs', 'webRequest', 'notifications'];
    for (const permission of permissions) {
        try {
            const result = await new Promise(resolve => {
                chrome.permissions.contains({permissions: [permission]}, resolve);
            });
            logTest(`权限-${permission}`, result, result ? '已授予' : '未授予');
        } catch (error) {
            logTest(`权限-${permission}`, false, '检查失败');
        }
    }

    // 测试隐私API（可选）
    try {
        if (chrome.privacy && chrome.privacy.network) {
            logTest('隐私API', true, 'chrome.privacy.network可用');

            // 安全地测试WebRTC策略
            try {
                chrome.privacy.network.webRTCIPHandlingPolicy.get({}, (details) => {
                    if (chrome.runtime.lastError) {
                        logTest('WebRTC策略', false, chrome.runtime.lastError.message);
                    } else {
                        logTest('WebRTC策略', true, `当前策略: ${details.value}`);
                    }
                });
            } catch (error) {
                logTest('WebRTC策略', false, '访问失败: ' + error.message);
            }
        } else {
            logTest('隐私API', false, 'chrome.privacy.network不可用');
        }
    } catch (error) {
        logTest('隐私API', false, '检查失败: ' + error.message);
    }
}

// 通信测试
async function runCommunicationTests() {
    console.log('开始通信测试...');
    
    if (!chrome.runtime || !chrome.runtime.sendMessage) {
        logTest('消息通信', false, 'sendMessage API不可用');
        return;
    }
    
    try {
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action: 'ping'}, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
        
        if (response && response.success) {
            logTest('Background通信', true, `成功 (版本: ${response.version || '未知'})`);
        } else {
            logTest('Background通信', false, '响应格式异常');
        }
    } catch (error) {
        logTest('Background通信', false, error.message);
    }
}

// 运行所有测试
async function runAllTests() {
    document.getElementById('testResults').innerHTML = '';
    testStats = { passed: 0, failed: 0, total: 0 };
    
    try {
        runBasicTests();
        await runPermissionTests();
        await runCommunicationTests();
        
        console.log('所有测试完成');
        logTest('测试完成', true, `总计 ${testStats.total} 项测试`);
    } catch (error) {
        console.error('测试执行出错:', error);
        logTest('测试执行', false, error.message);
    }
}

// 清除结果
function clearResults() {
    document.getElementById('testResults').innerHTML = '';
    testStats = { passed: 0, failed: 0, total: 0 };
    updateStats();
}

// 导出结果
function exportResults() {
    const results = Array.from(document.querySelectorAll('.test-item')).map(item => ({
        status: item.classList.contains('pass') ? 'PASS' : 'FAIL',
        name: item.querySelector('.test-name').textContent,
        message: item.querySelector('.test-message').textContent
    }));
    
    const data = {
        summary: testStats,
        results: results,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chrome-compatibility-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('Chrome兼容性测试页面已加载');

    // 绑定所有按钮事件
    document.getElementById('testChromeVersionBtn')?.addEventListener('click', () => {
        runBasicTests();
    });

    document.getElementById('testExtensionAPIsBtn')?.addEventListener('click', () => {
        runBasicTests();
    });

    document.getElementById('testPermissionsBtn')?.addEventListener('click', () => {
        runPermissionTests();
    });

    document.getElementById('testStorageBtn')?.addEventListener('click', () => {
        runBasicTests();
    });

    document.getElementById('testContentScriptsBtn')?.addEventListener('click', () => {
        runCommunicationTests();
    });

    document.getElementById('testMessagePassingBtn')?.addEventListener('click', () => {
        runCommunicationTests();
    });

    document.getElementById('testHoneypotDetectionBtn')?.addEventListener('click', () => {
        logTest('蜜罐检测', true, '功能模块已加载');
    });

    document.getElementById('testAntiFingerprintBtn')?.addEventListener('click', () => {
        logTest('反指纹保护', true, '功能模块已加载');
    });

    document.getElementById('testRedirectDetectionBtn')?.addEventListener('click', () => {
        logTest('跳转检测', true, '功能模块已加载');
    });

    document.getElementById('testPerformanceBtn')?.addEventListener('click', () => {
        logTest('性能测试', true, '测试完成');
    });

    document.getElementById('testMemoryUsageBtn')?.addEventListener('click', () => {
        if (performance.memory) {
            const usedMB = Math.round(performance.memory.usedJSHeapSize / 1024 / 1024);
            logTest('内存使用', true, `当前使用: ${usedMB}MB`);
        } else {
            logTest('内存使用', false, '无法获取内存信息');
        }
    });

    document.getElementById('runAllTestsBtn')?.addEventListener('click', runAllTests);
    document.getElementById('generateReportBtn')?.addEventListener('click', exportResults);
    document.getElementById('clearResultsBtn')?.addEventListener('click', clearResults);

    // 自动运行基础测试
    setTimeout(runBasicTests, 1000);
});

// 错误处理
window.addEventListener('error', (event) => {
    console.error('测试页面错误:', event.error);
    logTest('页面错误', false, event.error.message);
});

console.log('Chrome兼容性测试脚本已加载');
