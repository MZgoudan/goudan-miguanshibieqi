/**
 * 错误修复脚本 - 专门处理常见的JavaScript错误
 */

console.log('错误修复脚本已加载');

// 全局错误捕获和修复
(function() {
    'use strict';
    
    // 1. 修复navigator.connection相关错误
    function fixNavigatorConnectionErrors() {
        // 如果navigator.connection不存在，创建一个安全的代理
        if (typeof navigator !== 'undefined' && !navigator.connection) {
            console.log('创建navigator.connection安全代理');
            
            // 创建一个安全的connection对象
            Object.defineProperty(navigator, 'connection', {
                value: {
                    effectiveType: '4g',
                    downlink: 10,
                    rtt: 50,
                    saveData: false
                },
                writable: false,
                configurable: false
            });
        }
    }
    
    // 2. 修复chrome.privacy.network相关错误
    function fixChromePrivacyErrors() {
        if (typeof chrome !== 'undefined' && !chrome.privacy) {
            console.log('创建chrome.privacy安全代理');
            
            chrome.privacy = {
                network: {
                    webRTCIPHandlingPolicy: {
                        get: function(details, callback) {
                            console.log('chrome.privacy.network.webRTCIPHandlingPolicy.get被调用（代理）');
                            if (callback) {
                                setTimeout(() => {
                                    callback({ value: 'default' });
                                }, 0);
                            }
                        },
                        set: function(details, callback) {
                            console.log('chrome.privacy.network.webRTCIPHandlingPolicy.set被调用（代理）');
                            if (callback) {
                                setTimeout(callback, 0);
                            }
                        }
                    }
                }
            };
        }
    }
    
    // 3. 修复undefined属性访问错误
    function fixUndefinedPropertyErrors() {
        // 重写Object.prototype的属性访问，添加安全检查
        const originalGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
        
        // 不建议修改Object.prototype，这里只是示例
        // 实际应该在具体的代码中添加检查
    }
    
    // 4. 全局错误处理器
    function setupGlobalErrorHandlers() {
        // 捕获未处理的错误
        window.addEventListener('error', function(event) {
            const error = event.error;
            const message = event.message;
            
            console.warn('捕获到全局错误:', {
                message: message,
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno,
                error: error
            });
            
            // 特定错误的修复
            if (message && message.includes("Cannot read properties of undefined (reading 'network')")) {
                console.log('检测到network属性访问错误，尝试修复...');
                fixNavigatorConnectionErrors();
                fixChromePrivacyErrors();
            }
            
            // 阻止错误冒泡到控制台（可选）
            // event.preventDefault();
        });
        
        // 捕获未处理的Promise拒绝
        window.addEventListener('unhandledrejection', function(event) {
            console.warn('捕获到未处理的Promise拒绝:', event.reason);
            
            // 阻止错误显示在控制台（可选）
            // event.preventDefault();
        });
    }
    
    // 5. API安全包装器
    function createSafeAPIWrappers() {
        // 安全的chrome API调用包装器
        window.safeChromeCall = function(apiPath, method, ...args) {
            try {
                const api = apiPath.split('.').reduce((obj, key) => obj && obj[key], chrome);
                if (api && typeof api[method] === 'function') {
                    return api[method](...args);
                } else {
                    console.warn(`Chrome API不可用: ${apiPath}.${method}`);
                    return null;
                }
            } catch (error) {
                console.warn(`Chrome API调用失败: ${apiPath}.${method}`, error);
                return null;
            }
        };
        
        // 安全的属性访问包装器
        window.safePropertyAccess = function(obj, path, defaultValue = null) {
            try {
                return path.split('.').reduce((current, key) => {
                    return current && current[key] !== undefined ? current[key] : defaultValue;
                }, obj);
            } catch (error) {
                console.warn(`属性访问失败: ${path}`, error);
                return defaultValue;
            }
        };
    }
    
    // 6. 初始化所有修复
    function initializeErrorFixes() {
        console.log('初始化错误修复...');
        
        try {
            fixNavigatorConnectionErrors();
            fixChromePrivacyErrors();
            setupGlobalErrorHandlers();
            createSafeAPIWrappers();
            
            console.log('错误修复初始化完成');
        } catch (error) {
            console.error('错误修复初始化失败:', error);
        }
    }
    
    // 页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeErrorFixes);
    } else {
        initializeErrorFixes();
    }
    
    // 立即执行一些关键修复
    fixNavigatorConnectionErrors();
    fixChromePrivacyErrors();
    
})();

// 导出一些有用的函数供其他脚本使用
if (typeof window !== 'undefined') {
    window.ErrorFix = {
        fixNavigatorConnection: function() {
            if (typeof navigator !== 'undefined' && !navigator.connection) {
                Object.defineProperty(navigator, 'connection', {
                    value: {
                        effectiveType: '4g',
                        downlink: 10,
                        rtt: 50,
                        saveData: false
                    },
                    writable: false,
                    configurable: false
                });
                console.log('navigator.connection已修复');
            }
        },
        
        safeAccess: function(obj, path, defaultValue = null) {
            try {
                return path.split('.').reduce((current, key) => {
                    return current && current[key] !== undefined ? current[key] : defaultValue;
                }, obj);
            } catch (error) {
                return defaultValue;
            }
        }
    };
}

console.log('错误修复脚本加载完成');
