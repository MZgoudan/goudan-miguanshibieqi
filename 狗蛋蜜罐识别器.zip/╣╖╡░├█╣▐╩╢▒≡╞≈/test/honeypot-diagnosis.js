/**
 * 狗蛋蜜罐识别器 - 诊断工具脚本
 * 用于检查扩展运行状态和检测功能
 */

'use strict';

let diagnosticLogs = [];

function addLog(level, message) {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = { timestamp, level, message };
    diagnosticLogs.push(logEntry);
    
    console.log(`[${level.toUpperCase()}] ${message}`);
    
    const logSection = document.getElementById('logSection');
    if (logSection) {
        const logDiv = document.createElement('div');
        logDiv.className = 'log-entry';
        logDiv.innerHTML = `
            <span class="log-time">[${timestamp}]</span>
            <span class="log-level-${level}">${message}</span>
        `;
        logSection.appendChild(logDiv);
        logSection.scrollTop = logSection.scrollHeight;
    }
}

function updateStatus(elementId, status, className) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = status;
        element.className = `status-value ${className}`;
    }
}

// 完整诊断
async function runFullDiagnostic() {
    addLog('info', '开始完整诊断...');
    
    // 1. 检查Chrome扩展API
    checkChromeAPI();
    
    // 2. 检查Service Worker
    await checkServiceWorker();
    
    // 3. 检查Content Scripts
    checkContentScripts();
    
    // 4. 检查规则数据库
    checkRulesDatabase();
    
    // 5. 检查白名单管理器
    await checkWhitelistManager();
    
    // 6. 检查检测引擎
    checkDetectionEngine();
    
    // 7. 更新详细信息
    updateDetailedInfo();
    
    addLog('success', '完整诊断完成');
}

function checkChromeAPI() {
    try {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
            updateStatus('chromeApiStatus', '正常', 'status-ok');
            addLog('success', 'Chrome扩展API可用');
            
            // 检查扩展ID
            if (chrome.runtime.id) {
                addLog('info', `扩展ID: ${chrome.runtime.id}`);
            }
        } else {
            updateStatus('chromeApiStatus', '不可用', 'status-error');
            addLog('error', 'Chrome扩展API不可用');
        }
    } catch (error) {
        updateStatus('chromeApiStatus', '错误', 'status-error');
        addLog('error', `Chrome API检查失败: ${error.message}`);
    }
}

async function checkServiceWorker() {
    try {
        if (chrome.runtime && chrome.runtime.sendMessage) {
            const response = await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(response);
                    }
                });
            });
            
            if (response && response.success) {
                updateStatus('serviceWorkerStatus', '正常', 'status-ok');
                addLog('success', `Service Worker响应: ${response.message}`);
            } else {
                updateStatus('serviceWorkerStatus', '异常', 'status-warning');
                addLog('warn', 'Service Worker响应异常');
            }
        } else {
            updateStatus('serviceWorkerStatus', '不可用', 'status-error');
            addLog('error', 'Service Worker通信不可用');
        }
    } catch (error) {
        updateStatus('serviceWorkerStatus', '错误', 'status-error');
        addLog('error', `Service Worker检查失败: ${error.message}`);
    }
}

function checkContentScripts() {
    try {
        // 检查是否有Content Script注入的全局变量
        const indicators = [
            'printerData',
            'LatestHoneypotRules2024', 
            'whitelistManager',
            'fingerprintDefenseManager'
        ];
        
        let foundCount = 0;
        const foundItems = [];
        
        indicators.forEach(indicator => {
            if (typeof window[indicator] !== 'undefined') {
                foundCount++;
                foundItems.push(indicator);
                addLog('success', `找到Content Script组件: ${indicator}`);
            } else {
                addLog('warn', `未找到Content Script组件: ${indicator}`);
            }
        });
        
        if (foundCount > 0) {
            updateStatus('contentScriptStatus', `${foundCount}/${indicators.length}`, 'status-warning');
            addLog('info', `Content Scripts部分加载: ${foundItems.join(', ')}`);
        } else {
            updateStatus('contentScriptStatus', '未加载', 'status-error');
            addLog('error', 'Content Scripts未正确加载');
        }
        
    } catch (error) {
        updateStatus('contentScriptStatus', '错误', 'status-error');
        addLog('error', `Content Scripts检查失败: ${error.message}`);
    }
}

function checkRulesDatabase() {
    try {
        let totalRules = 0;
        let rulesSources = [];
        
        // 检查主规则数据库
        if (typeof printerData !== 'undefined' && Array.isArray(printerData)) {
            const honeypotRules = printerData.filter(rule => rule.type === 3);
            totalRules += honeypotRules.length;
            rulesSources.push(`主数据库: ${honeypotRules.length}条蜜罐规则`);
            addLog('success', `主规则数据库已加载: ${printerData.length}条总规则, ${honeypotRules.length}条蜜罐规则`);
        } else {
            addLog('error', '主规则数据库(printerData)未加载');
        }
        
        // 检查2024最新规则
        if (typeof LatestHoneypotRules2024 !== 'undefined' && Array.isArray(LatestHoneypotRules2024)) {
            totalRules += LatestHoneypotRules2024.length;
            rulesSources.push(`2024规则: ${LatestHoneypotRules2024.length}条`);
            addLog('success', `2024最新规则已加载: ${LatestHoneypotRules2024.length}条`);
        } else {
            addLog('error', '2024最新规则(LatestHoneypotRules2024)未加载');
        }
        
        if (totalRules > 0) {
            updateStatus('rulesStatus', `${totalRules}条规则`, 'status-ok');
            addLog('success', `规则数据库总计: ${totalRules}条规则`);
        } else {
            updateStatus('rulesStatus', '未加载', 'status-error');
            addLog('error', '规则数据库完全未加载');
        }
        
        // 更新详细统计
        document.getElementById('rulesStats').textContent = rulesSources.join('\n') || '无规则加载';
        
    } catch (error) {
        updateStatus('rulesStatus', '错误', 'status-error');
        addLog('error', `规则数据库检查失败: ${error.message}`);
    }
}

async function checkWhitelistManager() {
    try {
        // 等待白名单管理器加载
        let attempts = 0;
        while (!window.whitelistManager && attempts < 30) {
            await new Promise(resolve => setTimeout(resolve, 100));
            attempts++;
        }
        
        if (window.whitelistManager) {
            updateStatus('whitelistStatus', '正常', 'status-ok');
            addLog('success', '白名单管理器已加载');
            
            // 检查白名单管理器功能
            try {
                const testUrl = 'https://www.baidu.com';
                const result = window.whitelistManager.isWhitelisted(testUrl);
                addLog('info', `白名单测试: ${testUrl} -> ${result.isWhitelisted ? '在白名单中' : '不在白名单中'}`);
                
                // 获取统计信息
                const stats = window.whitelistManager.getStats();
                document.getElementById('whitelistStats').textContent = 
                    `白名单: ${stats.whitelistCount}个\n` +
                    `黑名单: ${stats.blacklistCount}个\n` +
                    `域名白名单: ${stats.domainWhitelistCount}个\n` +
                    `域名黑名单: ${stats.domainBlacklistCount}个`;
                    
            } catch (error) {
                addLog('warn', `白名单管理器功能测试失败: ${error.message}`);
            }
        } else {
            updateStatus('whitelistStatus', '未加载', 'status-error');
            addLog('error', '白名单管理器未加载');
            document.getElementById('whitelistStats').textContent = '白名单管理器未加载';
        }
        
    } catch (error) {
        updateStatus('whitelistStatus', '错误', 'status-error');
        addLog('error', `白名单管理器检查失败: ${error.message}`);
    }
}

function checkDetectionEngine() {
    try {
        // 检查检测函数是否存在
        const detectionFunctions = [
            'performHoneypotDetection',
            'detectHoneypotByRules',
            'detectHFishHoneypot',
            'detectMoanHoneypot',
            'detectAdvancedHoneypotFeatures'
        ];
        
        let foundFunctions = 0;
        const foundList = [];
        
        detectionFunctions.forEach(funcName => {
            if (typeof window[funcName] === 'function') {
                foundFunctions++;
                foundList.push(funcName);
                addLog('success', `检测函数可用: ${funcName}`);
            } else {
                addLog('warn', `检测函数不可用: ${funcName}`);
            }
        });
        
        if (foundFunctions > 0) {
            updateStatus('detectionEngineStatus', `${foundFunctions}/${detectionFunctions.length}`, 'status-warning');
            addLog('info', `检测引擎部分可用: ${foundList.join(', ')}`);
        } else {
            updateStatus('detectionEngineStatus', '不可用', 'status-error');
            addLog('error', '检测引擎完全不可用');
        }
        
    } catch (error) {
        updateStatus('detectionEngineStatus', '错误', 'status-error');
        addLog('error', `检测引擎检查失败: ${error.message}`);
    }
}

function updateDetailedInfo() {
    // 更新当前URL和页面标题
    document.getElementById('currentUrl').textContent = window.location.href;
    document.getElementById('pageTitle').textContent = document.title;
}

// 测试HFish检测
function testHFishDetection() {
    addLog('info', '开始测试HFish检测...');
    
    try {
        // 添加HFish测试特征
        window.sec_key = "test_hfish_key_12345";
        window.login_field = "username";
        window.user_login = "admin";
        
        addLog('info', '已添加HFish测试特征');
        
        // 尝试调用检测函数
        if (typeof window.detectHFishHoneypot === 'function') {
            const result = window.detectHFishHoneypot();
            if (result && result.length > 0) {
                addLog('success', `HFish检测成功: 发现${result.length}个特征`);
                result.forEach((detection, index) => {
                    addLog('info', `特征${index + 1}: ${detection.type} - ${detection.evidence}`);
                });
            } else {
                addLog('warn', 'HFish检测未发现特征（可能是正常的）');
            }
        } else {
            addLog('error', 'HFish检测函数不可用');
        }
        
        // 清理测试特征
        delete window.sec_key;
        delete window.login_field;
        delete window.user_login;
        addLog('info', '已清理HFish测试特征');
        
    } catch (error) {
        addLog('error', `HFish检测测试失败: ${error.message}`);
    }
}

// 测试规则引擎
function testRulesEngine() {
    addLog('info', '开始测试规则引擎...');
    
    try {
        if (typeof window.detectHoneypotByRules === 'function') {
            const result = window.detectHoneypotByRules();
            if (result && result.length > 0) {
                addLog('success', `规则引擎检测成功: 发现${result.length}个匹配`);
                result.forEach((detection, index) => {
                    addLog('info', `规则${index + 1}: ${detection.type} - ${detection.evidence}`);
                });
            } else {
                addLog('info', '规则引擎未发现匹配（正常）');
            }
        } else {
            addLog('error', '规则引擎检测函数不可用');
        }
    } catch (error) {
        addLog('error', `规则引擎测试失败: ${error.message}`);
    }
}

// 强制重载
function forceReload() {
    addLog('info', '强制重载页面...');
    setTimeout(() => {
        window.location.reload();
    }, 1000);
}

// 清除日志
function clearLogs() {
    diagnosticLogs = [];
    const logSection = document.getElementById('logSection');
    if (logSection) {
        logSection.innerHTML = '<div class="log-entry"><span class="log-time">[已清除]</span><span class="log-level-info">日志已清除</span></div>';
    }
}

// 页面加载时开始诊断
window.addEventListener('load', function() {
    addLog('info', '诊断工具已启动');
    setTimeout(runFullDiagnostic, 1000);
});

// 监听扩展消息
if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        addLog('info', `收到扩展消息: ${request.action}`);
        return true;
    });
}

// 监听页面消息
window.addEventListener('message', function(event) {
    if (event.data && event.data.msgType) {
        addLog('info', `收到页面消息: ${event.data.msgType}`);
    }
});

// 检查全局变量
function checkGlobalVariables() {
    const globalVars = [
        'printerData',
        'LatestHoneypotRules2024',
        'LatestFingerprintRules2024',
        'whitelistManager',
        'fingerprintDefenseManager',
        'HConfig'
    ];
    
    addLog('info', '检查全局变量...');
    
    globalVars.forEach(varName => {
        if (typeof window[varName] !== 'undefined') {
            const type = typeof window[varName];
            const value = Array.isArray(window[varName]) ? `Array(${window[varName].length})` : type;
            addLog('success', `全局变量 ${varName}: ${value}`);
        } else {
            addLog('warn', `全局变量 ${varName}: 未定义`);
        }
    });
}

// 检查脚本加载
function checkScriptLoading() {
    addLog('info', '检查脚本加载状态...');
    
    const scripts = document.querySelectorAll('script[src]');
    addLog('info', `页面共有 ${scripts.length} 个外部脚本`);
    
    scripts.forEach((script, index) => {
        const src = script.src;
        if (src.includes('chrome-extension://')) {
            addLog('info', `扩展脚本 ${index + 1}: ${src.split('/').pop()}`);
        }
    });
}

// 添加额外的诊断功能
window.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        checkGlobalVariables();
        checkScriptLoading();
    }, 2000);
});
