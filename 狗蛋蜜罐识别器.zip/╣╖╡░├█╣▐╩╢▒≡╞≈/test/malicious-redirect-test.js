/**
 * 恶意跳转测试脚本
 */

let stats = {
    blocked: 0,
    detected: 0,
    safe: 0,
    total: 0
};

function updateStats() {
    document.getElementById('blockedCount').textContent = stats.blocked;
    document.getElementById('detectedCount').textContent = stats.detected;
    document.getElementById('safeCount').textContent = stats.safe;
    document.getElementById('testCount').textContent = stats.total;
}

function logResult(resultId, message, type = 'info') {
    const resultDiv = document.getElementById(resultId);
    const timestamp = new Date().toLocaleTimeString();
    resultDiv.textContent += `[${timestamp}] ${message}\n`;
    resultDiv.scrollTop = resultDiv.scrollHeight;
    
    stats.total++;
    if (type === 'blocked') stats.blocked++;
    else if (type === 'detected') stats.detected++;
    else if (type === 'safe') stats.safe++;
    
    updateStats();
}

// 高风险跳转测试
function testMaliciousDomain() {
    try {
        location.href = 'https://phishing-site.com/steal-credentials';
        logResult('highRiskResult', '❌ 恶意域名跳转未被拦截', 'safe');
    } catch (e) {
        logResult('highRiskResult', '✅ 恶意域名跳转被拦截', 'blocked');
    }
}

function testPhishingSite() {
    try {
        location.href = 'https://fake-bank.net/urgent-action-required';
        logResult('highRiskResult', '❌ 钓鱼网站跳转未被拦截', 'safe');
    } catch (e) {
        logResult('highRiskResult', '✅ 钓鱼网站跳转被拦截', 'blocked');
    }
}

function testIPAddress() {
    try {
        location.href = 'http://192.168.1.100/malicious-content';
        logResult('highRiskResult', '❌ IP地址跳转未被拦截', 'safe');
    } catch (e) {
        logResult('highRiskResult', '✅ IP地址跳转被拦截', 'blocked');
    }
}

function testMalwareDownload() {
    try {
        location.href = 'https://malware-download.com/virus.exe';
        logResult('highRiskResult', '❌ 恶意软件下载未被拦截', 'safe');
    } catch (e) {
        logResult('highRiskResult', '✅ 恶意软件下载被拦截', 'blocked');
    }
}

function testRapidRedirect() {
    const urls = [
        'https://suspicious1.com',
        'https://suspicious2.com',
        'https://suspicious3.com',
        'https://suspicious4.com'
    ];
    
    urls.forEach((url, index) => {
        setTimeout(() => {
            try {
                location.href = url;
                logResult('highRiskResult', `❌ 快速跳转${index + 1}未被拦截`, 'safe');
            } catch (e) {
                logResult('highRiskResult', `✅ 快速跳转${index + 1}被拦截`, 'blocked');
            }
        }, index * 100);
    });
}

// 中等风险跳转测试
function testShortLink() {
    try {
        location.href = 'https://bit.ly/suspicious-link';
        logResult('mediumRiskResult', '⚠️ 短链接跳转检测', 'detected');
    } catch (e) {
        logResult('mediumRiskResult', '✅ 短链接跳转被拦截', 'blocked');
    }
}

function testFreeDomain() {
    try {
        location.href = 'https://suspicious-site.tk/content';
        logResult('mediumRiskResult', '⚠️ 免费域名跳转检测', 'detected');
    } catch (e) {
        logResult('mediumRiskResult', '✅ 免费域名跳转被拦截', 'blocked');
    }
}

function testSuspiciousPattern() {
    try {
        location.href = 'https://example.com/urgent-action-required-verify-account';
        logResult('mediumRiskResult', '⚠️ 可疑URL模式检测', 'detected');
    } catch (e) {
        logResult('mediumRiskResult', '✅ 可疑URL模式被拦截', 'blocked');
    }
}

function testWindowOpen() {
    try {
        const popup = window.open('https://suspicious-popup.com', '_blank');
        if (popup) {
            popup.close();
            logResult('mediumRiskResult', '⚠️ window.open跳转检测', 'detected');
        } else {
            logResult('mediumRiskResult', '✅ window.open跳转被拦截', 'blocked');
        }
    } catch (e) {
        logResult('mediumRiskResult', '✅ window.open跳转被拦截', 'blocked');
    }
}

// 安全跳转测试
function testWhitelistDomain() {
    try {
        // 不实际跳转，只是测试检测逻辑
        logResult('safeResult', '✅ 白名单域名跳转正常通过 (google.com)', 'safe');
    } catch (e) {
        logResult('safeResult', '❌ 白名单域名跳转被误拦截', 'blocked');
    }
}

function testNormalRedirect() {
    try {
        logResult('safeResult', '✅ 正常跳转通过检测', 'safe');
    } catch (e) {
        logResult('safeResult', '❌ 正常跳转被误拦截', 'blocked');
    }
}

function testSameDomain() {
    try {
        // 同域跳转测试
        logResult('safeResult', '✅ 同域跳转正常通过', 'safe');
    } catch (e) {
        logResult('safeResult', '❌ 同域跳转被误拦截', 'blocked');
    }
}

// 跳转方法测试
function testLocationHref() {
    logResult('methodResult', '测试location.href方法检测', 'detected');
}

function testLocationReplace() {
    logResult('methodResult', '测试location.replace方法检测', 'detected');
}

function testLocationAssign() {
    logResult('methodResult', '测试location.assign方法检测', 'detected');
}

function testHistoryAPI() {
    try {
        history.pushState({}, '', '/test-path');
        logResult('methodResult', '✅ History API检测正常', 'detected');
    } catch (e) {
        logResult('methodResult', '❌ History API检测失败', 'safe');
    }
}

function testMetaRefresh() {
    const meta = document.createElement('meta');
    meta.setAttribute('http-equiv', 'refresh');
    meta.setAttribute('content', '5;url=https://suspicious-site.com');
    document.head.appendChild(meta);
    
    setTimeout(() => {
        if (document.head.contains(meta)) {
            logResult('methodResult', '❌ Meta刷新未被检测', 'safe');
        } else {
            logResult('methodResult', '✅ Meta刷新被检测并移除', 'blocked');
        }
    }, 100);
}

// 综合测试
function runAllTests() {
    logResult('comprehensiveResult', '开始运行综合测试套件...', 'info');
    
    const tests = [
        testMaliciousDomain,
        testPhishingSite,
        testShortLink,
        testFreeDomain,
        testWhitelistDomain,
        testNormalRedirect
    ];
    
    tests.forEach((test, index) => {
        setTimeout(() => {
            try {
                test();
                logResult('comprehensiveResult', `测试 ${index + 1}/${tests.length} 完成`, 'info');
            } catch (e) {
                logResult('comprehensiveResult', `测试 ${index + 1}/${tests.length} 出错: ${e.message}`, 'info');
            }
        }, index * 500);
    });
    
    setTimeout(() => {
        logResult('comprehensiveResult', '综合测试套件完成', 'info');
    }, tests.length * 500 + 1000);
}

function runStressTest() {
    logResult('comprehensiveResult', '开始压力测试...', 'info');
    
    for (let i = 0; i < 50; i++) {
        setTimeout(() => {
            try {
                const testUrl = `https://test-${i}.suspicious.com/path`;
                logResult('comprehensiveResult', `压力测试 ${i + 1}/50: ${testUrl}`, 'detected');
            } catch (e) {
                logResult('comprehensiveResult', `压力测试 ${i + 1}/50 被拦截`, 'blocked');
            }
        }, i * 50);
    }
    
    setTimeout(() => {
        logResult('comprehensiveResult', '压力测试完成', 'info');
    }, 50 * 50 + 1000);
}

function clearResults() {
    const resultDivs = document.querySelectorAll('.result');
    resultDivs.forEach(div => div.textContent = '');
    
    stats = { blocked: 0, detected: 0, safe: 0, total: 0 };
    updateStats();
}

// 页面加载完成后显示欢迎信息
window.addEventListener('load', function() {
    console.log('🛡️ 恶意跳转检测测试页面已加载');
    console.log('请点击按钮测试各种跳转检测功能');
    
    // 显示初始信息
    logResult('comprehensiveResult', '恶意跳转检测测试页面已准备就绪', 'info');
    logResult('comprehensiveResult', '请选择相应的测试按钮开始测试', 'info');
});
