/**
 * Service Worker紧急检查脚本
 */

console.log('Service Worker紧急检查脚本已加载');

class ServiceWorkerEmergencyChecker {
    constructor() {
        this.logs = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.startStatusCheck();
        this.log('紧急检查器初始化完成');
    }

    bindEvents() {
        document.getElementById('checkStatusBtn')?.addEventListener('click', () => {
            this.checkStatus();
        });

        document.getElementById('testMessageBtn')?.addEventListener('click', () => {
            this.testMessageCommunication();
        });

        document.getElementById('forceReloadBtn')?.addEventListener('click', () => {
            this.forceReloadExtension();
        });

        document.getElementById('runBasicTestsBtn')?.addEventListener('click', () => {
            this.runBasicTests();
        });

        document.getElementById('testUISwitch')?.addEventListener('click', () => {
            this.testUISwitch();
        });

        document.getElementById('testDetectionBtn')?.addEventListener('click', () => {
            this.testDetection();
        });

        document.getElementById('clearLogBtn')?.addEventListener('click', () => {
            this.clearLog();
        });

        document.getElementById('exportLogBtn')?.addEventListener('click', () => {
            this.exportLog();
        });
    }

    async checkStatus() {
        this.log('🔍 开始检查Service Worker状态...');
        
        try {
            // 检查Chrome API
            if (typeof chrome === 'undefined') {
                this.showStatus('❌ Chrome API不可用', 'error');
                return;
            }

            // 检查runtime API
            if (!chrome.runtime) {
                this.showStatus('❌ Chrome Runtime API不可用', 'error');
                return;
            }

            // 尝试ping Service Worker
            const response = await this.sendMessage({ action: 'ping' });
            
            if (response && response.success) {
                this.showStatus(`✅ Service Worker运行正常 (v${response.version})`, 'ok');
                this.log(`✅ Ping成功: ${response.message}`);
            } else {
                this.showStatus('❌ Service Worker无响应', 'error');
                this.log('❌ Ping失败: 无响应');
            }

        } catch (error) {
            this.showStatus(`❌ 检查失败: ${error.message}`, 'error');
            this.log(`❌ 状态检查错误: ${error.message}`);
        }
    }

    async testMessageCommunication() {
        this.log('📨 测试消息通信...');
        
        try {
            const tests = [
                { action: 'ping', name: 'Ping测试' },
                { action: 'getConfig', name: '配置获取测试' },
                { action: 'getStats', name: '统计获取测试' }
            ];

            for (const test of tests) {
                try {
                    const response = await this.sendMessage(test);
                    if (response && response.success) {
                        this.addTestResult(`✅ ${test.name}: 成功`, 'pass');
                        this.log(`✅ ${test.name}: ${JSON.stringify(response)}`);
                    } else {
                        this.addTestResult(`❌ ${test.name}: 失败`, 'fail');
                        this.log(`❌ ${test.name}: ${JSON.stringify(response)}`);
                    }
                } catch (error) {
                    this.addTestResult(`❌ ${test.name}: 错误 - ${error.message}`, 'fail');
                    this.log(`❌ ${test.name}错误: ${error.message}`);
                }
            }

        } catch (error) {
            this.log(`❌ 消息通信测试失败: ${error.message}`);
        }
    }

    async testUISwitch() {
        this.log('🎨 测试UI切换功能...');
        
        try {
            const response = await this.sendMessage({
                action: 'switchUI',
                uiType: 'quick'
            });

            if (response && response.success) {
                this.addTestResult(`✅ UI切换测试: ${response.message}`, 'pass');
                this.log(`✅ UI切换成功: ${response.message}`);
            } else {
                this.addTestResult(`❌ UI切换测试: ${response?.message || '失败'}`, 'fail');
                this.log(`❌ UI切换失败: ${JSON.stringify(response)}`);
            }

        } catch (error) {
            this.addTestResult(`❌ UI切换测试: 错误 - ${error.message}`, 'fail');
            this.log(`❌ UI切换测试错误: ${error.message}`);
        }
    }

    async testDetection() {
        this.log('🛡️ 测试检测功能...');
        
        try {
            // 这里只是测试配置获取，实际检测在background中进行
            const response = await this.sendMessage({ action: 'getConfig' });
            
            if (response && response.success && response.config) {
                const config = response.config;
                this.addTestResult(`✅ 检测配置: 启用=${config.enabled}, 黑名单=${config.blackListCount}个`, 'pass');
                this.log(`✅ 检测配置: ${JSON.stringify(config)}`);
            } else {
                this.addTestResult('❌ 检测配置获取失败', 'fail');
                this.log('❌ 检测配置获取失败');
            }

        } catch (error) {
            this.addTestResult(`❌ 检测功能测试: 错误 - ${error.message}`, 'fail');
            this.log(`❌ 检测功能测试错误: ${error.message}`);
        }
    }

    async runBasicTests() {
        this.log('🧪 运行基础测试套件...');
        this.clearTestResults();
        
        // 依次运行所有测试
        await this.testMessageCommunication();
        await this.testUISwitch();
        await this.testDetection();
        
        this.log('✅ 基础测试套件完成');
    }

    forceReloadExtension() {
        this.log('🔄 尝试强制重新加载插件...');
        
        try {
            if (chrome.runtime && chrome.runtime.reload) {
                chrome.runtime.reload();
                this.log('✅ 重新加载命令已发送');
            } else {
                this.log('❌ 无法访问reload API');
                alert('请手动在扩展管理页面点击"重新加载"按钮');
            }
        } catch (error) {
            this.log(`❌ 强制重新加载失败: ${error.message}`);
            alert('请手动在扩展管理页面点击"重新加载"按钮');
        }
    }

    async sendMessage(message) {
        return new Promise((resolve, reject) => {
            if (!chrome.runtime || !chrome.runtime.sendMessage) {
                reject(new Error('Chrome runtime API不可用'));
                return;
            }

            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
    }

    showStatus(message, type = 'info') {
        const statusDisplay = document.getElementById('statusDisplay');
        if (statusDisplay) {
            statusDisplay.innerHTML = `<div class="status-${type}">${message}</div>`;
        }
    }

    addTestResult(message, type = 'info') {
        const testResults = document.getElementById('testResults');
        if (testResults) {
            const div = document.createElement('div');
            div.className = `test-result test-${type}`;
            div.textContent = message;
            testResults.appendChild(div);
        }
    }

    clearTestResults() {
        const testResults = document.getElementById('testResults');
        if (testResults) {
            testResults.innerHTML = '';
        }
    }

    log(message) {
        const timestamp = new Date().toLocaleTimeString();
        const logMessage = `[${timestamp}] ${message}`;
        this.logs.push(logMessage);
        
        const logDisplay = document.getElementById('logDisplay');
        if (logDisplay) {
            logDisplay.textContent = this.logs.slice(-50).join('\n'); // 只显示最近50条
            logDisplay.scrollTop = logDisplay.scrollHeight;
        }
        
        console.log(logMessage);
    }

    clearLog() {
        this.logs = [];
        const logDisplay = document.getElementById('logDisplay');
        if (logDisplay) {
            logDisplay.textContent = '日志已清除';
        }
    }

    exportLog() {
        const logContent = this.logs.join('\n');
        const blob = new Blob([logContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `service-worker-emergency-log-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.log('📄 日志已导出');
    }

    startStatusCheck() {
        // 立即检查一次
        this.checkStatus();
        
        // 每30秒自动检查一次
        setInterval(() => {
            this.checkStatus();
        }, 30000);
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    new ServiceWorkerEmergencyChecker();
});

// 错误处理
window.addEventListener('error', (e) => {
    console.error('页面错误:', e.error);
});
