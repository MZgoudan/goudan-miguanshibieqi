/**
 * 简单状态检查脚本
 */

// 运行基本检查
function runBasicCheck() {
    console.log('开始基本检查...');
    
    // 检查Chrome API
    checkChromeAPI();
    
    // 检查Service Worker
    checkServiceWorker();
    
    showResult('基本检查完成', 'success');
}

// 检查Chrome API
function checkChromeAPI() {
    const element = document.getElementById('chromeApi');
    
    if (typeof chrome !== 'undefined' && chrome.runtime) {
        element.textContent = '可用';
        element.className = 'status-value status-ok';
        console.log('Chrome API检查: 通过');
    } else {
        element.textContent = '不可用';
        element.className = 'status-value status-error';
        console.log('Chrome API检查: 失败');
    }
}

// 检查Service Worker
async function checkServiceWorker() {
    const element = document.getElementById('serviceWorker');
    
    try {
        if ('serviceWorker' in navigator) {
            const registration = await navigator.serviceWorker.getRegistration();
            
            if (registration) {
                const worker = registration.active || registration.installing || registration.waiting;
                if (worker && worker.state === 'activated') {
                    element.textContent = '正在运行';
                    element.className = 'status-value status-ok';
                    console.log('Service Worker检查: 通过');
                } else {
                    element.textContent = '未激活';
                    element.className = 'status-value status-warning';
                    console.log('Service Worker检查: 警告 - 未激活');
                }
            } else {
                element.textContent = '未注册';
                element.className = 'status-value status-error';
                console.log('Service Worker检查: 失败 - 未注册');
            }
        } else {
            element.textContent = '不支持';
            element.className = 'status-value status-error';
            console.log('Service Worker检查: 失败 - 不支持');
        }
    } catch (error) {
        element.textContent = '检查失败';
        element.className = 'status-value status-error';
        console.error('Service Worker检查失败:', error);
    }
}

// 测试通信
async function testCommunication() {
    const element = document.getElementById('communication');
    
    try {
        if (!chrome.runtime) {
            throw new Error('Chrome Runtime API不可用');
        }
        
        // 发送ping消息
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response);
                }
            });
        });
        
        if (response && response.success) {
            element.textContent = '成功';
            element.className = 'status-value status-ok';
            showResult(`通信测试成功！版本: ${response.version || '未知'}`, 'success');
            console.log('通信测试: 通过', response);
        } else {
            throw new Error('响应无效');
        }
        
    } catch (error) {
        element.textContent = '失败';
        element.className = 'status-value status-error';
        showResult(`通信测试失败: ${error.message}`, 'error');
        console.error('通信测试失败:', error);
    }
}

// 显示结果
function showResult(message, type) {
    const resultsDiv = document.getElementById('results');
    const timestamp = new Date().toLocaleTimeString();
    
    const resultClass = type === 'success' ? 'result success' : 
                       type === 'error' ? 'result error' : 'result';
    
    const resultHTML = `
        <div class="${resultClass}">
            <strong>[${timestamp}]</strong> ${message}
        </div>
    `;
    
    resultsDiv.innerHTML = resultHTML + resultsDiv.innerHTML;
}

// 页面加载时自动运行基本检查
document.addEventListener('DOMContentLoaded', () => {
    console.log('简单状态检查工具已加载');

    // 绑定按钮事件
    document.getElementById('basicCheckBtn')?.addEventListener('click', runBasicCheck);
    document.getElementById('communicationBtn')?.addEventListener('click', testCommunication);

    // 延迟1秒后自动运行基本检查
    setTimeout(() => {
        runBasicCheck();
    }, 1000);
});

// 错误处理
window.addEventListener('error', (event) => {
    console.error('页面错误:', event.error);
    showResult(`页面错误: ${event.error.message}`, 'error');
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('未处理的Promise拒绝:', event.reason);
    showResult(`Promise拒绝: ${event.reason}`, 'error');
});
