/**
 * 狗蛋蜜罐识别器 - 测试通用库
 * 提供测试页面的通用功能和工具
 */

// 通用测试工具类
class TestUtils {
    constructor() {
        this.results = [];
        this.stats = {
            total: 0,
            passed: 0,
            failed: 0,
            warnings: 0
        };
    }

    // 记录测试结果
    logResult(name, status, message = '', details = null) {
        const timestamp = new Date().toLocaleTimeString();
        const result = {
            name,
            status, // 'pass', 'fail', 'warning', 'info'
            message,
            details,
            timestamp
        };
        
        this.results.push(result);
        this.updateStats(status);
        
        // 输出到控制台
        const emoji = this.getStatusEmoji(status);
        console.log(`${emoji} [${timestamp}] ${name}: ${message}`);
        
        return result;
    }

    // 更新统计
    updateStats(status) {
        this.stats.total++;
        switch (status) {
            case 'pass':
                this.stats.passed++;
                break;
            case 'fail':
                this.stats.failed++;
                break;
            case 'warning':
                this.stats.warnings++;
                break;
        }
    }

    // 获取状态表情符号
    getStatusEmoji(status) {
        const emojis = {
            'pass': '✅',
            'fail': '❌',
            'warning': '⚠️',
            'info': 'ℹ️'
        };
        return emojis[status] || '📝';
    }

    // 显示结果到页面
    displayResults(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        let html = `
            <div class="test-summary">
                <h3>测试摘要</h3>
                <p>总计: ${this.stats.total} | 通过: ${this.stats.passed} | 失败: ${this.stats.failed} | 警告: ${this.stats.warnings}</p>
            </div>
            <div class="test-results">
        `;

        this.results.forEach(result => {
            const statusClass = `status-${result.status}`;
            html += `
                <div class="test-item ${statusClass}">
                    <span class="test-emoji">${this.getStatusEmoji(result.status)}</span>
                    <span class="test-name">${result.name}</span>
                    <span class="test-message">${result.message}</span>
                    <span class="test-time">${result.timestamp}</span>
                </div>
            `;
        });

        html += '</div>';
        container.innerHTML = html;
    }

    // 清除结果
    clearResults() {
        this.results = [];
        this.stats = { total: 0, passed: 0, failed: 0, warnings: 0 };
    }

    // 导出结果
    exportResults() {
        const data = {
            summary: this.stats,
            results: this.results,
            timestamp: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `test-results-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }
}

// Chrome API 测试工具
class ChromeAPITester {
    constructor() {
        this.utils = new TestUtils();
    }

    // 测试基础API可用性
    testBasicAPIs() {
        this.utils.logResult('Chrome对象', typeof chrome !== 'undefined' ? 'pass' : 'fail', 
            typeof chrome !== 'undefined' ? 'Chrome API可用' : 'Chrome API不可用');

        if (typeof chrome !== 'undefined') {
            const apis = ['runtime', 'storage', 'tabs', 'notifications', 'webRequest'];
            apis.forEach(api => {
                this.utils.logResult(`chrome.${api}`, chrome[api] ? 'pass' : 'fail',
                    chrome[api] ? '可用' : '不可用');
            });
        }
    }

    // 测试权限
    async testPermissions() {
        if (!chrome.permissions) {
            this.utils.logResult('权限API', 'fail', 'chrome.permissions不可用');
            return;
        }

        const permissions = ['storage', 'tabs', 'webRequest', 'notifications'];
        for (const permission of permissions) {
            try {
                const result = await new Promise(resolve => {
                    chrome.permissions.contains({permissions: [permission]}, resolve);
                });
                this.utils.logResult(`权限-${permission}`, result ? 'pass' : 'warning',
                    result ? '已授予' : '未授予');
            } catch (error) {
                this.utils.logResult(`权限-${permission}`, 'fail', `检查失败: ${error.message}`);
            }
        }
    }

    // 测试通信
    async testCommunication() {
        if (!chrome.runtime || !chrome.runtime.sendMessage) {
            this.utils.logResult('通信测试', 'fail', 'sendMessage API不可用');
            return;
        }

        try {
            const response = await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({action: 'ping'}, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(response);
                    }
                });
            });

            if (response && response.success) {
                this.utils.logResult('通信测试', 'pass', `成功，版本: ${response.version || '未知'}`);
            } else {
                this.utils.logResult('通信测试', 'warning', '响应格式异常');
            }
        } catch (error) {
            this.utils.logResult('通信测试', 'fail', error.message);
        }
    }

    // 运行所有测试
    async runAllTests() {
        this.utils.clearResults();
        this.utils.logResult('测试开始', 'info', '开始Chrome API兼容性测试');
        
        this.testBasicAPIs();
        await this.testPermissions();
        await this.testCommunication();
        
        this.utils.logResult('测试完成', 'info', '所有测试已完成');
        return this.utils;
    }
}

// 页面工具函数
const PageUtils = {
    // 显示消息
    showMessage(message, type = 'info', duration = 3000) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${type}`;
        messageDiv.textContent = message;
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 4px;
            color: white;
            font-weight: 600;
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
        `;

        const colors = {
            'info': '#17a2b8',
            'success': '#28a745',
            'warning': '#ffc107',
            'error': '#dc3545'
        };
        messageDiv.style.backgroundColor = colors[type] || colors.info;

        document.body.appendChild(messageDiv);

        setTimeout(() => {
            messageDiv.style.animation = 'slideOut 0.3s ease-in';
            setTimeout(() => {
                if (document.body.contains(messageDiv)) {
                    document.body.removeChild(messageDiv);
                }
            }, 300);
        }, duration);
    },

    // 添加CSS动画
    addAnimationCSS() {
        if (document.getElementById('test-animations')) return;

        const style = document.createElement('style');
        style.id = 'test-animations';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            .test-summary {
                background: #f8f9fa;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
                border-left: 4px solid #007bff;
            }
            .test-item {
                display: flex;
                align-items: center;
                padding: 8px 12px;
                margin-bottom: 4px;
                border-radius: 4px;
                font-family: monospace;
                font-size: 12px;
            }
            .test-item.status-pass { background: #d4edda; }
            .test-item.status-fail { background: #f8d7da; }
            .test-item.status-warning { background: #fff3cd; }
            .test-item.status-info { background: #d1ecf1; }
            .test-emoji { margin-right: 8px; }
            .test-name { font-weight: 600; margin-right: 12px; min-width: 150px; }
            .test-message { flex: 1; }
            .test-time { font-size: 10px; color: #666; margin-left: 12px; }
        `;
        document.head.appendChild(style);
    }
};

// 全局错误处理
window.addEventListener('error', (event) => {
    console.error('页面错误:', event.error);
    PageUtils.showMessage(`页面错误: ${event.error.message}`, 'error');
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('未处理的Promise拒绝:', event.reason);
    PageUtils.showMessage(`Promise错误: ${event.reason}`, 'error');
});

// 导出到全局
if (typeof window !== 'undefined') {
    window.TestUtils = TestUtils;
    window.ChromeAPITester = ChromeAPITester;
    window.PageUtils = PageUtils;
}

console.log('测试通用库已加载');
