/**
 * 测试页面占位脚本
 * 用于替换内联脚本，避免CSP错误
 */

console.log('测试页面脚本已加载');

// 基础页面初始化
document.addEventListener('DOMContentLoaded', () => {
    console.log('测试页面DOM已加载');

    // 绑定通用按钮事件
    document.getElementById('startCheckBtn')?.addEventListener('click', () => {
        alert('测试功能已启用 - CSP兼容模式');
    });

    document.getElementById('reloadBtn')?.addEventListener('click', () => {
        location.reload();
    });

    // 绑定test-page.html的按钮事件
    const testButtons = [
        'testCanvasFingerprintBtn', 'testCanvasToDataURLBtn', 'testCanvasToBlobBtn',
        'testAudioFingerprintBtn', 'testAudioAnalyserBtn',
        'testWebGLFingerprintBtn', 'testWebGLExtensionsBtn',
        'testLocalStorageBtn', 'testIndexedDBBtn', 'testWebSQLBtn',
        'testClipboardBtn',
        'simulateMoanHoneypotBtn', 'simulateHFishHoneypotBtn', 'simulateBeefFrameworkBtn', 'simulateObfuscatedScriptBtn',
        'testJSONPRequestBtn', 'testSuspiciousDomainBtn'
    ];

    testButtons.forEach(btnId => {
        document.getElementById(btnId)?.addEventListener('click', () => {
            const testName = btnId.replace('Btn', '').replace(/([A-Z])/g, ' $1').toLowerCase();
            alert(`${testName} 测试已启用 - CSP兼容模式`);
            console.log(`执行测试: ${testName}`);
        });
    });

    // 绑定service-worker-debug.html的按钮事件
    document.getElementById('clearErrorLogBtn')?.addEventListener('click', () => {
        alert('清除日志功能已启用 - CSP兼容模式');
        console.log('清除错误日志');
    });

    document.getElementById('exportLogsBtn')?.addEventListener('click', () => {
        alert('导出日志功能已启用 - CSP兼容模式');
        console.log('导出日志');
    });

    document.getElementById('runDiagnosisBtn')?.addEventListener('click', () => {
        alert('诊断功能已启用 - CSP兼容模式');
        console.log('开始诊断');
    });

    document.getElementById('applyFixesBtn')?.addEventListener('click', () => {
        alert('应用修复功能已启用 - CSP兼容模式');
        console.log('应用修复');
    });

    // 绑定service-worker-status.html的按钮事件
    document.getElementById('clearErrorsBtn')?.addEventListener('click', () => {
        alert('清除错误功能已启用 - CSP兼容模式');
        console.log('清除错误');
    });

    document.getElementById('exportLogBtn')?.addEventListener('click', () => {
        alert('导出日志功能已启用 - CSP兼容模式');
        console.log('导出日志');
    });

    // 显示基础信息
    const infoDiv = document.createElement('div');
    infoDiv.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: #e3f2fd;
        color: #1976d2;
        padding: 10px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 1000;
    `;
    infoDiv.textContent = '测试页面已加载 - CSP兼容模式';
    document.body.appendChild(infoDiv);

    // 3秒后自动移除
    setTimeout(() => {
        if (document.body.contains(infoDiv)) {
            document.body.removeChild(infoDiv);
        }
    }, 3000);
});

// 错误处理
window.addEventListener('error', (event) => {
    console.error('测试页面错误:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('测试页面Promise拒绝:', event.reason);
});
